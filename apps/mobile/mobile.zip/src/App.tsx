import React, { useEffect, useMemo, useRef, useState } from 'react';
import type { GestureResponderHandlers, ImageSourcePropType, LayoutChangeEvent } from 'react-native';
import {
  Image,
  ImageBackground,
  Alert,
  Animated,
  BackHandler,
  Modal,
  KeyboardAvoidingView,
  PanResponder,
  Platform,
  ScrollView,
  RefreshControl,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  View,
  useWindowDimensions,
} from 'react-native';
import Constants from 'expo-constants';
import * as ImagePicker from 'expo-image-picker';
import * as WebBrowser from 'expo-web-browser';
import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';
import { LinearGradient } from 'expo-linear-gradient';
import Slider from '@react-native-community/slider';
import Icon from 'react-native-vector-icons/Ionicons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { storage } from '../utils/storage';
import { romchatAccountApi, romchatBackendHealth, type RomChatAccount, type RomChatMemberProfile, type RomChatOnboardingState, type RomChatSessionPayload } from './features/romchat/account';
import { apiBaseUrl } from './lib/api';
import { checkForAppUpdate } from './lib/appUpdates';
import { ApiRequestError } from './lib/api';
import { useRomChatData } from './features/romchat/hooks';

type Section = 'explore' | 'likes' | 'chat' | 'premium' | 'superlikes' | 'goldPlans' | 'payment' | 'safety' | 'profile' | 'privacy' | 'terms' | 'community';
type AuthMode = 'login' | 'signup' | 'verify' | 'forgot' | 'reset';
type SessionState = RomChatSessionPayload & { onboarding: RomChatOnboardingState };
type RomChatPromptAnswer = { prompt: string; answer: string };
type PlanName = 'Free' | 'Gold' | 'Platinum';
type RomChatPayment = { id: string; provider: string; amountKes: number; tokens: number; checkoutUrl?: string | null; instructions: string; status: string; currency: string; reference?: string; packageKind?: string; superLikeCount?: number | null };
type PaymentSheetState = { provider: 'mpesa' | 'paystack'; title: string; subtitle: string; amountKes: number; paymentId: string; checkoutUrl?: string | null; instructions: string };
type PendingPurchase =
  | { kind: 'tokens'; title: string; subtitle: string; amountKes: number; packageId: string; accent: 'gold' | 'pink' | 'blue' }
  | { kind: 'superlikes'; title: string; subtitle: string; amountKes: number; packageId: 'superlikes_15' | 'superlikes_30'; accent: 'blue' }
  | { kind: 'plan'; title: string; subtitle: string; amountKes: number; planId: 'gold' | 'platinum'; accent: 'gold' | 'platinum' };

const ROMCHAT_TOKEN_KEY = 'romchat:auth:token';
const ROMCHAT_SESSION_KEY = 'romchat:auth:session';

type ProfileSeed = {
  id: string;
  name: string;
  age: number;
  city: string;
  match: number;
  intent: string;
  prompt: string;
  voiceNote: string;
  videoPrompt: string;
  quote: string;
  song: string;
  gallery: number;
  fullGallery?: number;
  lockedGallery?: number;
  distanceKm?: number;
  catalogueAccess?: number;
  photos?: string[];
  tags: string[];
  answers: string[];
  poll: { question: string; yes: number; no: number };
  color: string;
  gender?: 'female' | 'male' | string;
  photo: ImageSourcePropType;
  matchId?: string | null;
  lastSeenAt?: string | null;
  online?: boolean;
  verified?: boolean;
};

const localProfiles: ProfileSeed[] = [
  {
    id: 'elena',
    name: 'Aisha',
    age: 26,
    city: 'Nairobi',
    match: 94,
    intent: 'Serious Kenyan love, slow burn',
    prompt: 'Java dates, Karura walks, and dinners where phones stay away.',
    voiceNote: '10s voice note: Saturday brunch, Nairobi sunsets, quiet confidence.',
    videoPrompt: 'Loop: golden-hour walk through Westlands.',
    quote: 'Green flags are consistency, respect, and showing up even when Nairobi traffic wins.',
    song: 'Currently replaying: Sauti Sol - Suzanna',
    gallery: 9,
    tags: ['Karura', 'Afrobeats', 'Travel'],
    answers: ['Intentional effort', 'Dinner first', 'Texts with substance'],
    poll: { question: 'Mutura date after sunset?', yes: 68, no: 32 },
    color: '#ff4f88',
    gender: 'female',
    photo: require('../assets/romchat/profile-elena.png'),
  },
  {
    id: 'amara',
    name: 'Wanjiku',
    age: 29,
    city: 'Mombasa',
    match: 91,
    intent: 'Ready for partnership',
    prompt: 'Coast weekends, Swahili food, film nights, and tiny rituals.',
    voiceNote: '10s voice note: I will remember your chai order.',
    videoPrompt: 'Loop: beach dinner in Nyali with a film queue.',
    quote: 'A good Kenyan date feels easy, respectful, and worth crossing town for.',
    song: 'Currently replaying: Bien - Inauma',
    gallery: 10,
    tags: ['Swahili food', 'Design', 'Film'],
    answers: ['Plan the date', 'Acts of service', 'Sunday market'],
    poll: { question: 'Diani weekend or Nairobi rooftop?', yes: 74, no: 26 },
    color: '#ff6a3d',
    gender: 'female',
    photo: require('../assets/romchat/profile-amara.png'),
  },
  {
    id: 'noah',
    name: 'Brian',
    age: 31,
    city: 'Kisumu',
    match: 88,
    intent: 'Intentional connection',
    prompt: 'Runner, builder, and the guy who books the table before traffic starts.',
    voiceNote: '10s voice note: Sunday run, Java stop, rooftop sunset.',
    videoPrompt: 'Loop: city run ending at a Kisumu lakefront cafe.',
    quote: 'The best relationships are playful, prayerful if that is your lane, and deeply reliable.',
    song: 'Currently replaying: Bensoul - Favorite Song',
    gallery: 8,
    tags: ['Books', 'Rooftops', 'Running'],
    answers: ['Early flight', 'Rooftop view', 'Calls over voice notes'],
    poll: { question: 'Matatu adventure or Bolt comfort?', yes: 57, no: 43 },
    color: '#8a3ffc',
    gender: 'male',
    photo: require('../assets/romchat/profile-noah.png'),
  },
];

const shortcuts: Array<{ id: Section; label: string; title: string }> = [
  { id: 'chat', label: 'Inbox', title: 'Matches' },
  { id: 'premium', label: 'Plus', title: 'Boost' },
  { id: 'safety', label: 'Safe', title: 'Trust' },
  { id: 'profile', label: 'Me', title: 'Profile' },
];

const plans: Array<{ id: 'gold' | 'platinum'; name: PlanName; price: string; amountKes: number; perks: string[] }> = [
  { id: 'gold', name: 'Gold', price: 'KES 1,000/mo', amountKes: 1000, perks: ['Unlimited likes', 'Likes Sent', 'Top Picks', 'Undo swipes', 'Read receipts'] },
  { id: 'platinum', name: 'Platinum', price: 'KES 2,400/mo', amountKes: 2400, perks: ['Unlimited likes', 'Priority likes', 'Likes Sent', 'Top Picks', 'Weekly Boost'] },
];

const gifts = [
  { id: 'rose', name: 'Rose', tokens: 5 },
  { id: 'chai', name: 'Chai date', tokens: 12 },
  { id: 'spotlight', name: 'Spotlight', tokens: 30 },
];

const tokenPackages = [
  { id: 'tokens_100', amount: 100, price: 'KES 250', unit: 'KES 2.50/ea', badge: '' },
  { id: 'tokens_350', amount: 350, price: 'KES 650', unit: 'KES 1.85/ea', badge: 'MOST POPULAR' },
  { id: 'tokens_1000', amount: 1000, price: 'KES 1,500', unit: 'KES 1.50/ea', badge: 'BEST VALUE' },
];

const SUPER_LIKE_COST = 15;
const UNDO_SWIPE_COST = 9;
const MATCH_POP_DURATION_MS = 1100;

const profilePromptTemplates = [
  'My ideal Kenyan date is',
  'Green flags I notice fast',
  'A song that explains my vibe',
  'Two truths and a soft secret',
  'The food date I will never reject',
  'How I show care',
  'What I am ready to build',
];

const tokenCatalog = [
  { id: 'media_unlock', label: 'Unlock voice/photo media', cost: '10' },
  { id: 'undo_swipe_token', label: 'Undo previous swipe', cost: String(UNDO_SWIPE_COST) },
  { id: 'send_rose', label: 'Send rose', cost: '5' },
  { id: 'priority_message', label: 'Priority message', cost: String(SUPER_LIKE_COST) },
  { id: 'reveal_admirer', label: 'Reveal admirer', cost: '22' },
  { id: 'rewind_after_pass', label: 'Undo previous swipe', cost: String(UNDO_SWIPE_COST) },
];


const chatSafetyRules = [
  { category: 'racial slur', severity: 'critical', patterns: [/\bn+[\W_]*[i1!]+[\W_]*g+[\W_]*g*(?:[e3]r|a|ah|uh)s?\b/i, /\bk+[\W_]*[i1!]+[\W_]*k+[\W_]*e+s?\b/i, /\bc+[\W_]*h+[\W_]*[i1!]+[\W_]*n+[\W_]*k+s?\b/i] },
  { category: 'sexual abuse', severity: 'high', patterns: [/\brape\b/i, /\bsexual(?:ly)?\s+assault\b/i, /\bforce\s+(?:you|u)\s+to\s+(?:sex|sleep)/i, /\bslut\b/i, /\bwhore\b/i] },
  { category: 'abusive threat', severity: 'high', patterns: [/\bkill\s+(?:you|u|yourself)\b/i, /\bbeat\s+(?:you|u)\b/i, /\bhurt\s+(?:you|u)\b/i, /\bi\s+hate\s+you\b/i, /\bworthless\b/i] },
  { category: 'scam pressure', severity: 'medium', patterns: [/\bwire\s+money\b/i, /\bgift\s*card\b/i, /\bcrypto\b/i, /\bpassword\b/i] },
];

function normalizeChatSafetyText(text: string) {
  const swap: Record<string, string> = { '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '@': 'a', '$': 's', '!': 'i' };
  return String(text || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[013457@$!]/g, (char) => swap[char] || char)
    .replace(/(.)\1{2,}/g, '$1$1')
    .replace(/[\s._-]+/g, ' ')
    .trim();
}

function checkRomchatChatSafety(text: string) {
  const normalized = normalizeChatSafetyText(text);
  const compact = normalized.replace(/[^a-z0-9]+/g, '');
  const hits = chatSafetyRules
    .filter((rule) => rule.patterns.some((pattern) => pattern.test(normalized) || pattern.test(compact)))
    .map((rule) => ({ category: rule.category, severity: rule.severity }));
  const shouldBlock = hits.some((hit) => hit.severity === 'critical' || hit.severity === 'high');
  return { status: shouldBlock ? 'blocked' : hits.length ? 'review' : 'approved', shouldBlock, categories: hits.map((hit) => hit.category), severity: hits[0]?.severity || 'none', checkedAt: new Date().toISOString() };
}

const starterMessages: Array<[string, string, string]> = [
  ['Aisha', 'Your answer about building a life with room for quiet days was rare.', 'Seen 8:41 PM'],
  ['You', 'The best connection feels calm before it feels exciting.', 'Read'],
  ['Aisha', 'That deserves a golden-hour walk. Saturday?', 'Typing now'],
];

const screenTitles: Record<Section, string> = {
  explore: 'Explore',
  likes: 'Likes',
  chat: 'Chat',
  premium: 'RomChat Plus',
  superlikes: 'Super Likes',
  goldPlans: 'RomChat Gold',
  payment: 'Secure Payment',
  safety: 'Kenya Safety',
  profile: 'My Kenyan Profile',
  privacy: 'Privacy Policy',
  terms: 'Terms of Use',
  community: 'Community Guidelines',
};

export default function App() {
  const [authBooted, setAuthBooted] = useState(false);
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState('');
  const [session, setSession] = useState<SessionState | null>(null);
  const [activeSection, setActiveSection] = useState<Section | null>(null);
  const [index, setIndex] = useState(0);
  const [verifiedOnly, setVerifiedOnly] = useState(true);
  const [incognito, setIncognito] = useState(true);
  const [antiGrab, setAntiGrab] = useState(true);
  const [chatBadgeCount, setChatBadgeCount] = useState(0);
  const [tokens, setTokens] = useState(0);
  const [boosted, setBoosted] = useState(false);
  const [subscriptionTier, setSubscriptionTier] = useState<PlanName>('Free');
  const [paymentNotice, setPaymentNotice] = useState('');
  const [mpesaPhone, setMpesaPhone] = useState('');
  const [pendingPurchase, setPendingPurchase] = useState<PendingPurchase | null>(null);
  const [paymentSheet, setPaymentSheet] = useState<PaymentSheetState | null>(null);
  const [showMatch, setShowMatch] = useState(false);
  const [pendingChatProfileId, setPendingChatProfileId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [likesFeedViewed, setLikesFeedViewed] = useState(false);
  const [reviewedLikeIds, setReviewedLikeIds] = useState<string[]>([]);
  const [goldMatchProfileIds, setGoldMatchProfileIds] = useState<string[]>([]);
  const appReady = Boolean(session?.token && session.profile && !session.onboarding.needsFirstImage);
  const romchat = useRomChatData(localProfiles, { enabled: appReady, token: session?.token });
  const matchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const navigationHistoryRef = useRef<Section[]>([]);
  const swipePosition = useRef(new Animated.ValueXY()).current;
  const { height: windowHeight, width: windowWidth } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const bottomInset = Math.max(insets.bottom, 32);
  const footerHeight = 64 + bottomInset;
  const bottomContentPadding = footerHeight + 18;
  const swipeCardHeight = Math.max(500, windowHeight - insets.top - footerHeight - 92);
  const swipeRotation = swipePosition.x.interpolate({ inputRange: [-windowWidth * 0.55, 0, windowWidth * 0.55], outputRange: ['-14deg', '0deg', '14deg'], extrapolate: 'clamp' });
  const swipeLift = swipePosition.x.interpolate({ inputRange: [-windowWidth * 0.55, 0, windowWidth * 0.55], outputRange: [-10, 0, -10], extrapolate: 'clamp' });
  const swipeCardStyle = { transform: [{ translateX: swipePosition.x }, { translateY: Animated.add(swipePosition.y, swipeLift) }, { rotate: swipeRotation }] };
  const viewerGender = String(session?.profile?.gender || '').toLowerCase();
  const desiredDiscoveryGender = viewerGender === 'female' ? 'male' : viewerGender === 'male' ? 'female' : '';
  const profiles = useMemo(() => {
    const liveProfiles = romchat.profiles as ProfileSeed[];
    return desiredDiscoveryGender ? liveProfiles.filter((item) => String(item.gender || '').toLowerCase() === desiredDiscoveryGender) : liveProfiles;
  }, [desiredDiscoveryGender, romchat.profiles]);
  const profile = profiles.length ? profiles[index % profiles.length]! : null;
  const firstUploadedImageUrl = resolveMediaUrl([...(session?.profile?.media || [])].sort((a, b) => (a.position || 0) - (b.position || 0)).find((item) => item.mediaType === 'image')?.url);
  const strength = useMemo(() => 82 + (verifiedOnly ? 5 : 0) + (incognito ? 4 : 0) + (antiGrab ? 3 : 0), [verifiedOnly, incognito, antiGrab]);
  const activePlan: PlanName = boosted ? 'Platinum' : subscriptionTier;
  const likesSummary = romchat.bootstrap?.likes || { receivedCount: 0, sentCount: 0, sentProfileIds: [], topPickProfileIds: [] };
  const likesReceivedCount = Math.max(0, Number(likesSummary.receivedCount || 0));
  const visibleLikesReceivedCount = likesFeedViewed ? 0 : Math.max(0, likesReceivedCount - reviewedLikeIds.length);
  const hasGoldAccess = activePlan === 'Gold' || activePlan === 'Platinum';
  const hasPlatinumAccess = activePlan === 'Platinum';

  function normalizeSession(payload: RomChatSessionPayload | (Omit<RomChatSessionPayload, 'token'> & { token?: string }), tokenFallback?: string | null): SessionState {
    const raw = (payload || {}) as Partial<RomChatSessionPayload> & { token?: string; message?: string; routes?: unknown };
    const token = raw.token || tokenFallback || '';
    const user = raw.user;
    if (!token || !user?.id || !user?.email) {
      console.warn('[romchat-auth] invalid session payload', {
        hasToken: Boolean(token),
        hasUser: Boolean(user),
        payloadKeys: raw && typeof raw === 'object' ? Object.keys(raw).slice(0, 8) : [],
        message: raw.message || null,
        hasRoutes: Boolean(raw.routes),
      });
      throw new Error('RomChat session expired. Please sign in again.');
    }
    const safeUser: RomChatAccount = { ...user, name: user.name || user.email.split('@')[0] || 'RomChat member' };
    const profile = raw.profile || null;
    const imageCount = Number(profile?.imageCount || 0);
    const onboarding = raw.onboarding || { needsProfile: !profile, needsFirstImage: !imageCount, imageCount, catalogueAccess: Math.min(6, Math.max(1, imageCount)) };
    return { token, user: safeUser, profile, onboarding };
  }

  async function persistSession(next: SessionState | null) {
    setSession(next);
    if (!next) {
      await storage.removeItem(ROMCHAT_TOKEN_KEY);
      await storage.removeItem(ROMCHAT_SESSION_KEY);
      return;
    }
    await storage.setItem(ROMCHAT_TOKEN_KEY, next.token);
    await storage.setItem(ROMCHAT_SESSION_KEY, JSON.stringify(next));
  }

  async function refreshSession(token = session?.token || '') {
    const payload = await romchatAccountApi.me(token);
    const next = normalizeSession(payload, token);
    await persistSession(next);
    return next;
  }

  async function pullToRefresh() {
    if (!session?.token || refreshing) return;
    setRefreshing(true);
    setAuthError('');
    try {
      await refreshSession(session.token);
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : 'Unable to refresh RomChat.');
    } finally {
      setRefreshing(false);
    }
  }

  async function applyAuth(payload: RomChatSessionPayload) {
    const next = normalizeSession(payload, payload.token);
    await persistSession(next);
  }

  function goToSection(next: Section | null) {
    setActiveSection((current) => {
      if (current === next) return current;
      if (next === null) {
        navigationHistoryRef.current = [];
        return null;
      }
      if (current) {
        navigationHistoryRef.current = [...navigationHistoryRef.current, current];
      }
      return next;
    });
  }

  function goBackSection() {
    setActiveSection(() => {
      const history = navigationHistoryRef.current.slice();
      const previous = history.pop() || null;
      navigationHistoryRef.current = history;
      return previous;
    });
  }

  async function signOut() {
    clearMatchTimer();
    setShowMatch(false);
    setPaymentSheet(null);
    navigationHistoryRef.current = [];
    await persistSession(null);
    goToSection(null);
  }

  async function requestDataDeletion() {
    if (!session?.token) return;
    try {
      setAuthBusy(true);
      setAuthError('');
      console.info('[romchat-account] deletion-request:start', { memberId: session.user.id, email: session.user.email });
      const response = await romchatAccountApi.requestAccountDeletion(session.token, { reason: 'Requested from RomChat profile screen.' });
      Alert.alert('Deletion request sent', response.message || 'Your data deletion request has been recorded.');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to submit deletion request.';
      setAuthError(message);
      Alert.alert('Deletion request failed', message);
    } finally {
      setAuthBusy(false);
    }
  }

  async function confirmDeleteAccount() {
    if (!session?.token) return;
    try {
      setAuthBusy(true);
      setAuthError('');
      console.info('[romchat-account] delete:start', { memberId: session.user.id, email: session.user.email });
      await romchatAccountApi.deleteAccount(session.token, { reason: 'Deleted from RomChat profile screen.' });
      await signOut();
      Alert.alert('Account deleted', 'Your RomChat account has been removed from the device and backend.');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to delete account.';
      setAuthError(message);
      Alert.alert('Delete failed', message);
    } finally {
      setAuthBusy(false);
    }
  }

  async function deleteAccount() {
    Alert.alert(
      'Delete your RomChat account?',
      'This removes your account access and profile data. You can also request a data deletion review instead.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Request deletion', onPress: () => { void requestDataDeletion(); } },
        { text: 'Delete now', style: 'destructive', onPress: () => { void confirmDeleteAccount(); } },
      ]
    );
  }

  useEffect(() => {
    let mounted = true;
    (async () => {
      const savedToken = await storage.getItem(ROMCHAT_TOKEN_KEY);
      const savedSession = await storage.getItem(ROMCHAT_SESSION_KEY);
      if (savedSession && mounted) {
        try { setSession(normalizeSession(JSON.parse(savedSession) as SessionState, savedToken)); } catch { await persistSession(null); }
      }
      if (savedToken) {
        try {
          const payload = await romchatAccountApi.me(savedToken);
          if (mounted) await persistSession(normalizeSession(payload, savedToken));
        } catch (error) {
          console.warn('[romchat-auth] boot refresh failed', error instanceof Error ? error.message : String(error));
          if (mounted) {
            setAuthError(error instanceof Error ? error.message : 'Please sign in again.');
            await persistSession(null);
          }
        }
      }
      if (mounted) setAuthBooted(true);
    })();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    void checkForAppUpdate();
  }, []);

  useEffect(() => {
    const activeTier = String(romchat.bootstrap?.premium?.activeTier || '').toLowerCase();
    if (activeTier === 'gold') {
      setSubscriptionTier('Gold');
      setBoosted(false);
    } else if (activeTier === 'platinum') {
      setSubscriptionTier('Platinum');
      setBoosted(true);
    } else if (activeTier === 'free') {
      setSubscriptionTier('Free');
      setBoosted(false);
    }
  }, [romchat.bootstrap?.premium?.activeTier]);

  useEffect(() => {
    const walletBalance = Number(romchat.bootstrap?.wallet?.balance);
    if (Number.isFinite(walletBalance)) setTokens(Math.max(0, Math.floor(walletBalance)));
  }, [romchat.bootstrap?.wallet?.balance]);

  useEffect(() => {
    return () => {
      if (matchTimerRef.current) clearTimeout(matchTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (Platform.OS !== 'android') return undefined;
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      if (paymentSheet) {
        setPaymentSheet(null);
        return true;
      }
      if (showMatch) {
        setShowMatch(false);
        return true;
      }
      if (activeSection) {
        goBackSection();
        return true;
      }
      return false;
    });
    return () => subscription.remove();
  }, [activeSection, paymentSheet, showMatch]);

  function clearMatchTimer() {
    if (matchTimerRef.current) {
      clearTimeout(matchTimerRef.current);
      matchTimerRef.current = null;
    }
  }

  function openTokenStore() {
    clearMatchTimer();
    setShowMatch(false);
    goToSection('premium');
  }

  function showPaymentSheet(payment: RomChatPayment, provider: 'mpesa' | 'paystack', title: string, subtitle: string) {
    console.info('[romchat-payment-ui] sheet:open', {
      paymentId: payment.id,
      provider,
      status: payment.status,
      amountKes: payment.amountKes,
      hasCheckoutUrl: Boolean(payment.checkoutUrl),
      reference: payment.reference || null,
    });
    setPaymentSheet({
      provider,
      title,
      subtitle,
      amountKes: Number(payment.amountKes || 0),
      paymentId: payment.id,
      checkoutUrl: payment.checkoutUrl || null,
      instructions: payment.instructions || (provider === 'mpesa' ? 'Approve the M-Pesa prompt on your phone.' : 'Open card checkout to complete payment.'),
    });
  }

  async function openPaymentCheckout() {
    if (!paymentSheet?.checkoutUrl) return;
    try {
      await WebBrowser.openBrowserAsync(paymentSheet.checkoutUrl);
    } catch (error) {
      setPaymentNotice(error instanceof Error ? error.message : 'Unable to open card checkout.');
    }
  }

  function openPaymentPage(next: PendingPurchase) {
    setPaymentNotice('');
    setPendingPurchase(next);
    goToSection('payment');
  }

  async function startTokenPurchase(packageId = 'tokens_100', provider: 'mpesa' | 'paystack' = 'mpesa') {
    try {
      if (provider === 'mpesa' && !mpesaPhone.trim()) throw new Error('Enter your M-Pesa phone number first.');
      console.info('[romchat-payment-ui] token:start', { provider, packageId, hasPhone: Boolean(mpesaPhone.trim()) });
      const payment = await romchat.createPayment({ provider, purpose: 'tokens', packageId, phone: provider === 'mpesa' ? mpesaPhone : undefined });
      if (!payment) throw new Error('Payment could not start.');
      setPaymentNotice(provider === 'mpesa' ? `M-Pesa request created for KES ${payment.amountKes}. Tokens activate automatically after payment confirmation.` : `Paystack card checkout prepared for KES ${payment.amountKes}. Tokens activate after card confirmation.`);
      showPaymentSheet(payment, provider, 'Token Wallet', `${payment.tokens || 0} RomChat tokens`);
    } catch (error) { setPaymentNotice(error instanceof Error ? error.message : 'Unable to start token payment.'); }
  }

  async function startPlanPurchase(planId: 'gold' | 'platinum', provider: 'mpesa' | 'paystack' = 'mpesa') {
    try {
      if (provider === 'mpesa' && !mpesaPhone.trim()) throw new Error('Enter your M-Pesa phone number first.');
      console.info('[romchat-payment-ui] subscription:start', { provider, planId, hasPhone: Boolean(mpesaPhone.trim()) });
      const payment = await romchat.createPayment({ provider, purpose: 'subscription', planId, phone: provider === 'mpesa' ? mpesaPhone : undefined });
      if (!payment) throw new Error('Payment could not start.');
      const plan = plans.find((item) => item.id === planId);
      setPaymentNotice(provider === 'mpesa' ? `M-Pesa request created for ${plan?.price || `KES ${payment.amountKes}`}. Premium activates automatically after payment confirmation.` : `Paystack card checkout prepared for ${plan?.price || `KES ${payment.amountKes}`}. Premium activates after card confirmation.`);
      showPaymentSheet(payment, provider, `${plan?.name || 'Premium'} plan`, 'Unlimited likes and premium discovery benefits');
    } catch (error) { setPaymentNotice(error instanceof Error ? error.message : 'Unable to start subscription payment.'); }
  }

  async function startSuperLikePurchase(packageId: 'superlikes_15' | 'superlikes_30', provider: 'mpesa' | 'paystack' = 'mpesa') {
    const count = packageId === 'superlikes_30' ? 30 : 15;
    try {
      if (provider === 'mpesa' && !mpesaPhone.trim()) throw new Error('Enter your M-Pesa phone number first.');
      console.info('[romchat-payment-ui] superlike:start', { provider, packageId, count, hasPhone: Boolean(mpesaPhone.trim()) });
      const payment = await romchat.createPayment({ provider, purpose: 'tokens', packageId, phone: provider === 'mpesa' ? mpesaPhone : undefined });
      if (!payment) throw new Error('Payment could not start.');
      setPaymentNotice(provider === 'mpesa' ? `M-Pesa request created for ${count} Super Likes at KES ${payment.amountKes}. Super Likes activate after payment confirmation.` : `Paystack checkout prepared for ${count} Super Likes at KES ${payment.amountKes}. Super Likes activate after card confirmation.`);
      showPaymentSheet(payment, provider, 'Super Likes', `${count} priority Super Likes`);
    } catch (error) { setPaymentNotice(error instanceof Error ? error.message : 'Unable to start Super Likes payment.'); }
  }

  function openMatchedChatSoon() {
    clearMatchTimer();
    setShowMatch(true);
    matchTimerRef.current = setTimeout(() => {
      setShowMatch(false);
      goToSection('chat');
    }, MATCH_POP_DURATION_MS);
  }

  function advanceProfile() {
    setIndex((value) => profiles.length ? (value + 1) % profiles.length : 0);
  }

  function passProfile() {
    clearMatchTimer();
    if (!profile) return;
    void romchat.swipe(profile.id, 'pass');
    advanceProfile();
    setShowMatch(false);
  }

  function animateCardDecision(direction: 'left' | 'right', complete: () => void) {
    if (!profile) return;
    clearMatchTimer();
    Animated.timing(swipePosition, {
      toValue: { x: direction === 'right' ? windowWidth * 1.18 : -windowWidth * 1.18, y: -28 },
      duration: 235,
      useNativeDriver: false,
    }).start(() => {
      swipePosition.setValue({ x: 0, y: 0 });
      complete();
    });
  }

  function animatedPassProfile() {
    animateCardDecision('left', passProfile);
  }

  function animatedLikeProfile() {
    animateCardDecision('right', () => void likeProfile('like'));
  }

  function previous() {
    if (!hasGoldAccess) {
      Alert.alert('Rewind is premium', 'Free members cannot swipe back. Buy 100 tokens for KES 250 or upgrade to Gold to rewind.', [
        { text: 'Later', style: 'cancel' },
        { text: 'OK', onPress: () => { void startTokenPurchase('tokens_100', 'mpesa'); openTokenStore(); } },
      ]);
      return;
    }
    clearMatchTimer();
    setIndex((value) => (value - 1 + profiles.length) % profiles.length);
    setShowMatch(false);
  }

  async function likeProfile(action: 'like' | 'super_like' = 'like') {
    if (!profile) return;
    clearMatchTimer();
    try {
      const result = await romchat.swipe(profile.id, action);
      if (result?.matched) openMatchedChatSoon();
      else {
        setShowMatch(false);
        advanceProfile();
      }
    } catch (error) {
      if (error instanceof ApiRequestError && error.code === 'DAILY_LIKE_LIMIT_REACHED') {
        setShowMatch(false);
        Alert.alert('You are out of Likes', "You've used your 30 free Likes for today. Check back tomorrow to keep swiping, or upgrade for unlimited Likes.", [
          { text: 'Maybe later', style: 'cancel' },
          { text: 'See upgrades', onPress: openTokenStore },
        ]);
        return;
      }
      throw error;
    }
  }

  function markLikeReviewed(profileId: string) {
    setReviewedLikeIds((current) => current.includes(profileId) ? current : [...current, profileId]);
  }

  async function acceptLikeAndOpenChat(profileId: string, options: { openChat?: boolean } = {}) {
    clearMatchTimer();
    setShowMatch(false);
    markLikeReviewed(profileId);
    setGoldMatchProfileIds((current) => current.includes(profileId) ? current : [profileId, ...current]);
    const result = await romchat.swipe(profileId, 'like', { forceMatch: true });
    setPendingChatProfileId(profileId);
    await romchat.refresh();
    if (options.openChat !== false) goToSection('chat');
    if (!result?.matched) console.warn('[romchat-likes] accepted like did not return matched result', { profileId, result });
  }

  async function messageGoldMatch(profileId: string, text: string) {
    const clean = text.trim();
    if (!clean) return;
    setGoldMatchProfileIds((current) => current.includes(profileId) ? current : [profileId, ...current]);
    setPendingChatProfileId(profileId);
    await romchat.sendMessage(clean, `match_${profileId}`, { mode: 'standard', readReceiptRequested: false });
    goToSection('chat');
  }

  function passLikeProfile(profileId: string) {
    markLikeReviewed(profileId);
    void romchat.swipe(profileId, 'pass');
  }

  function superLikeProfile() {
    openPaymentPage({
      kind: 'plan',
      title: 'RomChat Platinum',
      subtitle: 'Priority likes, weekly boost, Top Picks, unlimited likes, and faster discovery.',
      amountKes: 2400,
      planId: 'platinum',
      accent: 'platinum',
    });
  }

  const swipeHandlers = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponder: (_event, gesture) => Math.abs(gesture.dx) > 10 && Math.abs(gesture.dx) > Math.abs(gesture.dy) * 1.15,
        onPanResponderMove: Animated.event([null, { dx: swipePosition.x, dy: swipePosition.y }], { useNativeDriver: false }),
        onPanResponderRelease: (_event, gesture) => {
          const swipeOut = (direction: 'left' | 'right') => {
            Animated.timing(swipePosition, {
              toValue: { x: direction === 'right' ? windowWidth * 1.18 : -windowWidth * 1.18, y: gesture.dy * 0.6 },
              duration: 210,
              useNativeDriver: false,
            }).start(() => {
              swipePosition.setValue({ x: 0, y: 0 });
              if (direction === 'right') void likeProfile('like');
              else passProfile();
            });
          };
          if (gesture.dx > 92) return swipeOut('right');
          if (gesture.dx < -92) return swipeOut('left');
          Animated.spring(swipePosition, { toValue: { x: 0, y: 0 }, friction: 7, tension: 95, useNativeDriver: false }).start();
        },
        onPanResponderTerminate: () => Animated.spring(swipePosition, { toValue: { x: 0, y: 0 }, friction: 7, tension: 95, useNativeDriver: false }).start(),
      }).panHandlers,
    [profile?.id, profiles.length, windowWidth, swipePosition, likeProfile, passProfile]
  );

  async function loginWithEmail(email: string, password: string) {
    setAuthBusy(true);
    setAuthError('');
    try { await applyAuth(await romchatAccountApi.login({ email, password })); }
    catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to login.'); }
    finally { setAuthBusy(false); }
  }

  async function requestOtp(name: string, email: string, password: string) {
    setAuthBusy(true);
    setAuthError('');
    try { await romchatAccountApi.requestOtp({ name, email, password }); }
    catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to send verification code.'); throw error; }
    finally { setAuthBusy(false); }
  }

  async function verifyOtp(email: string, otp: string) {
    setAuthBusy(true);
    setAuthError('');
    try { await applyAuth(await romchatAccountApi.verifyOtp({ email, otp })); }
    catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to verify code.'); }
    finally { setAuthBusy(false); }
  }

  async function requestPasswordReset(email: string) {
    setAuthBusy(true);
    setAuthError('');
    try {
      const response = await romchatAccountApi.forgotPassword({ email });
      const devCode = response.developmentCode ? ' Dev code: ' + response.developmentCode : '';
      return (response.message || 'Reset code sent. Check your email.') + devCode;
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : 'Unable to send reset email.');
      throw error;
    } finally {
      setAuthBusy(false);
    }
  }

  async function resetPassword(email: string, code: string, password: string) {
    setAuthBusy(true);
    setAuthError('');
    try { await applyAuth(await romchatAccountApi.resetPassword({ email, code, password })); }
    catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to reset password.'); throw error; }
    finally { setAuthBusy(false); }
  }

  async function loginWithGoogle(idToken: string) {
    setAuthBusy(true);
    setAuthError('');
    console.info('[romchat-google] token-login:start', { apiBaseUrl, tokenLength: idToken.length });
    try {
      await applyAuth(await romchatAccountApi.google(idToken));
      console.info('[romchat-google] token-login:success');
    }
    catch (error) {
      console.warn('[romchat-google] token-login:failed', error);
      setAuthError(error instanceof Error ? error.message : 'Google login failed.');
    }
    finally { setAuthBusy(false); }
  }

  async function loginWithNativeGoogle() {
    setAuthBusy(true);
    setAuthError('');
    try {
      console.info('[romchat-google] native:start', { apiBaseUrl });
      try { await GoogleSignin.signOut(); } catch (signOutError) { console.info('[romchat-google] native:signout-skip', signOutError); }
      await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
      console.info('[romchat-google] native:play-services-ok');
      await GoogleSignin.signIn();
      console.info('[romchat-google] native:signin-ok');
      const { idToken } = await GoogleSignin.getTokens();
      console.info('[romchat-google] native:tokens', { hasIdToken: Boolean(idToken), tokenLength: idToken?.length || 0 });
      if (!idToken) throw new Error('Google did not return an ID token.');
      try {
        const health = await romchatBackendHealth();
        console.info('[romchat-google] backend:health-ok', health);
      } catch (healthError) {
        console.warn('[romchat-google] backend:health-failed', healthError);
      }
      await applyAuth(await romchatAccountApi.google(idToken));
      console.info('[romchat-google] native:backend-auth-success');
    } catch (error) {
      console.warn('[romchat-google] native:failed', error);
      const code = typeof error === 'object' && error && 'code' in error ? String((error as { code?: string }).code || '') : '';
      if (code === statusCodes.SIGN_IN_CANCELLED) setAuthError('Google sign-in cancelled.');
      else if (code === statusCodes.IN_PROGRESS) setAuthError('Google sign-in is already in progress.');
      else if (code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) setAuthError('Google Play Services is unavailable or needs an update.');
      else setAuthError(error instanceof Error ? error.message : 'Google login failed.');
    } finally { setAuthBusy(false); }
  }

  async function saveOnboardingProfile(payload: { displayName: string; age: number; gender: string; city: string; intent: string; bio: string; interests: string[] }) {
    if (!session?.token) return;
    setAuthBusy(true);
    setAuthError('');
    try {
      await romchatAccountApi.saveProfile(session.token, payload);
      await refreshSession(session.token);
    } catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to save profile.'); }
    finally { setAuthBusy(false); }
  }

  async function uploadProfileImage() {
    if (!session?.token) return;
    setAuthBusy(true);
    setAuthError('');
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) throw new Error('Photo library permission is required.');
      const shouldCropForAvatar = !session.profile?.imageCount;
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: shouldCropForAvatar, ...(shouldCropForAvatar ? { aspect: [1, 1] as [number, number] } : {}), quality: 0.82, base64: true });
      if (result.canceled) return;
      const asset = result.assets[0];
      if (!asset?.base64) throw new Error('Unable to read image data.');
      const contentType = asset.mimeType || 'image/jpeg';
      const dataUri = `data:${contentType};base64,${asset.base64}`;
      const response = await romchatAccountApi.uploadMedia(session.token, { mediaType: 'image', dataUri, contentType, fileName: asset.fileName || 'profile.jpg' });
      if (response.profile) {
        const next = normalizeSession({ token: session.token, user: session.user, profile: response.profile });
        await persistSession(next);
      } else {
        await refreshSession(session.token);
      }
    } catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to upload image.'); }
    finally { setAuthBusy(false); }
  }

  async function setMainProfilePhoto(mediaId: string) {
    if (!session?.token || !mediaId) return;
    setAuthBusy(true);
    setAuthError('');
    try {
      const response = await romchatAccountApi.setMainPhoto(session.token, mediaId);
      const next = normalizeSession({ token: session.token, user: session.user, profile: response.profile });
      await persistSession(next);
    } catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to update main photo.'); }
    finally { setAuthBusy(false); }
  }

  async function verifySelfieProfile() {
    if (!session?.token) return;
    setAuthBusy(true);
    setAuthError('');
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (!permission.granted) throw new Error('Camera permission is required for selfie verification.');
      const result = await ImagePicker.launchCameraAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [1, 1], quality: 0.72, base64: true, cameraType: ImagePicker.CameraType.front });
      if (result.canceled) return;
      const asset = result.assets[0];
      if (!asset?.base64) throw new Error('Unable to read selfie data.');
      const contentType = asset.mimeType || 'image/jpeg';
      const response = await romchatAccountApi.verifySelfie(session.token, { dataUri: `data:${contentType};base64,${asset.base64}`, contentType, fileName: asset.fileName || 'selfie-verification.jpg' });
      const next = normalizeSession({ token: session.token, user: session.user, profile: response.profile });
      await persistSession(next);
    } catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to verify selfie.'); }
    finally { setAuthBusy(false); }
  }

  async function saveProfileDetails(payload: { displayName: string; gender: string; city: string; intent: string; bio: string; interests: string[] }) {
    if (!session?.token || !session.profile) return;
    setAuthBusy(true);
    setAuthError('');
    try {
      const response = await romchatAccountApi.saveProfile(session.token, {
        ...payload,
        age: session.profile.age,
        promptAnswers: session.profile.promptAnswers,
        maxDistanceKm: session.profile.maxDistanceKm,
        minAge: session.profile.minAge,
        maxAge: session.profile.maxAge,
        mapDiscoveryEnabled: session.profile.mapDiscoveryEnabled,
      });
      const next = normalizeSession({ token: session.token, user: session.user, profile: response.profile });
      await persistSession(next);
      await romchat.refresh();
    } catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to save profile details.'); }
    finally { setAuthBusy(false); }
  }

  async function saveProfilePrompts(promptAnswers: RomChatPromptAnswer[]) {
    if (!session?.token || !session.profile) return;
    setAuthBusy(true);
    setAuthError('');
    try {
      const response = await romchatAccountApi.saveProfile(session.token, {
        displayName: session.profile.displayName,
        age: session.profile.age,
        gender: session.profile.gender,
        city: session.profile.city,
        intent: session.profile.intent,
        bio: session.profile.bio,
        interests: session.profile.interests,
        promptAnswers,
        maxDistanceKm: session.profile.maxDistanceKm,
        minAge: session.profile.minAge,
        maxAge: session.profile.maxAge,
        mapDiscoveryEnabled: session.profile.mapDiscoveryEnabled,
      });
      const next = normalizeSession({ token: session.token, user: session.user, profile: response.profile });
      await persistSession(next);
    } catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to save prompts.'); }
    finally { setAuthBusy(false); }
  }

  async function saveDiscoverySettings(payload: { maxDistanceKm: number; minAge: number; maxAge: number; mapDiscoveryEnabled: boolean }) {
    if (!session?.token || !session.profile) return;
    setAuthBusy(true);
    setAuthError('');
    try {
      const response = await romchatAccountApi.saveProfile(session.token, {
        displayName: session.profile.displayName,
        age: session.profile.age,
        gender: session.profile.gender,
        city: session.profile.city,
        intent: session.profile.intent,
        bio: session.profile.bio,
        interests: session.profile.interests,
        promptAnswers: session.profile.promptAnswers,
        maxDistanceKm: payload.maxDistanceKm,
        minAge: payload.minAge,
        maxAge: payload.maxAge,
        mapDiscoveryEnabled: payload.mapDiscoveryEnabled,
      });
      const next = normalizeSession({ token: session.token, user: session.user, profile: response.profile });
      await persistSession(next);
      await romchat.refresh();
    } catch (error) { setAuthError(error instanceof Error ? error.message : 'Unable to save distance settings.'); }
    finally { setAuthBusy(false); }
  }
  function openSwipeDeck() {
    goToSection(null);
    if (appReady) void romchat.refresh();
  }

  function renderSection(section: Section) {
    if (section === 'explore') {
      return <ExploreScreen openLikes={() => goToSection('likes')} />;
    }
    if (section === 'likes') {
      return <LikesScreen profiles={profiles} likesReceivedCount={visibleLikesReceivedCount} likesSummary={likesSummary} activePlan={activePlan} openPremium={openTokenStore} openSuperLikes={() => goToSection('superlikes')} openChat={() => goToSection('chat')} acceptLikeAndOpenChat={(profileId) => void acceptLikeAndOpenChat(profileId, { openChat: false })} passLikeProfile={passLikeProfile} messageGoldMatch={(profileId, text) => void messageGoldMatch(profileId, text)} likeProfile={() => likeProfile('like')} passProfile={passProfile} onAllLikesSeenChange={setLikesFeedViewed} />;
    }
    if (section === 'chat') {
      return (
       <Chat
        profiles={profiles}
        sendMessage={romchat.sendMessage}
        getMessages={romchat.getMessages}
        reportMessage={romchat.reportMessage}
        currentUserId={session?.user?.id || 'me'}
        initialProfileId={pendingChatProfileId}
        goldMatchProfileIds={goldMatchProfileIds}
        onInitialProfileHandled={() => setPendingChatProfileId(null)}
        status={romchat.lastAction}
      />
      );
    }
    if (section === 'premium') {
      return <Premium tokens={tokens} boosted={boosted} activePlan={activePlan} paymentNotice={paymentNotice} activateBoost={() => { setBoosted(true); setSubscriptionTier('Platinum'); void romchat.boost(); }} openPaymentPage={openPaymentPage} />;
    }
    if (section === 'superlikes') {
      return <SuperLikesScreen paymentNotice={paymentNotice} openGoldPlans={() => goToSection('goldPlans')} openPaymentPage={openPaymentPage} />;
    }
    if (section === 'goldPlans') {
      return <GoldPlansScreen paymentNotice={paymentNotice} openPaymentPage={openPaymentPage} />;
    }
    if (section === 'payment') {
      return (
        <PaymentPage
          purchase={pendingPurchase}
          mpesaPhone={mpesaPhone}
          setMpesaPhone={setMpesaPhone}
          paymentNotice={paymentNotice}
          onBack={goBackSection}
          onMpesa={() => {
            if (!pendingPurchase) return;
            if (pendingPurchase.kind === 'plan') void startPlanPurchase(pendingPurchase.planId, 'mpesa');
            else if (pendingPurchase.kind === 'superlikes') void startSuperLikePurchase(pendingPurchase.packageId, 'mpesa');
            else void startTokenPurchase(pendingPurchase.packageId, 'mpesa');
          }}
          onCard={() => {
            if (!pendingPurchase) return;
            if (pendingPurchase.kind === 'plan') void startPlanPurchase(pendingPurchase.planId, 'paystack');
            else if (pendingPurchase.kind === 'superlikes') void startSuperLikePurchase(pendingPurchase.packageId, 'paystack');
            else void startTokenPurchase(pendingPurchase.packageId, 'paystack');
          }}
        />
      );
    }
    if (section === 'privacy' || section === 'terms' || section === 'community') {
      return <PolicyScreen section={section} />;
    }
    if (section === 'safety') {
      return (
        <Safety
          incognito={incognito}
          setIncognito={setIncognito}
          antiGrab={antiGrab}
          setAntiGrab={setAntiGrab}
          verifiedOnly={verifiedOnly}
          setVerifiedOnly={setVerifiedOnly}
          updatePrivacy={(next) => void romchat.updatePrivacy(next)}
          report={() => profile ? void romchat.report(profile.id) : undefined}
          verify={romchat.verify}
          status={romchat.lastAction}
        />
      );
    }
    return <Profile account={session?.user || null} profile={session?.profile || null} strength={strength} incognito={incognito} busy={authBusy} error={authError} onUploadImage={uploadProfileImage} onSetMainPhoto={setMainProfilePhoto} onVerifySelfie={verifySelfieProfile} onSaveDetails={saveProfileDetails} onSavePrompts={saveProfilePrompts} onSaveDiscoverySettings={saveDiscoverySettings} status={romchat.lastAction} onSignOut={signOut} onDeleteAccount={deleteAccount} onRequestDataDeletion={requestDataDeletion} openPolicy={(section) => goToSection(section)} />;
  }

  if (!authBooted) {
    return <LoadingScreen label="Preparing RomChat" />;
  }

  if (!session?.token) {
    return <AuthScreen busy={authBusy} error={authError} onLogin={loginWithEmail} onRequestOtp={requestOtp} onVerifyOtp={verifyOtp} onForgotPassword={requestPasswordReset} onResetPassword={resetPassword} onNativeGoogle={loginWithNativeGoogle} />;
  }

  if (!session.profile || session.onboarding.needsFirstImage) {
    return <ProfileOnboardingScreen busy={authBusy} error={authError} accountName={session.user?.name || session.user?.email?.split('@')[0] || 'RomChat member'} profile={session.profile} uploadedImageCount={session.onboarding.imageCount} onSaveProfile={saveOnboardingProfile} onUploadImage={uploadProfileImage} onSignOut={signOut} />;
  }

  if (activeSection) {
    return (
      <SafeAreaView edges={['top', 'bottom', 'left', 'right']} style={styles.safe}>
        <StatusBar barStyle="light-content" backgroundColor="#120914" />
        <ScreenHeader title={screenTitles[activeSection]} onBack={goBackSection} apiOnline={romchat.apiOnline} />
        <ScrollView
          contentContainerStyle={[styles.screenContent, { paddingBottom: bottomContentPadding }]}
          contentInsetAdjustmentBehavior="automatic"
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void pullToRefresh()} tintColor="#FF1493" colors={['#FF1493', '#FFD700']} progressBackgroundColor="#1E1222" />}
        >
          {renderSection(activeSection)}
        </ScrollView>
        <PaymentSheet sheet={paymentSheet} onClose={() => setPaymentSheet(null)} onOpenCheckout={() => void openPaymentCheckout()} onRefresh={() => void romchat.refresh()} />
        <FooterNav active={activeSection} setActiveSection={setActiveSection} openSwipeDeck={openSwipeDeck} bottomInset={bottomInset} chatBadgeCount={chatBadgeCount} likesReceivedCount={visibleLikesReceivedCount} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView edges={['top', 'bottom', 'left', 'right']} style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#120914" />
      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: bottomContentPadding }]}
        contentInsetAdjustmentBehavior="automatic"
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void pullToRefresh()} tintColor="#FF1493" colors={['#FF1493', '#FFD700']} progressBackgroundColor="#1E1222" />}
        scrollEnabled={false}
        bounces={false}
        overScrollMode="never"
      >
        <View style={styles.topBar}>
          <TouchableOpacity onPress={() => goToSection('profile')} style={styles.brandRow}>
            <Image source={firstUploadedImageUrl ? { uri: firstUploadedImageUrl } : require('../assets/icon.png')} style={styles.logo} />
            <View><Text style={styles.brand}>RomChat</Text><Text style={styles.brandTagline}>Kenya dating</Text></View>
          </TouchableOpacity>
          <View style={styles.topControls}>
            <TouchableOpacity onPress={() => goToSection('chat')} style={styles.iconButton} accessibilityLabel="Open inbox">
              <Icon name="chatbubbles" size={20} color="#FFFFFF" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => goToSection('safety')} style={styles.iconButton} accessibilityLabel="Open safety center">
              <Icon name="shield-checkmark" size={20} color="#FFFFFF" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => goToSection('premium')} style={styles.walletPill}>
              <Icon name="diamond" size={15} color="#FFD700" />
              <Text style={styles.walletText}>{tokens}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {profile ? (
          <>
            <Discover
              profile={profile}
              passProfile={animatedPassProfile}
              likeProfile={animatedLikeProfile}
              topProfile={superLikeProfile}
              previous={previous}
              swipeHandlers={swipeHandlers}
              swipeCardStyle={swipeCardStyle}
              showMatch={showMatch}
              dismissMatch={passProfile}
              openChat={() => {
                clearMatchTimer();
                setShowMatch(false);
                goToSection('chat');
              }}
              profiles={profiles}
              cardHeight={swipeCardHeight}
            />
          </>
        ) : (
          <EmptyDiscovery openProfile={() => goToSection('profile')} status={romchat.lastAction} />
        )}
      </ScrollView>
      <PaymentSheet sheet={paymentSheet} onClose={() => setPaymentSheet(null)} onOpenCheckout={() => void openPaymentCheckout()} onRefresh={() => void romchat.refresh()} />
      <FooterNav active="swipe" setActiveSection={setActiveSection} openSwipeDeck={openSwipeDeck} bottomInset={bottomInset} chatBadgeCount={chatBadgeCount} likesReceivedCount={visibleLikesReceivedCount} />
    </SafeAreaView>
  );
}

function LoadingScreen({ label }: { label: string }) {
  return (
    <SafeAreaView edges={['top', 'bottom', 'left', 'right']} style={styles.safeCenter}>
      <ActivityIndicator color="#FF1493" size="large" />
      <Text style={styles.loadingText}>{label}</Text>
    </SafeAreaView>
  );
}

function AuthScreen({ busy, error, onLogin, onRequestOtp, onVerifyOtp, onForgotPassword, onResetPassword, onNativeGoogle }: {
  busy: boolean;
  error: string;
  onLogin: (email: string, password: string) => Promise<void>;
  onRequestOtp: (name: string, email: string, password: string) => Promise<void>;
  onVerifyOtp: (email: string, otp: string) => Promise<void>;
  onForgotPassword: (email: string) => Promise<string>;
  onResetPassword: (email: string, code: string, password: string) => Promise<void>;
  onNativeGoogle: () => Promise<void>;
}) {
  const [mode, setMode] = useState<AuthMode>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [resetPasswordValue, setResetPasswordValue] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [otp, setOtp] = useState('');
  const [resetNotice, setResetNotice] = useState('');
  const [localError, setLocalError] = useState('');
  const manifestExtra = (Constants.manifest as { extra?: unknown } | null | undefined)?.extra;
  const extra = (Constants.expoConfig?.extra || manifestExtra || {}) as { EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID?: string; EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID?: string; EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID?: string };
  const googleConfigured = Boolean(extra.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID && extra.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID);
  const titleByMode: Record<AuthMode, string> = {
    login: 'Meet Kenyan singles. Chat beautifully.',
    signup: 'Create your RomChat account.',
    verify: 'Confirm your email.',
    forgot: 'Reset your RomChat password.',
    reset: 'Create a new password.',
  };
  const copyByMode: Record<AuthMode, string> = {
    login: 'Login to meet verified Kenyan singles in Nairobi, Mombasa, Kisumu, Eldoret, Nakuru, and beyond.',
    signup: 'Join Kenya-first romance chats with verified profiles, beautiful prompts, and safer dating tools.',
    verify: 'Enter the 6-digit code we sent to your email to unlock your RomChat profile.',
    forgot: 'Enter your email and we will send a private reset code to help you get back in.',
    reset: 'Use the reset code from your email and choose a stronger password for your account.',
  };

  async function submit() {
    setResetNotice('');
    setLocalError('');
    if (mode === 'login') return onLogin(email, password);
    if (mode === 'signup') {
      if (password !== confirmPassword) {
        setLocalError('Passwords do not match.');
        return;
      }
      await onRequestOtp(name, email, password);
      setMode('verify');
      return;
    }
    if (mode === 'forgot') {
      const message = await onForgotPassword(email);
      setResetNotice(message || 'Reset code requested. Check your email, then enter the code below.');
      setMode('reset');
      return;
    }
    if (mode === 'reset') return onResetPassword(email, otp, resetPasswordValue);
    return onVerifyOtp(email, otp);
  }

  const primaryLabel = mode === 'verify'
    ? 'Verify email'
    : mode === 'signup'
      ? 'Send email code'
      : mode === 'forgot'
        ? 'Send reset email'
        : mode === 'reset'
          ? 'Reset password'
          : 'Login';

  return (
    <SafeAreaView edges={['top', 'bottom', 'left', 'right']} style={styles.authSafe}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 8 : 0} style={styles.keyboardAvoider}>
        <ScrollView contentContainerStyle={styles.authContent} keyboardShouldPersistTaps="handled" keyboardDismissMode="interactive" automaticallyAdjustKeyboardInsets contentInsetAdjustmentBehavior="automatic" showsVerticalScrollIndicator={false}>
        <Text style={styles.authLogo}>RomChat</Text>
        <Text style={styles.authTitle}>{titleByMode[mode]}</Text>
        <Text style={styles.authCopy}>{copyByMode[mode]}</Text>
        {mode !== 'forgot' && mode !== 'reset' && (
          <TouchableOpacity disabled={!googleConfigured || busy} onPress={() => void onNativeGoogle()} style={[styles.googleButton, !googleConfigured && styles.googleButtonDisabled]}>
            <Icon name="logo-google" size={18} color="#120914" />
            <Text style={styles.googleButtonText}>{!googleConfigured ? 'Google setup pending' : busy ? 'Connecting...' : 'Continue with Google'}</Text>
          </TouchableOpacity>
        )}
        {mode !== 'forgot' && mode !== 'reset' && mode !== 'verify' && (
          <View style={styles.authTabs}>
            {(['login', 'signup'] as AuthMode[]).map((item) => (
              <TouchableOpacity key={item} onPress={() => setMode(item)} style={[styles.authTab, mode === item && styles.authTabActive]}>
                <Text style={[styles.authTabText, mode === item && styles.authTabTextActive]}>{item === 'login' ? 'Login' : 'Create'}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
        {mode === 'signup' && <TextInput value={name} onChangeText={setName} placeholder="Display name" placeholderTextColor="rgba(255,255,255,0.45)" style={styles.authInput} />}
        <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="Email address" placeholderTextColor="rgba(255,255,255,0.45)" style={styles.authInput} />
        {(mode === 'login' || mode === 'signup') && <PasswordField value={password} onChangeText={setPassword} visible={showPassword} setVisible={setShowPassword} placeholder="Password" />}
        {mode === 'signup' && <PasswordField value={confirmPassword} onChangeText={setConfirmPassword} visible={showConfirmPassword} setVisible={setShowConfirmPassword} placeholder="Confirm password" />}
        {(mode === 'verify' || mode === 'reset') && <TextInput value={otp} onChangeText={setOtp} keyboardType="number-pad" placeholder={mode === 'reset' ? 'Reset code' : '6-digit email code'} placeholderTextColor="rgba(255,255,255,0.45)" style={styles.authInput} />}
        {mode === 'reset' && <PasswordField value={resetPasswordValue} onChangeText={setResetPasswordValue} visible={showResetPassword} setVisible={setShowResetPassword} placeholder="New password" />}
        {!!resetNotice && <Text style={styles.authSuccess}>{resetNotice}</Text>}
        {!!localError && <Text style={styles.authError}>{localError}</Text>}
        <TouchableOpacity disabled={busy} onPress={() => void submit()} style={styles.authPrimary}>
          <Text style={styles.authPrimaryText}>{busy ? 'Please wait...' : primaryLabel}</Text>
        </TouchableOpacity>
        {mode === 'login' && <TouchableOpacity onPress={() => { setResetNotice(''); setMode('forgot'); }}><Text style={styles.authLink}>Forgot password?</Text></TouchableOpacity>}
        {mode === 'verify' && <TouchableOpacity onPress={() => setMode('signup')}><Text style={styles.authLink}>Edit signup details</Text></TouchableOpacity>}
        {(mode === 'forgot' || mode === 'reset') && <TouchableOpacity onPress={() => { setResetNotice(''); setMode('login'); }}><Text style={styles.authLink}>Back to login</Text></TouchableOpacity>}
        {!!error && <Text style={styles.authError}>{error}</Text>}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}


const datingIntentions = [
  'Serious relationship',
  'Life partner',
  'Marriage minded',
  'Intentional connection',
  'Long-term, open to short',
  'Short-term, open to long',
  'New friends first',
  'Slow dating',
  'Christian dating',
  'Muslim dating',
  'Single parent dating',
  'Travel romance',
  'Casual dates',
  'Still figuring it out',
];

const datingInterests = [
  'Coffee dates', 'Dinner dates', 'Brunch', 'Road trips', 'Beach weekends', 'Karura walks', 'Nairobi nightlife', 'Mombasa coast',
  'Live music', 'Afrobeats', 'Bongo', 'Amapiano', 'Sauti Sol', 'Karaoke', 'Dancing', 'Concerts',
  'Movies', 'Netflix nights', 'K-dramas', 'Comedy shows', 'Theatre', 'Photography', 'Content creation', 'Fashion',
  'Gym', 'Running', 'Hiking', 'Cycling', 'Yoga', 'Football', 'Rugby', 'Swimming', 'Wellness',
  'Cooking', 'Baking', 'Foodie', 'Street food', 'Nyama choma', 'Sushi', 'Wine tasting', 'Mocktails',
  'Travel', 'Staycations', 'Safari', 'Camping', 'Picnics', 'Sunsets', 'Lake views', 'Adventure',
  'Books', 'Poetry', 'Podcasts', 'Tech', 'Startups', 'Business', 'Investing', 'Volunteering',
  'Church', 'Mosque', 'Family time', 'Parenting', 'Pets', 'Board games', 'Gaming', 'Art galleries',
];

function PasswordField({ value, onChangeText, visible, setVisible, placeholder }: { value: string; onChangeText: (value: string) => void; visible: boolean; setVisible: (value: boolean) => void; placeholder: string }) {
  return (
    <View style={styles.passwordRow}>
      <TextInput value={value} onChangeText={onChangeText} secureTextEntry={!visible} placeholder={placeholder} placeholderTextColor="rgba(255,255,255,0.45)" style={styles.passwordInput} />
      <TouchableOpacity onPress={() => setVisible(!visible)} style={styles.passwordEye} accessibilityLabel={visible ? 'Hide password' : 'Show password'}>
        <Icon name={visible ? 'eye-off' : 'eye'} size={20} color="#FFD700" />
      </TouchableOpacity>
    </View>
  );
}

function ProfileOnboardingScreen({ busy, error, accountName, profile, uploadedImageCount, onSaveProfile, onUploadImage, onSignOut }: {
  busy: boolean;
  error: string;
  accountName: string;
  profile: RomChatMemberProfile | null;
  uploadedImageCount: number;
  onSaveProfile: (payload: { displayName: string; age: number; gender: string; city: string; intent: string; bio: string; interests: string[] }) => Promise<void>;
  onUploadImage: () => Promise<void>;
  onSignOut: () => Promise<void>;
}) {
  const initialDisplayName = profile?.displayName || accountName || '';
  const [displayName, setDisplayName] = useState(initialDisplayName);
  const [age, setAge] = useState(profile?.age ? String(profile.age) : '');
  const [gender, setGender] = useState(profile?.gender || 'female');
  const [city, setCity] = useState(profile?.city || '');
  const [intent, setIntent] = useState(profile?.intent || 'Serious relationship');
  const [bio, setBio] = useState(profile?.bio || '');
  const [selectedInterests, setSelectedInterests] = useState<string[]>(profile?.interests?.length ? profile.interests : ['Coffee dates', 'Travel', 'Live music']);
  const hasProfile = Boolean(profile);
  const imageCount = profile?.imageCount || uploadedImageCount || 0;
  const scrollRef = useRef<ScrollView | null>(null);
  const sectionYRef = useRef<Record<string, number>>({});
  const [missingSection, setMissingSection] = useState('');
  const toggleInterest = (interest: string) => setSelectedInterests((current) => current.includes(interest) ? current.filter((item) => item !== interest) : [...current, interest]);
  const rememberSection = (key: string) => (event: LayoutChangeEvent) => { sectionYRef.current[key] = event.nativeEvent.layout.y; };
  function jumpToMissing(section: string) {
    setMissingSection(section);
    const y = Math.max(0, (sectionYRef.current[section] || 0) - 16);
    requestAnimationFrame(() => scrollRef.current?.scrollTo({ y, animated: true }));
  }
  function handleSaveProfile() {
    const ageValue = Number(age);
    const requiredSections = [
      { key: 'displayName', missing: !displayName.trim() },
      { key: 'age', missing: !ageValue || ageValue < 18 },
      { key: 'gender', missing: !gender.trim() },
      { key: 'city', missing: !city.trim() },
      { key: 'intent', missing: !intent.trim() },
      { key: 'interests', missing: selectedInterests.length === 0 },
      { key: 'bio', missing: !bio.trim() },
      { key: 'image', missing: imageCount < 1 },
    ];
    const firstMissing = requiredSections.find((item) => item.missing);
    if (firstMissing) {
      jumpToMissing(firstMissing.key);
      return;
    }
    setMissingSection('');
    void onSaveProfile({ displayName, age: ageValue, gender, city, intent, bio, interests: selectedInterests });
  }
  useEffect(() => {
    if (!displayName.trim() && initialDisplayName.trim()) setDisplayName(initialDisplayName);
  }, [displayName, initialDisplayName]);
  useEffect(() => {
    if (!missingSection) return;
    const ageValue = Number(age);
    const fixed = {
      displayName: Boolean(displayName.trim()),
      age: Boolean(ageValue && ageValue >= 18),
      gender: Boolean(gender.trim()),
      city: Boolean(city.trim()),
      intent: Boolean(intent.trim()),
      interests: selectedInterests.length > 0,
      bio: Boolean(bio.trim()),
      image: imageCount >= 1,
    }[missingSection];
    if (fixed) setMissingSection('');
  }, [age, bio, city, displayName, gender, imageCount, intent, missingSection, selectedInterests.length]);

  return (
    <SafeAreaView edges={['top', 'bottom', 'left', 'right']} style={styles.authSafe}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 8 : 0} style={styles.keyboardAvoider}>
        <ScrollView ref={scrollRef} contentContainerStyle={[styles.authContent, styles.authContentTop]} keyboardShouldPersistTaps="handled" keyboardDismissMode="interactive" automaticallyAdjustKeyboardInsets contentInsetAdjustmentBehavior="automatic" showsVerticalScrollIndicator={false}>
        <Text style={styles.authLogo}>RomChat</Text>
        <Text style={styles.authTitle}>{hasProfile ? 'Add your first photo' : 'Create your Kenyan dating profile'}</Text>
        <Text style={styles.authCopy}>Upload at least 1 image to enter Kenyan discovery. More uploaded images unlock more of other members' photo catalogues.</Text>
        <View onLayout={rememberSection('displayName')}><TextInput value={displayName} onChangeText={setDisplayName} placeholder="Display name" placeholderTextColor="rgba(255,255,255,0.45)" style={[styles.authInput, missingSection === 'displayName' && styles.inputMissing]} /></View>
        <View onLayout={rememberSection('age')}><TextInput value={age} onChangeText={setAge} keyboardType="number-pad" placeholder="Age" placeholderTextColor="rgba(255,255,255,0.45)" style={[styles.authInput, missingSection === 'age' && styles.inputMissing]} /></View>
        <View onLayout={rememberSection('gender')} style={[styles.genderRow, missingSection === 'gender' && styles.sectionMissing]}>{['female', 'male'].map((item) => <TouchableOpacity key={item} onPress={() => setGender(item)} style={[styles.genderChip, gender === item && styles.genderChipActive]}><Text style={[styles.genderText, gender === item && styles.genderTextActive]}>{item}</Text></TouchableOpacity>)}</View>
        <View onLayout={rememberSection('city')}><TextInput value={city} onChangeText={setCity} placeholder="City" placeholderTextColor="rgba(255,255,255,0.45)" style={[styles.authInput, missingSection === 'city' && styles.inputMissing]} /></View>
        <View onLayout={rememberSection('intent')}><Text style={[styles.selectorTitle, missingSection === 'intent' && styles.selectorTitleMissing]}>Dating intention in Kenya</Text>
        <View style={styles.choiceWrap}>{datingIntentions.map((item) => <TouchableOpacity key={item} onPress={() => setIntent(item)} style={[styles.choiceChip, intent === item && styles.choiceChipActive]}><Text style={[styles.choiceText, intent === item && styles.choiceTextActive]}>{item}</Text></TouchableOpacity>)}</View></View>
        <View onLayout={rememberSection('interests')}><Text style={[styles.selectorTitle, missingSection === 'interests' && styles.selectorTitleMissing]}>Interests and vibe signals</Text>
        <View style={styles.choiceWrap}>{datingInterests.map((item) => { const active = selectedInterests.includes(item); return <TouchableOpacity key={item} onPress={() => toggleInterest(item)} style={[styles.choiceChip, active && styles.choiceChipActive]}><Text style={[styles.choiceText, active && styles.choiceTextActive]}>{item}</Text></TouchableOpacity>; })}</View></View>
        <View onLayout={rememberSection('bio')}><TextInput value={bio} onChangeText={setBio} placeholder="Short Kenyan romance bio" placeholderTextColor="rgba(255,255,255,0.45)" style={[styles.authInput, styles.authTextArea, missingSection === 'bio' && styles.inputMissing]} multiline /></View>
        <TouchableOpacity onLayout={rememberSection('image')} disabled={busy} onPress={() => void onUploadImage()} style={[styles.uploadCard, missingSection === 'image' && styles.uploadCardMissing]}>
          <Icon name="image" size={24} color="#FFD700" />
          <View style={{ flex: 1 }}><Text style={styles.uploadTitle}>{imageCount ? String(imageCount) + ' image uploaded' : 'Upload first profile image'}</Text><Text style={styles.uploadMeta}>{missingSection === 'image' ? 'Add at least one photo before saving.' : 'Private RomChat photo gallery'}</Text></View>
        </TouchableOpacity>
        {!!missingSection && <Text style={styles.validationNudge}>Finish this highlighted section to continue.</Text>}
        <TouchableOpacity disabled={busy} onPress={handleSaveProfile} style={styles.authPrimary}>
          <Text style={styles.authPrimaryText}>Save profile</Text>
        </TouchableOpacity>
        {!!error && <Text style={styles.authError}>{error}</Text>}
        <TouchableOpacity onPress={() => void onSignOut()}><Text style={styles.authLink}>Use another account</Text></TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function ScreenHeader({ title, onBack, apiOnline }: { title: string; onBack: () => void; apiOnline: boolean }) {
  return (
    <View style={styles.screenHeader}>
      <TouchableOpacity onPress={onBack} style={styles.backButton}><Icon name="chevron-back" size={20} color="#FFFFFF" /></TouchableOpacity>
      <Text style={styles.screenTitle}>{title}</Text>
      <Text style={styles.apiPill}>{apiOnline ? 'Live' : 'Local'}</Text>
    </View>
  );
}

function Discover({
  profile,
  passProfile,
  likeProfile,
  topProfile,
  previous,
  swipeHandlers,
  swipeCardStyle,
  showMatch,
  dismissMatch,
  openChat,
  profiles,
  cardHeight,
}: {
  profile: ProfileSeed;
  passProfile: () => void;
  likeProfile: () => void;
  topProfile: () => void;
  previous: () => void;
  swipeHandlers: GestureResponderHandlers;
  swipeCardStyle: object;
  showMatch: boolean;
  dismissMatch: () => void;
  openChat: () => void;
  profiles: ProfileSeed[];
  cardHeight: number;
}) {
  const [photoIndex, setPhotoIndex] = useState(0);
  const [galleryNotice, setGalleryNotice] = useState('');
  const popScale = useRef(new Animated.Value(0.82)).current;
  const popOpacity = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!showMatch) return;
    popScale.setValue(0.82);
    popOpacity.setValue(0);
    Animated.parallel([
      Animated.spring(popScale, { toValue: 1, friction: 5, tension: 160, useNativeDriver: true }),
      Animated.timing(popOpacity, { toValue: 1, duration: 180, useNativeDriver: true }),
    ]).start();
  }, [popOpacity, popScale, showMatch]);
  useEffect(() => {
    setPhotoIndex(0);
    setGalleryNotice('');
  }, [profile.id]);
  const openers = [`Ask ${profile.name} about ${profile.tags[0]?.toLowerCase() || 'her vibe'}.`, `Start with: "${profile.poll.question}"`];
  const remotePhotos = (profile.photos || []).map((url) => ({ uri: resolveMediaUrl(url) })).filter((item) => Boolean(item.uri));
  const photoSlots = remotePhotos.length ? remotePhotos : [profile.photo];
  const totalGallery = Number(profile.fullGallery || profile.gallery || photoSlots.length);
  const changePhoto = (direction: -1 | 1) => setPhotoIndex((value) => {
    if (direction > 0 && value >= photoSlots.length - 1 && totalGallery > photoSlots.length) {
      setGalleryNotice('Add more of your own photos to unlock the rest of this gallery.');
      return value;
    }
    setGalleryNotice('');
    return (value + direction + photoSlots.length) % photoSlots.length;
  });

  return (
    <View style={styles.discovery}>
      <Animated.View style={[styles.deckShadow, swipeCardStyle]} {...swipeHandlers}>
        <ImageBackground source={photoSlots[photoIndex]} resizeMode="cover" style={[styles.profileCard, { height: cardHeight, minHeight: cardHeight }]} imageStyle={styles.profilePhoto}>
          <LinearGradient colors={['rgba(255,255,255,0.10)', 'rgba(255,255,255,0.02)', 'rgba(18,9,20,0.74)']} locations={[0, 0.52, 1]} style={styles.photoOverlay} />
          <View style={styles.photoDots}>
            {photoSlots.map((_, itemIndex) => (
              <View key={itemIndex} style={[styles.photoDot, itemIndex === photoIndex && styles.photoDotActive]} />
            ))}
          </View>
          <View style={styles.tapZones}>
            <TouchableOpacity onPress={() => changePhoto(-1)} style={styles.tapZone} accessibilityLabel="Previous photo" />
            <TouchableOpacity onPress={() => changePhoto(1)} style={styles.tapZone} accessibilityLabel="Next photo" />
          </View>
          {!!galleryNotice && (
            <View style={styles.galleryLockNotice}>
              <Icon name="images" size={17} color="#FFD700" />
              <Text style={styles.galleryLockText}>{galleryNotice}</Text>
            </View>
          )}
          <View style={styles.cardCopy}>
            <View style={styles.pillRow}>
              <Text style={styles.cardBadge}>{profile.match}%</Text>
              <Text style={styles.verifiedBadge}>Active</Text>
            </View>
            <Text style={styles.cardTitle}>{profile.name} <Text style={styles.cardAge}>{profile.age}</Text></Text>
            <Text style={styles.cardSub}>{profile.city} - Kenya{typeof profile.distanceKm === 'number' && profile.distanceKm > 0 ? ` - ${profile.distanceKm} km away` : ''}</Text>
            <Text numberOfLines={2} style={styles.cardPrompt}>{profile.prompt}</Text>
            <View style={styles.tagRow}>{profile.tags.slice(0, 3).map((tag) => <Text key={tag} style={styles.photoTag}>{tag}</Text>)}</View>
          </View>
          <View style={styles.actionDock}>
            <View style={styles.actionItem}>
              <TouchableOpacity onPress={previous} style={styles.rewindAction} accessibilityLabel="Undo swipe"><Icon name="return-up-back" size={18} color="#C9C3CB" /></TouchableOpacity>
            </View>
            <View style={styles.actionItem}>
              <TouchableOpacity onPress={passProfile} style={styles.passAction} accessibilityLabel="Pass profile"><Icon name="close" size={30} color="#FFFFFF" /></TouchableOpacity>
            </View>
            <View style={styles.actionItem}>
              <TouchableOpacity onPress={topProfile} style={styles.topAction} accessibilityLabel="Open Platinum"><Icon name="diamond" size={21} color="#9BC6FF" /></TouchableOpacity>
            </View>
            <View style={styles.actionItem}>
              <TouchableOpacity onPress={likeProfile} style={styles.likeAction} accessibilityLabel="Like profile"><Icon name="heart" size={30} color="#FF1200" /></TouchableOpacity>
            </View>
            <View style={styles.actionItem}>
              <TouchableOpacity onPress={openChat} style={styles.messageAction} accessibilityLabel="Message match"><Icon name="paper-plane" size={21} color="#9BC6FF" /></TouchableOpacity>
            </View>
          </View>
        </ImageBackground>
      </Animated.View>

      {showMatch && (
        <Animated.View pointerEvents="box-none" style={[styles.matchPopOverlay, { opacity: popOpacity, transform: [{ scale: popScale }] }]}>
        <LinearGradient colors={['#120914', '#FF1493']} style={styles.matchSheet}>
          <View style={styles.matchAvatarPair}>
            <Image source={require('../assets/icon.png')} style={styles.matchAvatarLarge} />
            <Image source={photoSlots[0]} style={[styles.matchAvatarLarge, styles.matchAvatarOverlap]} />
            <View style={styles.floatingHeart}><Icon name="heart" size={18} color="#FFFFFF" /></View>
          </View>
          <Text style={styles.matchKicker}>Ni match</Text>
          <Text style={styles.matchTitle}>You and {profile.name} both felt the Kenyan vibe</Text>
          {openers.map((item) => <Text key={item} style={styles.matchPrompt}>{item}</Text>)}
          <View style={styles.matchActions}>
            <TouchableOpacity onPress={dismissMatch} style={styles.matchSecondary}><Text style={styles.matchSecondaryText}>Keep swiping</Text></TouchableOpacity>
            <TouchableOpacity onPress={openChat} style={styles.matchPrimary}><Text style={styles.matchPrimaryText}>Send a Kenyan romantic intro - 5 tokens</Text></TouchableOpacity>
          </View>
        </LinearGradient>
        </Animated.View>
      )}
    </View>
  );
}

function ShortcutRail({ setActiveSection }: { setActiveSection: (section: Section) => void }) {
  return (
    <View style={styles.shortcutRail}>
      {shortcuts.map((item) => (
        <TouchableOpacity key={item.id} onPress={() => setActiveSection(item.id)} style={styles.shortcut}>
          <Text style={styles.shortcutLabel}>{item.label}</Text>
          <Text style={styles.shortcutTitle}>{item.title}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

function FooterNav({ active, setActiveSection, openSwipeDeck, bottomInset, chatBadgeCount, likesReceivedCount }: { active: Section | 'swipe'; setActiveSection: (section: Section | null) => void; openSwipeDeck: () => void; bottomInset: number; chatBadgeCount: number; likesReceivedCount: number }) {
  const chatBadge = chatBadgeCount > 0 ? (chatBadgeCount > 99 ? '99+' : String(chatBadgeCount)) : undefined;
  const likesBadge = likesReceivedCount > 0 ? (likesReceivedCount > 99 ? '99+' : String(likesReceivedCount)) : undefined;
  const items: Array<{ key: Section | 'swipe'; label: string; icon: string; target: Section | null; badge?: string }> = [
    { key: 'swipe', label: 'Swipe', icon: 'flame', target: null },
    { key: 'explore', label: 'Explore', icon: 'compass', target: 'explore' },
    { key: 'likes', label: 'Likes', icon: 'heart-outline', target: 'likes', badge: likesBadge },
    { key: 'chat', label: 'Chat', icon: 'chatbubble', target: 'chat', badge: chatBadge },
    { key: 'profile', label: 'Profile', icon: 'person-outline', target: 'profile' },
  ];
  return (
    <View style={[styles.footerNav, { paddingBottom: Math.max(bottomInset, 12), minHeight: 64 + Math.max(bottomInset, 12) }]}>
      {items.map((item) => {
        const selected = active === item.key;
        return (
          <TouchableOpacity key={item.key} onPress={() => item.key === 'swipe' ? openSwipeDeck() : setActiveSection(item.target)} style={styles.footerItem} accessibilityLabel={item.label}>
            <View>
              <Icon name={item.icon} size={21} color={selected ? '#FFFFFF' : 'rgba(255,255,255,0.62)'} />
              {!!item.badge && <Text style={styles.footerBadge}>{item.badge}</Text>}
            </View>
            <Text style={[styles.footerLabel, selected && styles.footerLabelActive]}>{item.label}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

function ExploreScreen({ openLikes }: { openLikes: () => void }) {
  const tiles: Array<[string, string, string, string]> = [
    ['Long-term partner', 'rose', '1K', '#FF1493'],
    ['Serious commitment', 'diamond', '614', '#F472B6'],
    ['Binge watchers', 'tv', '334', '#FF6F61'],
    ['Sporty', 'fitness', '299', '#60A5FA'],
    ['Coast weekends', 'sunny', '528', '#FFD700'],
    ['Soft romance', 'moon', '487', '#9BC6FF'],
  ];
  return (
    <View>
      <Text style={styles.exploreTitle}>Explore romance vibes</Text>
      <View style={styles.exploreGrid}>
        {tiles.map(([label, icon, count, color]) => (
          <TouchableOpacity key={label} onPress={openLikes} style={styles.exploreTile}>
            <Icon name={icon} size={44} color={color} />
            <View style={styles.exploreTileFooter}>
              <Text style={styles.exploreTileTitle}>{label}</Text>
              <Text style={styles.exploreTileCount}>{count}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

function LikesScreen({ profiles, likesReceivedCount, likesSummary, activePlan, openPremium, openSuperLikes, openChat, acceptLikeAndOpenChat, passLikeProfile, messageGoldMatch, likeProfile, passProfile, onAllLikesSeenChange }: {
  profiles: ProfileSeed[]; likesReceivedCount: number; likesSummary: { receivedCount?: number; sentCount?: number; sentProfileIds?: string[]; topPickProfileIds?: string[] }; activePlan: PlanName; openPremium: () => void; openSuperLikes: () => void; openChat: () => void; acceptLikeAndOpenChat: (profileId: string) => void; passLikeProfile: (profileId: string) => void; messageGoldMatch: (profileId: string, text: string) => void; likeProfile: () => void; passProfile: () => void; onAllLikesSeenChange: (seen: boolean) => void }) {
  const [tab, setTab] = useState<'received' | 'sent' | 'top'>('received');
  const [revealedLikeId, setRevealedLikeId] = useState<string | null>(null);
  const [expandedLikeId, setExpandedLikeId] = useState<string | null>(null);
  const [likedChatProfile, setLikedChatProfile] = useState<ProfileSeed | null>(null);
  const [goldChatDraft, setGoldChatDraft] = useState('');
  const [dismissedLikeIds, setDismissedLikeIds] = useState<string[]>([]);
  const [nextDropCountdown, setNextDropCountdown] = useState(() => formatNextLikeDropCountdown());
  const hasGoldAccess = activePlan === 'Gold' || activePlan === 'Platinum';
  const sentIds = new Set(likesSummary.sentProfileIds || []);
  const topIds = new Set(likesSummary.topPickProfileIds || []);
  const sentProfiles = profiles.filter((profile) => sentIds.has(profile.id));
  const topPicks = profiles.filter((profile) => topIds.has(profile.id));
  const fallbackTopPicks = profiles.filter((profile) => profile.match >= 88).slice(0, 6);
  const dismissedLikeIdSet = new Set(dismissedLikeIds);
  const admirerProfiles = profiles.filter((profile) => !sentIds.has(profile.id) && !dismissedLikeIdSet.has(profile.id)).slice(0, 8);
  const dailyGoldMatch = admirerProfiles[0] || null;
  const topPickList = (topPicks.length ? topPicks : fallbackTopPicks).slice(0, 6);
  const sentList = (sentProfiles.length ? sentProfiles : profiles.slice(0, 4)).slice(0, 8);
  const likesLabel = likesReceivedCount > 99 ? '99+' : String(Math.max(likesReceivedCount, admirerProfiles.length));
  const tabText = tab === 'received' ? `${likesLabel} Likes` : tab === 'sent' ? 'Likes Sent' : 'Top Picks';

  useEffect(() => {
    const timer = setInterval(() => setNextDropCountdown(formatNextLikeDropCountdown()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    onAllLikesSeenChange(tab === 'received' && hasGoldAccess);
  }, [hasGoldAccess, onAllLikesSeenChange, tab]);

  function revealDailyLike() {
    if (!dailyGoldMatch) return;
    if (revealedLikeId || hasGoldAccess) {
      setExpandedLikeId(dailyGoldMatch.id);
      return;
    }
    setRevealedLikeId(dailyGoldMatch.id);
    setExpandedLikeId(dailyGoldMatch.id);
  }
  function acceptDailyLike() {
    if (!dailyGoldMatch) return;
    setDismissedLikeIds((current) => current.includes(dailyGoldMatch.id) ? current : [...current, dailyGoldMatch.id]);
    setRevealedLikeId(null);
    setExpandedLikeId(null);
    setLikedChatProfile(dailyGoldMatch);
    acceptLikeAndOpenChat(dailyGoldMatch.id);
    openChat();
  }

  function sendGoldIntro() {
    if (!likedChatProfile || !goldChatDraft.trim()) return;
    const text = goldChatDraft.trim();
    setGoldChatDraft('');
    messageGoldMatch(likedChatProfile.id, text);
    setLikedChatProfile(null);
  }

  function passDailyLike() {
    if (!dailyGoldMatch) return;
    setDismissedLikeIds((current) => current.includes(dailyGoldMatch.id) ? current : [...current, dailyGoldMatch.id]);
    setRevealedLikeId(null);
    setExpandedLikeId(null);
    passLikeProfile(dailyGoldMatch.id);
  }
  function superLikeUpsell() {
    openSuperLikes();
  }

  return (
    <View>
      <View style={styles.likesTabs}>
        <TouchableOpacity onPress={() => setTab('received')} style={styles.likesTabButton}><Text style={tab === 'received' ? styles.likesTabActive : styles.likesTab}>{likesLabel} Likes</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => setTab('sent')} style={styles.likesTabButton}><View style={styles.likesTabWithDot}><Text style={tab === 'sent' ? styles.likesTabActive : styles.likesTab}>Likes Sent</Text><Icon name="star" size={12} color="#9BC6FF" /></View></TouchableOpacity>
        <TouchableOpacity onPress={() => setTab('top')} style={styles.likesTabButton}><Text style={tab === 'top' ? styles.likesTabActive : styles.likesTab}>Top Picks</Text></TouchableOpacity>
      </View>
      <Text style={styles.likesScreenTitle}>{tabText}</Text>

      {tab === 'received' && (
        <View>
          <Text style={styles.likesSectionTitle}>Free Likes</Text>
          <LinearGradient colors={["#5A0034", "#38001F"]} style={styles.freeLikeDrop}>
            <Text style={styles.freeLikePill}>Next drop is in</Text>
            <Text style={styles.freeLikeTimer}>{nextDropCountdown}</Text>
            <Text style={styles.freeLikeCopy}>One Like is free to review each day. Accept to match and message, or pass to keep browsing.</Text>
          </LinearGradient>
          <Text style={styles.likesSectionTitle}>Gold Match</Text>
          {dailyGoldMatch ? <GoldMatchCard profile={dailyGoldMatch} revealed={revealedLikeId === dailyGoldMatch.id || hasGoldAccess} expanded={expandedLikeId === dailyGoldMatch.id} onReveal={revealDailyLike} onOpenProfile={() => setExpandedLikeId(dailyGoldMatch.id)} onAccept={acceptDailyLike} onPass={passDailyLike} /> : <View style={styles.emptyThreadCard}><Text style={styles.emptyThreadTitle}>No free Like waiting</Text><Text style={styles.emptyThreadText}>You reviewed today's free Like. The next one drops when the timer reaches zero.</Text></View>}
          <Text style={styles.likesSectionTitle}>Everyone else who's into you</Text>
          <View style={styles.likesGrid}>
            {admirerProfiles.slice(1, 7).map((profile, index) => <BlurredLikeCard key={profile.id} profile={profile} onPress={openPremium} index={index} />)}
          </View>
          <TouchableOpacity onPress={openPremium} style={styles.likesUnlockButton}><Text style={styles.likesUnlockText}>See All Your Likes Now</Text></TouchableOpacity>
        </View>
      )}

      {tab === 'sent' && (
        <View>
          <Text style={styles.likesSectionTitle}>Profiles you liked</Text>
          <Text style={styles.likesSubcopy}>Tap a starred profile to Super Like and get pushed faster in their queue.</Text>
          <View style={styles.likesGrid}>
            {sentList.map((profile) => <SentLikeCard key={profile.id} profile={profile} onPress={superLikeUpsell} />)}
          </View>
        </View>
      )}

      {tab === 'top' && (
        <View>
          <Text style={styles.topPickHeadline}>{hasGoldAccess ? 'Your best Kenyan picks today' : 'Upgrade to RomChat Gold for more Top Picks!'}</Text>
          <View style={styles.topPickGrid}>
            {topPickList.slice(0, hasGoldAccess ? 6 : 2).map((profile, index) => <TopPickCard key={profile.id} profile={profile} locked={!hasGoldAccess && index === 0} onPress={hasGoldAccess ? likeProfile : openPremium} />)}
          </View>
          <TouchableOpacity onPress={openPremium} style={styles.topPickUnlockButton}><Text style={styles.topPickUnlockText}>{hasGoldAccess ? 'Refresh Top Picks' : 'Unlock all Top Picks'}</Text></TouchableOpacity>
        </View>
      )}
    </View>
  );
}

function formatNextLikeDropCountdown() {
  const nowDate = new Date();
  const nextDrop = new Date(nowDate);
  nextDrop.setHours(24, 0, 0, 0);
  const totalSeconds = Math.max(0, Math.floor((nextDrop.getTime() - nowDate.getTime()) / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${hours}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`;
}

function GoldMatchCard({ profile, revealed, expanded, onReveal, onOpenProfile, onAccept, onPass }: { profile: ProfileSeed; revealed: boolean; expanded: boolean; onReveal: () => void; onOpenProfile: () => void; onAccept: () => void; onPass: () => void }) {
  const gallery = profile.photos?.length ? profile.photos.map((photo) => ({ uri: resolveMediaUrl(photo) })) : [profile.photo];
  const [photoIndex, setPhotoIndex] = useState(0);
  const [viewerOpen, setViewerOpen] = useState(false);
  const photo = gallery[photoIndex % gallery.length] || profile.photo;
  const visibleName = revealed ? profile.name : 'Someone';
  useEffect(function () { setPhotoIndex(0); }, [profile.id]);
  function movePhoto(direction: number) { if (!revealed || gallery.length < 2) return; setPhotoIndex(function (current) { return (current + direction + gallery.length) % gallery.length; }); }
  const fullPhotoPanResponder = PanResponder.create({
    onMoveShouldSetPanResponder: function (_event, gesture) { return Math.abs(gesture.dx) > 18 && Math.abs(gesture.dx) > Math.abs(gesture.dy); },
    onPanResponderRelease: function (_event, gesture) {
      if (gesture.dx < -35) movePhoto(1);
      if (gesture.dx > 35) movePhoto(-1);
    },
  });
  return (
    <View style={[styles.goldMatchShell, expanded && styles.goldMatchShellExpanded]}>
      <Modal visible={viewerOpen} animationType='fade' transparent onRequestClose={function () { setViewerOpen(false); }}><View style={styles.fullPhotoViewer} {...fullPhotoPanResponder.panHandlers}><Image source={photo} resizeMode='contain' style={styles.fullPhotoImage} /><TouchableOpacity onPress={function () { setViewerOpen(false); }} style={styles.fullPhotoClose}><Icon name='close' size={30} color='#FFFFFF' /></TouchableOpacity></View></Modal>
      <TouchableOpacity activeOpacity={revealed ? 0.96 : 1} onPress={revealed ? function () { setViewerOpen(true); } : undefined} style={styles.goldMatchTouch}>
      <ImageBackground source={photo} resizeMode="cover" blurRadius={revealed ? 0 : 18} style={[styles.goldMatchCard, expanded && styles.goldMatchCardExpanded]} imageStyle={styles.goldMatchImage}>
        <LinearGradient colors={["rgba(0,0,0,0.05)", "rgba(0,0,0,0.72)"]} style={styles.photoOverlay} />
        <View style={styles.goldMatchBadge}><Icon name="star" size={15} color="#120914" /><Text style={styles.goldMatchBadgeText}>Today's free Like</Text></View>
        {revealed && gallery.length > 1 && <TouchableOpacity onPress={function () { movePhoto(-1); }} style={[styles.goldPhotoArrow, styles.goldPhotoArrowLeft]}><Icon name='chevron-back' size={20} color='#FFFFFF' /></TouchableOpacity>}
        {revealed && gallery.length > 1 && <TouchableOpacity onPress={function () { movePhoto(1); }} style={[styles.goldPhotoArrow, styles.goldPhotoArrowRight]}><Icon name='chevron-forward' size={20} color='#FFFFFF' /></TouchableOpacity>}
        <View style={styles.goldMatchFooter}>
          <Text style={styles.goldMatchName}>{visibleName} <Text style={styles.cardAge}>{profile.age}</Text></Text>
          <Text style={styles.goldMatchMeta}>{profile.online ? 'Recently Active' : `${profile.city} vibe`}</Text>
          {expanded && revealed && (
            <View style={styles.goldExpandedPanel}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.goldExpandedGallery}>
                {gallery.map((item, index) => <Image key={`${profile.id}-like-photo-${index}`} source={item} style={styles.goldExpandedPhoto} />)}
              </ScrollView>
              <Text numberOfLines={2} style={styles.goldExpandedBio}>{profile.prompt || `A little more about ${profile.name}`}</Text>
              <View style={styles.goldExpandedTags}>{profile.tags.slice(0, 3).map((tag) => <Text key={tag} style={styles.goldExpandedTag}>{tag}</Text>)}</View>
            </View>
          )}
          {revealed ? (
            <View style={styles.goldMatchActions}>
              <TouchableOpacity onPress={onPass} style={styles.goldPassButton} accessibilityLabel="Pass this like"><Icon name="close" size={29} color="#FFFFFF" /></TouchableOpacity>
              <TouchableOpacity onPress={onAccept} style={styles.goldAcceptIconButton} accessibilityLabel="Like back and message"><Icon name="heart" size={30} color="#FF1200" /></TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity onPress={onReveal} style={styles.goldRevealButton}><Text style={styles.goldRevealText}>Reveal free Like</Text></TouchableOpacity>
          )}
        </View>
      </ImageBackground>
      </TouchableOpacity>
    </View>
  );
}

function BlurredLikeCard({ profile, onPress, index }: { profile: ProfileSeed; onPress: () => void; index: number }) {
  const photo = profile.photos?.[0] ? { uri: resolveMediaUrl(profile.photos[0]) } : profile.photo;
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.9} style={styles.blurredLikeCard}>
      <ImageBackground source={photo} resizeMode="cover" blurRadius={18} style={styles.blurredLikeImage} imageStyle={styles.blurredLikeImageRadius}>
        <LinearGradient colors={["rgba(255,255,255,0.10)", "rgba(0,0,0,0.70)"]} style={styles.photoOverlay} />
        <View style={styles.blurredNamePill} />
        <Text style={styles.blurredAge}>{profile.age + index % 3}</Text>
        <Text style={styles.blurredMeta}>{profile.online ? 'Recently Active' : `${Math.max(3, Math.round(profile.distanceKm || 9))} miles away`}</Text>
      </ImageBackground>
    </TouchableOpacity>
  );
}

function SentLikeCard({ profile, onPress }: { profile: ProfileSeed; onPress: () => void }) {
  const photo = profile.photos?.[0] ? { uri: resolveMediaUrl(profile.photos[0]) } : profile.photo;
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.9} style={styles.sentLikeCard}>
      <ImageBackground source={photo} resizeMode="cover" style={styles.sentLikeImage} imageStyle={styles.blurredLikeImageRadius}>
        <LinearGradient colors={["rgba(0,0,0,0.06)", "rgba(0,0,0,0.78)"]} style={styles.photoOverlay} />
        <View style={styles.sentStar}><Icon name="star" size={20} color="#9BC6FF" /></View>
        <Text style={styles.sentLikeName}>{profile.name}, {profile.age}</Text>
        <Text style={styles.sentLikeMeta}>Boost this Like</Text>
      </ImageBackground>
    </TouchableOpacity>
  );
}

function TopPickCard({ profile, locked, onPress }: { profile: ProfileSeed; locked: boolean; onPress: () => void }) {
  const photo = profile.photos?.[0] ? { uri: resolveMediaUrl(profile.photos[0]) } : profile.photo;
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.9} style={styles.topPickCard}>
      <ImageBackground source={photo} resizeMode="cover" blurRadius={locked ? 14 : 0} style={styles.topPickImage} imageStyle={styles.topPickImageRadius}>
        <LinearGradient colors={["rgba(0,0,0,0.05)", "rgba(0,0,0,0.72)"]} style={styles.photoOverlay} />
        {locked && <View style={styles.topPickSilhouette}><Icon name="person" size={66} color="#FFFFFF" /></View>}
        <View style={styles.topPickFooter}>
          <Text style={styles.topPickName}>{locked ? 'Mystery Pick' : profile.name}, {profile.age}</Text>
          <Text style={styles.topPickTime}>24h left</Text>
        </View>
        <View style={styles.topPickStar}><Icon name="star" size={20} color="#9BC6FF" /></View>
      </ImageBackground>
    </TouchableOpacity>
  );
}

function EmptyDiscovery({ openProfile, status }: { openProfile: () => void; status: string }) {
  return (
    <View style={styles.emptyDiscovery}>
      <Icon name="heart-circle" size={52} color="#FF1493" />
      <Text style={styles.emptyDiscoveryTitle}>Finding Kenyan profiles</Text>
      <Text style={styles.emptyDiscoveryText}>{status === 'Live API connected' || status === 'Distance preferences applied' ? 'No profiles match your current filters yet. Open your profile, widen distance, or refresh after more members upload photos.' : 'Refreshing the RomChat backend. If this stays here, check the backend URL and try again.'}</Text>
      <TouchableOpacity onPress={openProfile} style={styles.emptyDiscoveryButton}><Text style={styles.emptyDiscoveryButtonText}>Improve my profile</Text></TouchableOpacity>
    </View>
  );
}

function HomeNudge({ profile, openProfile, status }: { profile: ProfileSeed; openProfile: () => void; status: string }) {
  return (
    <TouchableOpacity onPress={openProfile} style={styles.homeNudge}>
      <View style={{ flex: 1 }}>
        <Text style={styles.kicker}>{status}</Text>
        <Text style={styles.nudgeTitle}>{profile.name} likes thoughtful openers</Text>
      </View>
      <Text style={styles.nudgeAction}>View</Text>
    </TouchableOpacity>
  );+++++++++++++++++++++++++++++++.
}
+
function Chat({ profiles, sendMessage, getMessages, reportMessage, currentUserId, initialProfileId, goldMatchProfileIds, onInitialProfileHandled, status }: {
  profiles: ProfileSeed[];
  sendMessage: (text: string, matchId?: string, options?: { mode?: 'standard'; readReceiptRequested?: boolean }) => Promise<unknown>;
  getMessages: (matchId: string) => Promise<Array<{ id: string; senderId?: string; from?: string; text: string; createdAt?: string }>>;
  reportMessage: (payload: {
    profileId: string;
    reportedMemberId?: string;
    matchId?: string;
    messageId?: string;
    text?: string;
    senderId?: string;
    moderation?: unknown;
    reporterNote?: string;
  }) => Promise<boolean>;
  currentUserId: string;
  initialProfileId?: string | null;
  goldMatchProfileIds?: string[];
  onInitialProfileHandled?: () => void;
  status: string;
}) {
  const goldMatchIdSet = new Set(goldMatchProfileIds || []);
  const matchPool = profiles
    .filter((profile) => Boolean(profile.matchId) || goldMatchIdSet.has(profile.id))
    .map((profile) => goldMatchIdSet.has(profile.id) && !profile.matchId ? { ...profile, matchId: `match_${profile.id}`, online: profile.online !== false } : profile);
  const onlineMatches = matchPool.filter((profile) => profile.online === true);
  const orderedMatches = [
    ...matchPool.filter((profile) => goldMatchIdSet.has(profile.id)),
    ...onlineMatches.filter((profile) => !goldMatchIdSet.has(profile.id)),
    ...matchPool.filter((profile) => profile.online !== true && !goldMatchIdSet.has(profile.id)),
  ].filter((profile, index, all) => all.findIndex((item) => item.id === profile.id) === index);
  const [draft, setDraft] = useState('');
  const [query, setQuery] = useState('');
  const [threadMessages, setThreadMessages] = useState<Record<string, Array<{ id: string; from: 'You' | 'Them'; text: string; status: string }>>>({});
  const [contactWarnings, setContactWarnings] = useState<Record<string, boolean>>({});
  const [pendingContactText, setPendingContactText] = useState('');
  const [selectedMatchId, setSelectedMatchId] = useState<string | null>(null);
  const [blockedMatchIds, setBlockedMatchIds] = useState<string[]>([]);
  const [safetyWarning, setSafetyWarning] = useState<{ text: string; categories: string[] } | null>(null);
  const selectedMatch = orderedMatches.find((profile) => profile.id === selectedMatchId) || null;
  const visibleThreads = orderedMatches.filter((profile) => `${profile.name} ${profile.city} ${profile.intent} ${profile.tags.join(' ')}`.toLowerCase().includes(query.trim().toLowerCase()));
  const promptChips = selectedMatch ? [`Ask ${selectedMatch.name} about ${selectedMatch.tags[0] || 'her vibe'}`, 'Coffee this weekend?', 'How has your day been?'] : [];
  const activePhoto = selectedMatch?.photos?.[0] ? { uri: resolveMediaUrl(selectedMatch.photos[0]) } : selectedMatch?.photo || require('../assets/icon.png');
  const selectedMessages = selectedMatch ? threadMessages[selectedMatch.id] || [] : [];
  const selectedMatchBlocked = selectedMatch ? blockedMatchIds.includes(selectedMatch.id) : false;

  useEffect(() => {
    if (!initialProfileId) return;
    const target = orderedMatches.find((profile) => profile.id === initialProfileId);
    if (!target) return;
    setSelectedMatchId(target.id);
    onInitialProfileHandled?.();
  }, [initialProfileId, orderedMatches, onInitialProfileHandled]);

  function looksLikeContactShare(textValue: string) {
    return /(\+?\d[\d\s().-]{6,}\d)|([\w.%+-]+@[\w.-]+\.[A-Za-z]{2,})|(whats\s*app|telegram|snapchat|instagram|ig\b|@\w{3,})/i.test(textValue);
  }

  function appendLocalMessage(profileId: string, textValue: string) {
    setThreadMessages((current) => ({
      ...current,
      [profileId]: [...(current[profileId] || []), { id: `local_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`, from: 'You', text: textValue, status: 'Delivered' }],
    }));
  }

  function deliverMessage(textValue: string) {
    if (!selectedMatch) return;
    appendLocalMessage(selectedMatch.id, textValue);
    void sendMessage(textValue, selectedMatch.matchId || `match_${selectedMatch.id}`, { mode: 'standard', readReceiptRequested: false });
  }

  function sendChatText(textValue: string) {
    const clean = textValue.trim();
    if (!clean || !selectedMatch) return;
    if (looksLikeContactShare(clean) && !contactWarnings[selectedMatch.id]) {
      setPendingContactText(clean);
      return;
    }
    deliverMessage(clean);
  }

  function cancelContactShare() {
    setPendingContactText('');
  }

  function confirmContactShare() {
    if (!selectedMatch || !pendingContactText) return;
    const textToSend = pendingContactText;
    setPendingContactText('');
    setContactWarnings((current) => ({ ...current, [selectedMatch.id]: true }));
    deliverMessage(textToSend);
  }

  function submit() {
    const textValue = draft.trim();
    if (!textValue || !selectedMatch) return;
    setDraft('');
    sendChatText(textValue);
  }

  useEffect(() => {
    if (!selectedMatch?.matchId) return;
    let mounted = true;
    void getMessages(selectedMatch.matchId)
      .then((messages) => {
        if (!mounted) return;
        setThreadMessages((current) => ({
          ...current,
          [selectedMatch.id]: messages.map((message) => ({
            id: message.id,
            from: (message.senderId || message.from) === currentUserId ? 'You' : 'Them',
            text: message.text,
            status: (message.senderId || message.from) === currentUserId ? 'Delivered' : 'Received',
          })),
        }));
      })
      .catch(() => undefined);
    return () => { mounted = false; };
  }, [selectedMatch?.id, selectedMatch?.matchId, currentUserId, getMessages]);

  if (selectedMatch) {
    return (
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 88 : 0} style={[styles.chatScreen, styles.chatKeyboardAvoider]}>
        <ContactSafetySheet visible={Boolean(pendingContactText)} matchName={selectedMatch.name} onReview={cancelContactShare} onSend={confirmContactShare} />
        <View style={styles.threadTopBar}>
          <TouchableOpacity onPress={() => setSelectedMatchId(null)} style={styles.chatBackButton}><Icon name="chevron-back" size={20} color="#FFFFFF" /></TouchableOpacity>
          <View style={styles.chatIdentity}>
            <Image source={activePhoto} style={styles.chatHeaderAvatar} />
            <View>
              <Text style={styles.chatName}>{selectedMatch.name}</Text>
              <Text style={styles.chatStatus}>{selectedMatch.online === true ? 'Online now' : 'Matched on RomChat'}</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.chatIconButton}><Icon name="shield-checkmark-outline" size={19} color="#FFFFFF" /></TouchableOpacity>
        </View>

        <View style={styles.safetyReminder}>
          <Icon name="shield-checkmark" size={17} color="#FFD700" />
          <Text style={styles.safetyReminderText}>Keep early chats on RomChat. Be careful with contacts, money requests, and pressure to move off app.</Text>
        </View>

        <View style={styles.conversationPanel}>
          <Text style={styles.matchContext}>{selectedMatch.intent} - {selectedMatch.city}{typeof selectedMatch.distanceKm === 'number' && selectedMatch.distanceKm > 0 ? ` - ${selectedMatch.distanceKm} km` : ''}</Text>
          {selectedMessages.length ? selectedMessages.map((message) => (
            <View key={message.id} style={[styles.bubble, message.from === 'You' ? styles.sent : styles.received]}>
              <Text style={message.from === 'You' ? styles.sentText : styles.receivedText}>{message.text}</Text>
              <Text style={message.from === 'You' ? styles.sentMeta : styles.receivedMeta}>{message.status}</Text>
            </View>
          )) : (
            <View style={styles.emptyThreadCard}>
              <Text style={styles.emptyThreadTitle}>Start with a simple message</Text>
              <Text style={styles.emptyThreadText}>Matched chats are free. Say hello, ask about a profile detail, and keep it respectful.</Text>
            </View>
          )}
        </View>

        {safetyWarning && <View style={styles.safetyBlockCard}><Icon name="shield-checkmark" size={18} color="#FFD700" /><Text style={styles.safetyBlockTitle}>Message blocked for community safety</Text><Text style={styles.safetyBlockText}>RomChat does not allow racial slurs, sexual abuse, threats, or harassment. Please rewrite your message respectfully.</Text><TouchableOpacity onPress={() => setSafetyWarning(null)}><Text style={styles.safetyBlockAction}>Edit message</Text></TouchableOpacity></View>}
        {selectedMatchBlocked && <View style={styles.safetyBlockCard}><Text style={styles.safetyBlockTitle}>This match is blocked</Text><Text style={styles.safetyBlockText}>The reported message was sent to RomChat Safety. Admin can reinstate if an appeal proves the block was unfair.</Text></View>}

        <View style={styles.chatToolsSimple}>
          <View style={styles.promptRow}>
            {promptChips.map((prompt) => <TouchableOpacity key={prompt} onPress={() => sendChatText(prompt)}><Text style={styles.promptChip}>{prompt}</Text></TouchableOpacity>)}
          </View>
        </View>
        <View style={styles.composer}>
          <TextInput value={draft} onChangeText={setDraft} placeholder={`Message ${selectedMatch.name}`} style={styles.input} placeholderTextColor="#a45a72" multiline maxLength={800} returnKeyType="default" textAlignVertical="center" />
          <TouchableOpacity onPress={submit} style={styles.send}><Icon name="send" size={18} color="#FFFFFF" /></TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    );
  }

  return (
    <View style={styles.chatScreen}>
      <View style={styles.chatInboxHeader}>
        <View>
          <Text style={styles.chatHeroTitle}>Chat</Text>
          <Text style={styles.chatHeroMeta}>{onlineMatches.length} ready now - {orderedMatches.length} matches</Text>
        </View>
        <TouchableOpacity style={styles.chatIconButton}><Icon name="shield-checkmark-outline" size={20} color="#FFFFFF" /></TouchableOpacity>
      </View>
      <View style={styles.searchBox}>
        <Icon name="search" size={20} color="rgba(255,255,255,0.62)" />
        <TextInput value={query} onChangeText={setQuery} placeholder={`Search ${orderedMatches.length} Matches`} placeholderTextColor="rgba(255,255,255,0.58)" style={styles.searchInput} />
      </View>
      <Text style={styles.chatSectionTitle}>New Matches</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.readyMatchesRail}>
        {onlineMatches.map((profile) => {
          const photo = profile.photos?.[0] ? { uri: resolveMediaUrl(profile.photos[0]) } : profile.photo;
          return (
            <TouchableOpacity key={profile.id} onPress={() => setSelectedMatchId(profile.id)} style={styles.readyMatchCard}>
              <Image source={photo} style={styles.readyMatchPhoto} />
              <View style={styles.onlineDot} />
              <Text numberOfLines={1} style={styles.readyMatchName}>{profile.name}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
      <View style={styles.messagesPanel}>
        <Text style={styles.messagesTitle}>Messages</Text>
        {visibleThreads.map((profile) => {
          const photo = profile.photos?.[0] ? { uri: resolveMediaUrl(profile.photos[0]) } : profile.photo;
          const messages = threadMessages[profile.id] || [];
          const preview = messages.length ? messages[messages.length - 1]!.text : profile.prompt;
          return (
            <TouchableOpacity key={profile.id} onPress={() => setSelectedMatchId(profile.id)} style={styles.threadRow}>
              <View>
                <Image source={photo} style={styles.threadAvatar} />
                {profile.online !== false && <View style={styles.threadOnlineDot} />}
              </View>
              <View style={styles.threadCopy}>
                <Text numberOfLines={1} style={styles.threadName}>{profile.name}{profile.verified ? ' verified' : ''}</Text>
                <Text numberOfLines={1} style={styles.threadPreview}>{preview}</Text>
              </View>
              <Text style={styles.yourTurnPill}>{messages.length ? 'Open' : 'Say hi'}</Text>
            </TouchableOpacity>
          );
        })}
        {!visibleThreads.length && <Text style={styles.emptyThreadText}>No matched conversations found. New matches will appear here.</Text>}
      </View>
    </View>
  );
}

const superLikeOffers = [
  { id: 'superlikes_15' as const, count: 15, unit: 200, total: 3000, badge: 'Popular' },
  { id: 'superlikes_30' as const, count: 30, unit: 150, total: 4500, badge: 'Best Value' },
];

const goldPlanOptions = [
  { id: 'week', label: '1 Week', unit: 300, total: 300, badge: 'Popular' },
  { id: 'month', label: '1 Month', unit: 200, total: 800, badge: 'Save' },
  { id: 'six', label: '6 Months', unit: 100, total: 2400, badge: 'Best Value' },
];

function SuperLikesScreen({ paymentNotice, openGoldPlans, openPaymentPage }: {
  paymentNotice: string;
  openGoldPlans: () => void;
  openPaymentPage: (purchase: PendingPurchase) => void;
}) {
  const [selected, setSelected] = useState<'superlikes_15' | 'superlikes_30'>('superlikes_15');
  const selectedOffer = superLikeOffers.find((item) => item.id === selected) ?? superLikeOffers[0]!;
  return (
    <View style={styles.purchaseScreen}>
      <View style={styles.purchaseCloseRow}><Icon name="close" size={34} color="#FFFFFF" /></View>
      <LinearGradient colors={["#9BC6FF", "#60A5FA"]} style={styles.superStar}><Icon name="star" size={54} color="#FFFFFF" /></LinearGradient>
      <Text style={styles.superTitle}>Get <Text style={styles.superTitleScript}>Super Likes</Text></Text>
      <Text style={styles.superCopy}>Stand out with Super Like. You're 3x more likely to get a match.</Text>
      <View style={styles.superOfferStack}>
        {superLikeOffers.map((offer) => (
          <TouchableOpacity key={offer.id} onPress={() => setSelected(offer.id)} activeOpacity={0.9} style={[styles.superOffer, selected === offer.id && styles.superOfferActive]}>
            <View style={styles.superOfferCopy}>
              {!!offer.badge && offer.id !== 'superlikes_15' && <Text style={styles.superOfferBadge}>{offer.badge}</Text>}
              <Text style={styles.superOfferCount}>{offer.count} Super Likes</Text>
              <Text style={styles.superOfferHint}>KES {offer.total.toLocaleString()} total</Text>
            </View>
            <View style={styles.superOfferPriceBox}>
              <Text style={styles.superOfferPrice}>KES {offer.unit.toFixed(2)}</Text>
              <Text style={styles.superOfferUnit}>per Super Like</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
      <Text style={styles.orText}>or</Text>
      <View style={styles.goldInlineCard}>
        <View><Text style={styles.goldInlineTitle}>Get RomChat Gold</Text><Text style={styles.goldInlineCopy}>Includes 2 Free Super Likes Every Week</Text></View>
        <TouchableOpacity onPress={openGoldPlans} style={styles.goldSelectButton}><Text style={styles.goldSelectText}>Select</Text></TouchableOpacity>
      </View>
      <TouchableOpacity
        onPress={() => openPaymentPage({ kind: 'superlikes', title: `${selectedOffer.count} Super Likes`, subtitle: 'Priority likes that move you higher in matching.', amountKes: selectedOffer.total, packageId: selectedOffer.id, accent: 'blue' })}
        style={styles.purchaseContinue}
      >
        <Text style={styles.purchaseContinueText}>Select</Text>
      </TouchableOpacity>
      {!!paymentNotice && <Text style={styles.paymentNotice}>{paymentNotice}</Text>}
    </View>
  );
}

function GoldPlansScreen({ paymentNotice, openPaymentPage }: {
  paymentNotice: string;
  openPaymentPage: (purchase: PendingPurchase) => void;
}) {
  const [selected, setSelected] = useState('week');
  const plan = goldPlanOptions.find((item) => item.id === selected) ?? goldPlanOptions[0]!;
  const benefits = ['Unlimited Likes', 'See Who Likes You', 'Unlimited Rewinds', '1 Free Boost per month', '2 Free Super Likes per week', 'Top Picks', 'Control Who Sees You', 'Hide Ads'];
  return (
    <AnimatedSalesPanel style={styles.purchaseScreen}>
      <View style={styles.goldHeaderRow}><Icon name="close" size={28} color="#FFFFFF" /><View style={styles.goldBrand}><Text style={styles.goldBrandText}>ROMCHAT</Text><Text style={styles.goldBadge}>GOLD</Text></View></View>
      <Text style={styles.goldHeroText}>3x more likely to get a match with Super Like.</Text>
      <Text style={styles.goldPlanLabel}>Select a Plan</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.goldPlanScroller}>
        {goldPlanOptions.map((option) => (
          <TouchableOpacity key={option.id} onPress={() => setSelected(option.id)} activeOpacity={0.9} style={[styles.goldPlanOption, selected === option.id && styles.goldPlanOptionActive]}>
            <View style={styles.goldOptionTop}><Text style={styles.goldOptionBadge}>{option.badge}</Text>{selected === option.id && <Icon name="checkmark" size={28} color="#FFD700" />}</View>
            <Text style={styles.goldOptionLabel}>{option.label}</Text>
            <Text style={styles.goldOptionPrice}>KES {option.unit}/wk</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.goldIncludedCard}>
        <Text style={styles.goldIncludedPill}>Included with RomChat Gold</Text>
        {benefits.map((benefit) => <View key={benefit} style={styles.goldBenefitRow}><Icon name="checkmark" size={28} color="#FFFFFF" /><Text style={styles.goldBenefitText}>{benefit}</Text></View>)}
      </View>
      <Text style={styles.goldTerms}>By tapping Continue, your subscription renews until cancelled. You agree to our Terms.</Text>
      <TouchableOpacity
        onPress={() => openPaymentPage({ kind: 'plan', title: `RomChat Gold - ${plan.label}`, subtitle: 'Unlimited likes, Top Picks, weekly Super Likes, and stronger discovery.', amountKes: plan.total, planId: 'gold', accent: 'gold' })}
        style={styles.purchaseContinue}
      >
        <Text style={styles.purchaseContinueText}>Select plan</Text>
      </TouchableOpacity>
      {!!paymentNotice && <Text style={styles.paymentNotice}>{paymentNotice}</Text>}
    </AnimatedSalesPanel>
  );
}

function Premium({ tokens, boosted, activePlan, paymentNotice, activateBoost, openPaymentPage }: {
  tokens: number; boosted: boolean; activePlan: PlanName; paymentNotice: string; activateBoost: () => void; openPaymentPage: (purchase: PendingPurchase) => void;
}) {
  return (
    <AnimatedSalesPanel>
      <LinearGradient colors={['#FFD700', '#FFA500']} style={styles.walletHero}>
        <Text style={styles.kickerDark}>Token Wallet</Text><Text style={styles.balance}>{tokens} tokens</Text><Text style={styles.heroCopyDark}>Transparent KES token pricing before every purchase.</Text>
      </LinearGradient>
      <View style={styles.packageGrid}>{tokenPackages.map((pack) => {
        const amountKes = Number(String(pack.price).replace(/[^0-9]/g, '') || 0);
        return (
          <View key={pack.id} style={[styles.packageCard, pack.badge && styles.packageFeatured]}>
            {!!pack.badge && <Text style={styles.packageBadge}>{pack.badge}</Text>}
            <View style={styles.packageTopRow}><Text style={styles.packageAmount}>{pack.amount}</Text><Text style={styles.packagePrice}>{pack.price}</Text></View>
            <Text style={styles.packageUnit}>{pack.unit}</Text>
            <TouchableOpacity onPress={() => openPaymentPage({ kind: 'tokens', title: `${pack.amount} tokens`, subtitle: `${pack.unit} for roses, rewinds, unlocks, and Super Likes.`, amountKes, packageId: pack.id, accent: pack.badge ? 'gold' : 'pink' })} style={styles.packageSelectButton}>
              <Text style={styles.packageSelectText}>Select</Text>
            </TouchableOpacity>
          </View>
        );
      })}</View>
      {!!paymentNotice && <Text style={styles.paymentNotice}>{paymentNotice}</Text>}
      <View style={styles.catalogCard}><Text style={styles.sectionLabel}>Token feature catalog</Text>{tokenCatalog.map((item) => <View key={item.id} style={styles.catalogRow}><Text style={styles.catalogLabel}>{item.label}</Text><Text style={styles.catalogCost}>{item.cost}</Text></View>)}</View>
      <Text style={styles.sectionLabel}>Plus tiers</Text>
      {plans.map((plan) => (
        <LinearGradient key={plan.name} colors={plan.name === 'Gold' ? ['#FF6F61', '#FF1493'] : ['#111823', '#2B2350', '#111111']} style={[styles.planCard, plan.name === 'Platinum' && styles.platinumPlanCard, activePlan === plan.name && styles.planCardActive]}>
          <View style={styles.planHeader}><View><Text style={styles.planName}>{plan.name}</Text><Text style={styles.planSubline}>{plan.name === 'Platinum' ? 'Priority discovery for serious matches' : 'Premium essentials for more control'}</Text></View><Text style={styles.planPrice}>{plan.price}</Text></View>
          <View style={styles.planPerkGrid}>{plan.perks.map((perk) => <View key={perk} style={styles.planPerkPill}><Icon name="checkmark" size={14} color="#120914" /><Text style={styles.planPerkPillText}>{perk}</Text></View>)}</View>
          <TouchableOpacity onPress={() => openPaymentPage({ kind: 'plan', title: `RomChat ${plan.name}`, subtitle: plan.name === 'Platinum' ? 'Priority likes, weekly boost, Top Picks, and unlimited likes.' : 'Unlimited likes, Likes Sent, Top Picks, and rewinds.', amountKes: plan.amountKes, planId: plan.id, accent: plan.name === 'Platinum' ? 'platinum' : 'gold' })} style={[styles.planSelectButton, plan.name === 'Platinum' && styles.platinumSelectButton]}>
            <Text style={styles.planSelectText}>Select</Text>
          </TouchableOpacity>
        </LinearGradient>
      ))}
      <TouchableOpacity onPress={activateBoost} style={[styles.boostButton, boosted && styles.boostButtonActive]}><Text style={styles.boostText}>{boosted ? 'Spotlight active for 30 minutes' : 'Boost profile for peak hour'}</Text></TouchableOpacity>
      <Text style={styles.complianceText}>Currency: KES. Select a package, then choose M-Pesa or card on the secure payment page. Store billing can remain enabled for app-store distributions.</Text>
    </AnimatedSalesPanel>
  );
}

function Safety({ incognito, setIncognito, antiGrab, setAntiGrab, verifiedOnly, setVerifiedOnly, updatePrivacy, report, verify, status }: {
  incognito: boolean;
  setIncognito: (value: boolean) => void;
  antiGrab: boolean;
  setAntiGrab: (value: boolean) => void;
  verifiedOnly: boolean;
  setVerifiedOnly: (value: boolean) => void;
  updatePrivacy: (payload: { incognito: boolean; screenshotsBlocked: boolean; visibleToLikedOnly: boolean }) => void;
  report: () => void;
  verify: () => Promise<void>;
  status: string;
}) {
  function setPrivacy(next: { verifiedOnly?: boolean; incognito?: boolean; antiGrab?: boolean }) {
    const values = {
      verifiedOnly: next.verifiedOnly ?? verifiedOnly,
      incognito: next.incognito ?? incognito,
      antiGrab: next.antiGrab ?? antiGrab,
    };
    setVerifiedOnly(values.verifiedOnly);
    setIncognito(values.incognito);
    setAntiGrab(values.antiGrab);
    updatePrivacy({ incognito: values.incognito, screenshotsBlocked: values.antiGrab, visibleToLikedOnly: values.verifiedOnly });
  }

  return (
    <View>
      <View style={styles.panel}>
        <Text style={styles.kicker}>{status}</Text>
        <Text style={styles.title}>Kenyan safety & privacy hub</Text>
        <ToggleRow title="Verified-only discovery" value={verifiedOnly} onPress={() => setPrivacy({ verifiedOnly: !verifiedOnly })} />
        <ToggleRow title="Incognito visibility" value={incognito} onPress={() => setPrivacy({ incognito: !incognito })} />
        <ToggleRow title="Anti-screengrab blocks" value={antiGrab} onPress={() => setPrivacy({ antiGrab: !antiGrab })} />
        <TouchableOpacity onPress={() => void verify()} style={styles.listItem}><Text style={styles.listTitle}>Selfie verification</Text><Text style={styles.caption}>Persona / Smile Identity ready</Text></TouchableOpacity>
        <TouchableOpacity onPress={report} style={styles.listItem}><Text style={styles.listTitle}>Report profile</Text><Text style={styles.caption}>Kenya safety team</Text></TouchableOpacity>
        <TouchableOpacity style={styles.listItem}><Text style={styles.listTitle}>Blocked accounts</Text><Text style={styles.caption}>Manage list</Text></TouchableOpacity>
        <TouchableOpacity style={styles.listItem}><Text style={styles.listTitle}>Community support</Text><Text style={styles.caption}>Get help</Text></TouchableOpacity>
      </View>
      <View style={styles.safetyScore}>
        <Text style={styles.score}>97</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.scoreTitle}>Safety score</Text>
          <Text style={styles.caption}>Identity, consent, and Kenyan community signals are healthy.</Text>
        </View>
      </View>
    </View>
  );
}




function AnimatedSalesPanel({ children, style, delay = 0 }: { children: React.ReactNode; style?: object; delay?: number }) {
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(18)).current;
  const scale = useRef(new Animated.Value(0.98)).current;

  useEffect(() => {
    opacity.setValue(0);
    translateY.setValue(18);
    scale.setValue(0.98);
    Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: 260, delay, useNativeDriver: true }),
      Animated.spring(translateY, { toValue: 0, friction: 8, tension: 85, delay, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, friction: 8, tension: 85, delay, useNativeDriver: true }),
    ]).start();
  }, [delay, opacity, scale, translateY]);

  return <Animated.View style={[style, { opacity, transform: [{ translateY }, { scale }] }]}>{children}</Animated.View>;
}

function PaymentPage({ purchase, mpesaPhone, setMpesaPhone, paymentNotice, onBack, onMpesa, onCard }: {
  purchase: PendingPurchase | null;
  mpesaPhone: string;
  setMpesaPhone: (value: string) => void;
  paymentNotice: string;
  onBack: () => void;
  onMpesa: () => void;
  onCard: () => void;
}) {
  if (!purchase) {
    return (
      <View style={styles.paymentPageEmpty}>
        <Icon name="bag-handle" size={34} color="#FFD700" />
        <Text style={styles.paymentPageTitle}>Choose a package first</Text>
        <TouchableOpacity onPress={onBack} style={styles.purchaseContinue}><Text style={styles.purchaseContinueText}>Back to packages</Text></TouchableOpacity>
      </View>
    );
  }
  const colors = purchase.accent === 'platinum' ? ['#0F172A', '#3B2D68', '#111111'] : purchase.accent === 'gold' ? ['#FFD700', '#FF9F1C'] : purchase.accent === 'blue' ? ['#9BC6FF', '#60A5FA'] : ['#FF1493', '#FF6F61'];
  const darkText = purchase.accent === 'gold' || purchase.accent === 'blue';
  return (
    <AnimatedSalesPanel style={styles.paymentPage}>
      <LinearGradient colors={colors as [string, string, ...string[]]} style={styles.paymentPageHero}>
        <Text style={[styles.paymentPageEyebrow, darkText && styles.paymentPageEyebrowDark]}>RomChat checkout</Text>
        <Text style={[styles.paymentPageTitle, darkText && styles.paymentPageTitleDark]}>{purchase.title}</Text>
        <Text style={[styles.paymentPageSubtitle, darkText && styles.paymentPageSubtitleDark]}>{purchase.subtitle}</Text>
        <View style={styles.paymentPageAmountRow}><Text style={[styles.paymentPageAmountLabel, darkText && styles.paymentPageAmountLabelDark]}>Total</Text><Text style={[styles.paymentPageAmount, darkText && styles.paymentPageAmountDark]}>KES {purchase.amountKes.toLocaleString()}</Text></View>
      </LinearGradient>
      <View style={styles.paymentMethodPanel}>
        <Text style={styles.paymentMethodTitle}>Select payment method</Text>
        <View style={styles.methodCard}>
          <View style={styles.methodIconWrap}><Icon name="phone-portrait" size={22} color="#FFFFFF" /></View>
          <View style={styles.methodCopy}><Text style={styles.methodTitle}>M-Pesa STK Push</Text><Text style={styles.methodCaption}>Enter your Safaricom number and approve the PIN prompt.</Text></View>
        </View>
        <TextInput
          value={mpesaPhone}
          onChangeText={setMpesaPhone}
          keyboardType="phone-pad"
          placeholder="0712345678"
          placeholderTextColor="rgba(255,255,255,0.45)"
          style={styles.paymentPageInput}
        />
        <TouchableOpacity onPress={onMpesa} style={styles.paymentMpesaButton}><Icon name="phone-portrait" size={18} color="#FFFFFF" /><Text style={styles.paymentMethodButtonText}>Pay with M-Pesa</Text></TouchableOpacity>
        <View style={styles.cardDivider}><View style={styles.cardDividerLine} /><Text style={styles.cardDividerText}>or</Text><View style={styles.cardDividerLine} /></View>
        <TouchableOpacity onPress={onCard} style={styles.paymentCardButton}><Icon name="card" size={18} color="#FFFFFF" /><Text style={styles.paymentMethodButtonText}>Pay with Credit/Debit Card</Text></TouchableOpacity>
        {!!paymentNotice && <Text style={styles.paymentNotice}>{paymentNotice}</Text>}
      </View>
    </AnimatedSalesPanel>
  );
}

function PaymentSheet({ sheet, onClose, onOpenCheckout, onRefresh }: { sheet: PaymentSheetState | null; onClose: () => void; onOpenCheckout: () => void; onRefresh: () => void }) {
  if (!sheet) return null;
  const isMpesa = sheet.provider === 'mpesa';
  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.paymentSheetBackdrop}>
        <TouchableOpacity style={StyleSheet.absoluteFill} activeOpacity={1} onPress={onClose} />
        <AnimatedSalesPanel style={styles.paymentSheetCard}>
          {isMpesa ? (
            <>
              <View style={styles.paymentSheetHandle} />
              <View style={styles.paymentSheetTop}>
                <LinearGradient colors={['#00C853', '#13A538']} style={styles.paymentProviderIcon}>
                  <Icon name="phone-portrait" size={28} color="#FFFFFF" />
                </LinearGradient>
                <TouchableOpacity onPress={onClose} style={styles.paymentCloseButton}><Icon name="close" size={22} color="#FFFFFF" /></TouchableOpacity>
              </View>
              <Text style={styles.paymentSheetEyebrow}>M-Pesa payment</Text>
              <Text style={styles.paymentSheetTitle}>{sheet.title}</Text>
              <Text style={styles.paymentSheetSubtitle}>{sheet.subtitle}</Text>
              <View style={styles.paymentAmountCard}><Text style={styles.paymentAmountLabel}>Amount</Text><Text style={styles.paymentAmountValue}>KES {sheet.amountKes.toLocaleString()}</Text></View>
              <View style={styles.paymentStatusRow}><ActivityIndicator color="#00E676" /><Text style={styles.paymentStatusText}>Waiting for provider confirmation</Text></View>
              <Text style={styles.paymentInstructionText}>{sheet.instructions}</Text>
              <Text style={styles.paymentReferenceText}>Payment ID: {sheet.paymentId}</Text>
              <View style={styles.paymentInfoBox}><Icon name="information-circle" size={18} color="#FFD700" /><Text style={styles.paymentInfoText}>Check your phone for the M-Pesa PIN prompt. If it does not arrive, confirm the phone number and backend STK logs.</Text></View>
              <View style={styles.paymentActionsRow}>
                <TouchableOpacity onPress={onRefresh} style={styles.paymentSecondaryButton}><Text style={styles.paymentSecondaryText}>Refresh status</Text></TouchableOpacity>
                <TouchableOpacity onPress={onClose} style={styles.paymentSecondaryButton}><Text style={styles.paymentSecondaryText}>Done</Text></TouchableOpacity>
              </View>
            </>
          ) : (
            <View style={styles.paymentCardOnly}>
              <TouchableOpacity disabled={!sheet.checkoutUrl} onPress={onOpenCheckout} style={[styles.paymentCardOnlyButton, !sheet.checkoutUrl && styles.paymentPrimaryButtonDisabled]}>
                <Icon name="card" size={20} color="#120914" />
                <Text style={styles.paymentPrimaryTextDark}>{sheet.checkoutUrl ? 'Pay with Card' : 'Checkout link not ready'}</Text>
              </TouchableOpacity>
            </View>
          )}
        </AnimatedSalesPanel>
      </View>
    </Modal>
  );
}

function ContactSafetySheet({ visible, matchName, onReview, onSend }: { visible: boolean; matchName: string; onReview: () => void; onSend: () => void }) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onReview}>
      <View style={styles.contactSheetBackdrop}>
        <TouchableOpacity style={StyleSheet.absoluteFill} activeOpacity={1} onPress={onReview} />
        <View style={styles.contactSheetCard}>
          <LinearGradient colors={["#FF1493", "#FF6F61"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.contactSheetIcon}>
            <Icon name="shield-checkmark" size={28} color="#FFFFFF" />
          </LinearGradient>
          <Text style={styles.contactSheetEyebrow}>RomChat safety check</Text>
          <Text style={styles.contactSheetTitle}>Share contacts only when trust feels real</Text>
          <Text style={styles.contactSheetBody}>You are about to send contact details to {matchName}. Keep early conversations here until you feel comfortable, and never send money or private documents.</Text>
          <View style={styles.contactSafetyList}>
            <View style={styles.contactSafetyItem}><Icon name="chatbubble-ellipses" size={16} color="#FFD700" /><Text style={styles.contactSafetyText}>Use RomChat messages first so reports and blocks still protect you.</Text></View>
            <View style={styles.contactSafetyItem}><Icon name="cash" size={16} color="#FFD700" /><Text style={styles.contactSafetyText}>Be cautious with money requests, transport fees, gifts, or urgent pressure.</Text></View>
            <View style={styles.contactSafetyItem}><Icon name="location" size={16} color="#FFD700" /><Text style={styles.contactSafetyText}>Meet in public and tell someone where you are going.</Text></View>
          </View>
          <View style={styles.contactSheetActions}>
            <TouchableOpacity onPress={onReview} style={styles.contactReviewButton}><Text style={styles.contactReviewText}>Review</Text></TouchableOpacity>
            <TouchableOpacity onPress={onSend} style={styles.contactSendButton}><Text style={styles.contactSendText}>Send anyway</Text></TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

function PolicyScreen({ section }: { section: 'privacy' | 'terms' | 'community' }) {
  const content = {
    privacy: {
      title: 'Privacy Policy',
      items: [
        ['Profile data', 'We use your profile details, photos, preferences, interests, and location settings to show relevant Kenyan matches and improve safety.'],
        ['Chats', 'Messages are used to deliver conversations, support moderation, detect abuse, and help with reports. Keep sensitive details on-app until trust is earned.'],
        ['Media', 'Photos and verification selfies are used for profile display, gallery access, moderation, and authenticity checks.'],
        ['Controls', 'You can update profile details, manage privacy settings, block/report accounts, and sign out from your profile.'],
      ],
    },
    terms: {
      title: 'Terms of Use',
      items: [
        ['Eligibility', 'RomChat is for adults 18+ who provide accurate account and profile information.'],
        ['Respectful use', 'Do not harass, impersonate, scam, solicit money, post illegal content, or pressure matches to move off app.'],
        ['Premium and tokens', 'Subscriptions and tokens unlock optional discovery features. Matched text chat remains simple and accessible.'],
        ['Enforcement', 'RomChat may remove content, limit features, suspend accounts, or cooperate with lawful safety requests.'],
      ],
    },
    community: {
      title: 'Community Guidelines',
      items: [
        ['Be real', 'Use your own photos, be honest about your intentions, and keep your profile respectful.'],
        ['Stay safe', 'Be careful sharing phone numbers, emails, social handles, money details, home address, or workplace details.'],
        ['Meet smart', 'Choose public places, tell someone you trust, arrange your own transport, and leave if anything feels wrong.'],
        ['Report quickly', 'Report suspicious profiles, pressure, abuse, scams, explicit threats, or requests for money.'],
      ],
    },
  }[section];
  return (
    <View style={styles.policyScreen}>
      <Text style={styles.title}>{content.title}</Text>
      {content.items.map(([title, body]) => (
        <View key={title} style={styles.policyItem}>
          <Text style={styles.policyTitle}>{title}</Text>
          <Text style={styles.policyBody}>{body}</Text>
        </View>
      ))}
      <Text style={styles.complianceText}>Last updated for RomChat Kenya. This in-app summary should be reviewed by counsel before production store submission.</Text>
    </View>
  );
}

function resolveMediaUrl(url?: string) {
  if (!url) return '';
  if (/^https?:\/\//i.test(url)) return url;
  return `${apiBaseUrl}${url.startsWith('/') ? url : `/${url}`}`;
}

function Profile({ account, profile, strength, incognito, busy, error, onUploadImage, onSetMainPhoto, onVerifySelfie, onSaveDetails, onSavePrompts, onSaveDiscoverySettings, status, onSignOut, onDeleteAccount, onRequestDataDeletion, openPolicy }: { account: RomChatAccount | null; profile: RomChatMemberProfile | null; strength: number; incognito: boolean; busy: boolean; error: string; onUploadImage: () => Promise<void>; onSetMainPhoto: (mediaId: string) => Promise<void>; onVerifySelfie: () => Promise<void>; onSaveDetails: (payload: { displayName: string; gender: string; city: string; intent: string; bio: string; interests: string[] }) => Promise<void>; onSavePrompts: (answers: RomChatPromptAnswer[]) => Promise<void>; onSaveDiscoverySettings: (payload: { maxDistanceKm: number; minAge: number; maxAge: number; mapDiscoveryEnabled: boolean }) => Promise<void>; status: string; onSignOut: () => Promise<void>; onDeleteAccount: () => Promise<void>; onRequestDataDeletion: () => Promise<void>; openPolicy: (section: 'privacy' | 'terms' | 'community') => void }) {
  const imageCount = profile?.imageCount || 0;
  const computedStrength = profile?.profileStrength || strength;
  const catalogueAccess = Math.min(6, Math.max(1, imageCount));
  const photoMedia = [...(profile?.media || [])].filter((item) => item.mediaType === 'image').sort((a, b) => (a.position || 0) - (b.position || 0));
  const promptSeed = profilePromptTemplates.map((prompt, index) => ({ prompt, answer: profile?.promptAnswers?.[index]?.answer || '' }));
  const [displayName, setDisplayName] = useState(profile?.displayName || account?.name || '');
  const [gender, setGender] = useState(profile?.gender || 'female');
  const [city, setCity] = useState(profile?.city || '');
  const [intent, setIntent] = useState(profile?.intent || 'Serious relationship');
  const [bio, setBio] = useState(profile?.bio || '');
  const [selectedInterests, setSelectedInterests] = useState<string[]>(profile?.interests?.length ? profile.interests : []);
  const [detailsNotice, setDetailsNotice] = useState('');
  const [promptAnswers, setPromptAnswers] = useState<RomChatPromptAnswer[]>(promptSeed);
  const lastProfileSyncKey = useRef<string | null>(null);
  useEffect(() => { setPromptAnswers(promptSeed); }, [profile?.memberId, profile?.promptAnswers?.length]);
  useEffect(() => {
    const syncKey = profile?.memberId || account?.id || account?.email || 'guest';
    if (lastProfileSyncKey.current === syncKey) return;
    lastProfileSyncKey.current = syncKey;
    setDisplayName(profile?.displayName || account?.name || '');
    setGender(profile?.gender || 'female');
    setCity(profile?.city || '');
    setIntent(profile?.intent || 'Serious relationship');
    setBio(profile?.bio || '');
    setSelectedInterests(profile?.interests?.length ? profile.interests : []);
    setDetailsNotice('');
  }, [account?.email, account?.id, account?.name, profile?.memberId]);
  const toggleEditableInterest = (interest: string) => setSelectedInterests((current) => current.includes(interest) ? current.filter((item) => item !== interest) : [...current, interest]);
  function saveEditableDetails() {
    if (!displayName.trim()) return setDetailsNotice('Add a display name.');
    if (!gender.trim()) return setDetailsNotice('Choose your gender.');
    if (!city.trim()) return setDetailsNotice('Add your city.');
    if (!intent.trim()) return setDetailsNotice('Choose your dating intention.');
    if (!selectedInterests.length) return setDetailsNotice('Pick at least one interest.');
    if (!bio.trim()) return setDetailsNotice('Write a short bio.');
    setDetailsNotice('');
    void onSaveDetails({ displayName, gender, city, intent, bio, interests: selectedInterests });
  }
  const [distanceKm, setDistanceKm] = useState(profile?.maxDistanceKm || 80);
  const [minAge, setMinAge] = useState(profile?.minAge || 18);
  const [maxAge, setMaxAge] = useState(profile?.maxAge || 80);
  const [mapEnabled, setMapEnabled] = useState(profile?.mapDiscoveryEnabled !== false);
  useEffect(() => {
    setDistanceKm(profile?.maxDistanceKm || 80);
    setMinAge(profile?.minAge || 18);
    setMaxAge(profile?.maxAge || 80);
    setMapEnabled(profile?.mapDiscoveryEnabled !== false);
  }, [profile?.memberId, profile?.maxDistanceKm, profile?.minAge, profile?.maxAge, profile?.mapDiscoveryEnabled]);
  const updateMinAge = (value: number) => setMinAge(Math.min(Math.round(value), maxAge - 1));
  const updateMaxAge = (value: number) => setMaxAge(Math.max(Math.round(value), minAge + 1));
  const completePrompts = promptAnswers.filter((item) => item.prompt && item.answer.trim()).length;
  const profileTasks = [
    [`Images uploaded: ${imageCount}`, imageCount >= 3 ? 'Fuller catalogues unlocked' : 'Add photos to unlock more galleries'],
    [`Catalogue access: ${catalogueAccess} photos`, incognito ? 'Visible after like' : 'Discovery ready'],
    ['Answer 7 prompts', completePrompts === 7 ? 'All prompts live' : `${completePrompts}/7 prompts answered`],
    ['Selfie verification', profile?.selfieVerified ? 'Verified badge active' : 'Verify with a live selfie'],
  ];

  return (
    <View>
      <View style={styles.panel}>
        <Text style={styles.kicker}>{account?.email || status}</Text>
        <Text style={styles.title}>{profile?.displayName || account?.name || 'Kenyan profile & vibe'}</Text>
        <Text style={styles.caption}>{profile?.city ? `${profile.city} - ${profile.intent || 'Intentional connection'}` : status}</Text>
        <Text style={styles.profileStrength}>{computedStrength}% complete</Text>
        <View style={styles.progress}><View style={[styles.progressFill, { width: `${computedStrength}%` }]} /></View>
        <View style={styles.editProfilePanel}>
          <View style={styles.editProfileHeader}>
            <View style={{ flex: 1 }}>
              <Text style={styles.distanceTitle}>Profile details</Text>
              <Text style={styles.distanceMeta}>Age is locked after creation. Everything else stays editable.</Text>
            </View>
            <View style={styles.ageLockPill}><Icon name="lock-closed" size={14} color="#120914" /><Text style={styles.ageLockText}>{profile?.age || '--'}</Text></View>
          </View>
          <TextInput value={displayName} onChangeText={setDisplayName} placeholder="Display name" placeholderTextColor="rgba(255,255,255,0.42)" style={styles.authInput} />
          <View style={styles.lockedAgeRow}>
            <View><Text style={styles.lockedAgeLabel}>Age</Text><Text style={styles.lockedAgeValue}>{profile?.age || '--'} years</Text></View>
            <Text style={styles.lockedAgeBadge}>Locked</Text>
          </View>
          <View style={styles.genderRow}>{['female', 'male'].map((item) => <TouchableOpacity key={item} disabled={busy} onPress={() => setGender(item)} style={[styles.genderChip, gender === item && styles.genderChipActive]}><Text style={[styles.genderText, gender === item && styles.genderTextActive]}>{item}</Text></TouchableOpacity>)}</View>
          <TextInput value={city} onChangeText={setCity} placeholder="City" placeholderTextColor="rgba(255,255,255,0.42)" style={styles.authInput} />
          <TextInput value={bio} onChangeText={setBio} placeholder="Short Kenyan romance bio" placeholderTextColor="rgba(255,255,255,0.42)" style={[styles.authInput, styles.authTextArea]} multiline />
        </View>
        <View style={styles.distancePanel}>
          <View style={styles.distanceHeader}>
            <View style={{ flex: 1 }}>
              <Text style={styles.distanceTitle}>Distance preference</Text>
              <Text style={styles.distanceMeta}>{mapEnabled ? 'Map discovery on' : 'Map discovery paused'} - show people within {distanceKm} km</Text>
            </View>
            <TouchableOpacity disabled={busy} onPress={() => setMapEnabled((value) => !value)} style={[styles.mapToggle, mapEnabled && styles.mapToggleActive]}>
              <Icon name={mapEnabled ? 'map' : 'map-outline'} size={18} color={mapEnabled ? '#120914' : '#FFD700'} />
            </TouchableOpacity>
          </View>
          <Slider value={distanceKm} minimumValue={5} maximumValue={500} step={5} minimumTrackTintColor="#FF1493" maximumTrackTintColor="rgba(255,255,255,0.20)" thumbTintColor="#FFD700" onValueChange={setDistanceKm} />
          <View style={styles.distanceScale}><Text style={styles.distanceScaleText}>5 km</Text><Text style={styles.distanceScaleText}>500 km</Text></View>
          <View style={styles.ageRangeBlock}>
            <View style={styles.ageRangeHeader}>
              <Text style={styles.distanceTitle}>Age range</Text>
              <Text style={styles.ageRangeValue}>{minAge} - {maxAge}</Text>
            </View>
            <Text style={styles.distanceMeta}>Show profiles in this age range, like Tinder discovery.</Text>
            <Slider value={minAge} minimumValue={18} maximumValue={79} step={1} minimumTrackTintColor="#FF1493" maximumTrackTintColor="rgba(255,255,255,0.18)" thumbTintColor="#FFD700" onValueChange={updateMinAge} />
            <Slider value={maxAge} minimumValue={19} maximumValue={80} step={1} minimumTrackTintColor="#FF6F61" maximumTrackTintColor="rgba(255,255,255,0.18)" thumbTintColor="#FFFFFF" onValueChange={updateMaxAge} />
            <View style={styles.distanceScale}><Text style={styles.distanceScaleText}>18</Text><Text style={styles.distanceScaleText}>80+</Text></View>
          </View>
          <TouchableOpacity disabled={busy} onPress={() => void onSaveDiscoverySettings({ maxDistanceKm: distanceKm, minAge, maxAge, mapDiscoveryEnabled: mapEnabled })} style={styles.distanceSaveButton}><Text style={styles.distanceSaveText}>Apply discovery filters</Text></TouchableOpacity>
        </View>
        <View style={styles.photoSlotGrid}>{Array.from({ length: 6 }).map((_, index) => {
          const media = photoMedia[index];
          const uri = resolveMediaUrl(media?.url);
          const isMain = Boolean(media && index === 0);
          return <TouchableOpacity disabled={busy} onPress={() => media?.id ? void onSetMainPhoto(media.id) : void onUploadImage()} key={media?.id || index} style={[styles.photoSlot, isMain && styles.photoSlotMain]}>{uri ? <Image source={{ uri }} style={styles.photoThumb} /> : <Icon name={index < imageCount ? 'image' : 'add'} size={22} color={index < imageCount ? '#FFD700' : '#FF1493'} />}{!uri && <Text style={styles.photoSlotText}>Add</Text>}</TouchableOpacity>;
        })}</View>
        {profileTasks.map(([item, detail]) => (
          <View key={item} style={styles.listItem}>
            <Text style={styles.listTitle}>{item}</Text>
            <Text style={styles.caption}>{detail}</Text>
          </View>
        ))}
        <View style={styles.profileActionGrid}><TouchableOpacity disabled={busy} onPress={() => void onUploadImage()} style={styles.profileAction}><Icon name="images" size={18} color="#FFD700" /><Text style={styles.profileActionText}>Add photo</Text></TouchableOpacity><TouchableOpacity disabled={busy || !imageCount} onPress={() => void onVerifySelfie()} style={[styles.profileAction, !imageCount && styles.profileActionDisabled]}><Icon name="shield-checkmark" size={18} color="#FFD700" /><Text style={styles.profileActionText}>{profile?.selfieVerified ? 'Verified' : 'Verify selfie'}</Text></TouchableOpacity></View>{!!error && <Text style={styles.authError}>{error}</Text>}
        <TouchableOpacity onPress={() => void onSignOut()} style={styles.textButton}><Text style={styles.textButtonLabel}>Sign out</Text></TouchableOpacity>
      </View>
      <View style={styles.legalPanel}>
        <Text style={styles.sectionLabel}>Legal and privacy</Text>
        <TouchableOpacity onPress={() => openPolicy('privacy')} style={styles.legalLink}><Text style={styles.legalTitle}>Privacy Policy</Text><Text style={styles.caption}>How RomChat handles profile, chat, photo, location, and safety data.</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => openPolicy('terms')} style={styles.legalLink}><Text style={styles.legalTitle}>Terms of Use</Text><Text style={styles.caption}>Account rules, subscriptions, tokens, acceptable use, and service limits.</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => openPolicy('community')} style={styles.legalLink}><Text style={styles.legalTitle}>Community Guidelines</Text><Text style={styles.caption}>Dating safety, respectful messaging, reporting, blocking, and contact-sharing guidance.</Text></TouchableOpacity>
      </View>
      <View style={styles.panel}>
        <Text style={styles.kicker}>Bio assistant</Text>
        <Text style={styles.insight}>{bio || profile?.bio || 'One-tap Kenyan bio: I am looking for something warm, honest, and intentional around real dates.'}</Text>
        <Text style={styles.insight}>{selectedInterests.length ? `Vibe signals: ${selectedInterests.join(', ')}` : 'Best dates: Karura walks, Java chats, lakefront sunsets, and food worth remembering.'}</Text>
        <Text style={styles.selectorTitle}>Dating intention in Kenya</Text>
        <View style={styles.choiceWrap}>{datingIntentions.map((item) => <TouchableOpacity key={item} disabled={busy} onPress={() => setIntent(item)} style={[styles.choiceChip, intent === item && styles.choiceChipActive]}><Text style={[styles.choiceText, intent === item && styles.choiceTextActive]}>{item}</Text></TouchableOpacity>)}</View>
        <Text style={styles.selectorTitle}>Interests and vibe signals</Text>
        <View style={styles.choiceWrap}>{datingInterests.map((item) => { const active = selectedInterests.includes(item); return <TouchableOpacity key={item} disabled={busy} onPress={() => toggleEditableInterest(item)} style={[styles.choiceChip, active && styles.choiceChipActive]}><Text style={[styles.choiceText, active && styles.choiceTextActive]}>{item}</Text></TouchableOpacity>; })}</View>
        {!!detailsNotice && <Text style={styles.validationNudge}>{detailsNotice}</Text>}
        <TouchableOpacity disabled={busy} onPress={saveEditableDetails} style={styles.distanceSaveButton}><Text style={styles.distanceSaveText}>Save profile details</Text></TouchableOpacity>
        <Text style={styles.kicker}>Dating prompts</Text>
        {promptAnswers.map((item, index) => <View key={item.prompt} style={styles.promptEditor}><Text style={styles.promptEditorLabel}>{item.prompt}</Text><TextInput value={item.answer} onChangeText={(answer) => setPromptAnswers((current) => current.map((row, rowIndex) => rowIndex === index ? { ...row, answer } : row))} placeholder="Write a charming answer" placeholderTextColor="rgba(255,255,255,0.42)" style={styles.promptEditorInput} multiline /></View>)}
        <TouchableOpacity disabled={busy} onPress={() => void onSavePrompts(promptAnswers)} style={styles.boostButton}><Text style={styles.boostText}>Save 7 profile prompts</Text></TouchableOpacity>
      <View style={styles.dangerPanel}>
        <Text style={styles.sectionLabel}>Account deletion</Text>
        <Text style={styles.caption}>Request a data deletion review or remove your RomChat account immediately.</Text>
        <View style={styles.dangerActionRow}>
          <TouchableOpacity disabled={busy} onPress={() => void onRequestDataDeletion()} style={styles.dangerSoftButton}><Text style={styles.dangerSoftButtonText}>Request data deletion</Text></TouchableOpacity>
          <TouchableOpacity disabled={busy} onPress={() => void onDeleteAccount()} style={styles.dangerButton}><Text style={styles.dangerButtonText}>Delete account</Text></TouchableOpacity>
        </View>
      </View>
      </View>
    </View>
  );
}

function ToggleRow({ title, value, onPress }: { title: string; value: boolean; onPress: () => void }) {
  return (
    <TouchableOpacity onPress={onPress} style={styles.switchRow}>
      <Text style={styles.switchTitle}>{title}</Text>
      <View style={[styles.toggleTrack, value && styles.toggleTrackOn]}>
        <View style={[styles.toggleDot, value && styles.toggleDotOn]} />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#120914' },
  safeCenter: { flex: 1, backgroundColor: '#120914', alignItems: 'center', justifyContent: 'center', padding: 24 },
  loadingText: { color: '#FFFFFF', fontWeight: '900', marginTop: 14 },
  authSafe: { flex: 1, backgroundColor: '#120914' },
  keyboardAvoider: { flex: 1 },
  authContent: { padding: 20, paddingBottom: 120, flexGrow: 1, justifyContent: 'center' },
  authContentTop: { justifyContent: 'flex-start', paddingTop: 24 },
  authLogo: { color: '#FF1493', fontSize: 30, fontWeight: '900', marginBottom: 10 },
  authTitle: { color: '#FFFFFF', fontSize: 34, fontWeight: '900', lineHeight: 39, marginBottom: 10 },
  authCopy: { color: 'rgba(255,255,255,0.7)', fontWeight: '800', lineHeight: 22, marginBottom: 18 },
  googleButton: { minHeight: 52, borderRadius: 18, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 10, marginBottom: 14 },
  googleButtonText: { color: '#120914', fontWeight: '900', fontSize: 16 },
  googleButtonDisabled: { opacity: 0.58 },
  authTabs: { flexDirection: 'row', backgroundColor: '#1E1222', borderRadius: 18, padding: 4, marginBottom: 12 },
  authTab: { flex: 1, alignItems: 'center', paddingVertical: 11, borderRadius: 15 },
  authTabActive: { backgroundColor: '#FF1493' },
  authTabText: { color: 'rgba(255,255,255,0.7)', fontWeight: '900' },
  authTabTextActive: { color: '#FFFFFF' },
  authInput: { minHeight: 52, borderRadius: 18, backgroundColor: '#1E1222', borderWidth: 1, borderColor: 'rgba(255,20,147,0.24)', paddingHorizontal: 14, color: '#FFFFFF', fontWeight: '800', marginBottom: 10 },
  inputMissing: { borderColor: '#FFD700', backgroundColor: 'rgba(255,215,0,0.08)' },
  sectionMissing: { borderWidth: 1, borderColor: '#FFD700', borderRadius: 18, padding: 6, backgroundColor: 'rgba(255,215,0,0.06)' },
  passwordRow: { minHeight: 52, borderRadius: 18, backgroundColor: '#1E1222', borderWidth: 1, borderColor: 'rgba(255,20,147,0.24)', marginBottom: 10, flexDirection: 'row', alignItems: 'center' },
  passwordInput: { flex: 1, minHeight: 52, paddingHorizontal: 14, color: '#FFFFFF', fontWeight: '800' },
  passwordEye: { width: 50, minHeight: 52, alignItems: 'center', justifyContent: 'center' },
  authTextArea: { minHeight: 92, paddingTop: 14, textAlignVertical: 'top' },
  authPrimary: { minHeight: 54, borderRadius: 18, backgroundColor: '#FF1493', alignItems: 'center', justifyContent: 'center', marginTop: 4, marginBottom: 12 },
  authPrimaryText: { color: '#FFFFFF', fontWeight: '900', fontSize: 16 },
  authLink: { color: '#FFD700', fontWeight: '900', textAlign: 'center', marginTop: 8 },
  authError: { color: '#FF6F61', fontWeight: '900', lineHeight: 20, marginTop: 4, marginBottom: 8 },
  authSuccess: { color: '#FFD700', fontWeight: '900', lineHeight: 20, marginTop: 2, marginBottom: 8 },
  genderRow: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  genderChip: { flex: 1, backgroundColor: '#1E1222', borderRadius: 16, borderWidth: 1, borderColor: 'rgba(255,20,147,0.22)', paddingVertical: 11, alignItems: 'center' },
  genderChipActive: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
  genderText: { color: '#FFFFFF', fontWeight: '900', textTransform: 'capitalize' },
  genderTextActive: { color: '#120914' },
  selectorTitle: { color: '#FFFFFF', fontWeight: '900', fontSize: 15, marginTop: 4, marginBottom: 10 },
  selectorTitleMissing: { color: '#FFD700' },
  choiceWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  choiceChip: { borderRadius: 999, borderWidth: 1, borderColor: 'rgba(255,20,147,0.24)', backgroundColor: '#1E1222', paddingHorizontal: 13, paddingVertical: 10 },
  choiceChipActive: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
  choiceText: { color: 'rgba(255,255,255,0.78)', fontWeight: '900', fontSize: 13 },
  choiceTextActive: { color: '#120914' },
  uploadCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#1E1222', borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,215,0,0.35)', padding: 16, marginBottom: 8 },
  uploadCardMissing: { borderColor: '#FFD700', backgroundColor: 'rgba(255,215,0,0.08)' },
  uploadCardDisabled: { opacity: 0.45 },
  validationNudge: { color: '#FFD700', fontWeight: '900', marginTop: 2, marginBottom: 10, textAlign: 'center' },
  uploadTitle: { color: '#FFFFFF', fontWeight: '900', fontSize: 16 },
  uploadMeta: { color: 'rgba(255,255,255,0.6)', fontWeight: '800', marginTop: 3 },
  content: { paddingHorizontal: 16, paddingTop: 8, backgroundColor: '#120914' },
  screenContent: { paddingHorizontal: 16, paddingTop: 10, backgroundColor: '#120914' },
  screenHeader: { paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#120914', borderBottomWidth: 1, borderBottomColor: 'rgba(255,20,147,0.2)' },
  screenTitle: { color: '#FFFFFF', fontSize: 20, fontWeight: '900' },
  backButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#1E1222', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255, 20, 147, 0.24)' },
  backButtonText: { color: '#FFFFFF', fontWeight: '900' },
  apiPill: { color: '#FFD700', backgroundColor: '#1E1222', overflow: 'hidden', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 8, fontWeight: '900' },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  topControls: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  logo: { width: 42, height: 42, borderRadius: 21, borderWidth: 2, borderColor: '#FFD700', backgroundColor: '#2A1A30' },
  brand: { color: '#FF1493', fontSize: 25, fontWeight: '900' },
  brandTagline: { color: '#FFD7E6', fontSize: 11, fontWeight: '900', marginTop: 1 },
  caption: { color: 'rgba(255,255,255,0.7)', fontWeight: '800', lineHeight: 18 },
  iconButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#1E1222', borderWidth: 1, borderColor: 'rgba(255,20,147,0.22)', alignItems: 'center', justifyContent: 'center' },
  walletPill: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#1E1222', paddingHorizontal: 12, height: 42, borderRadius: 999, borderWidth: 1, borderColor: 'rgba(255, 215, 0, 0.38)' },
  walletText: { color: '#FFD700', fontWeight: '900', fontSize: 14 },
  safePill: { backgroundColor: '#1E1222', borderRadius: 999, paddingHorizontal: 14, paddingVertical: 10 },
  safePillText: { color: '#FFD700', fontWeight: '900' },
  discovery: { marginBottom: 4 },
  deckShadow: { borderRadius: 26, marginBottom: 10, shadowColor: '#FF1493', shadowOpacity: 0.34, shadowRadius: 20, shadowOffset: { width: 0, height: 12 }, elevation: 10 },
  profileCard: { width: '100%', borderRadius: 28, overflow: 'hidden', justifyContent: 'flex-end', backgroundColor: '#1E1222' },
  profilePhoto: { borderRadius: 28 },
  photoOverlay: { ...StyleSheet.absoluteFillObject },
  tapZones: { ...StyleSheet.absoluteFillObject, flexDirection: 'row' },
  tapZone: { flex: 1 },
  photoDots: { position: 'absolute', left: 12, right: 12, top: 12, flexDirection: 'row', gap: 4 },
  photoDot: { flex: 1, height: 4, borderRadius: 999, backgroundColor: 'rgba(255,255,255,0.4)' },
  photoDotActive: { backgroundColor: '#FF1493' },
  galleryLockNotice: { position: 'absolute', top: 28, left: 18, right: 18, flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 18, paddingHorizontal: 12, paddingVertical: 10, backgroundColor: 'rgba(18,9,20,0.82)', borderWidth: 1, borderColor: 'rgba(255,215,0,0.35)' },
  galleryLockText: { flex: 1, color: '#FFFFFF', fontWeight: '900', fontSize: 12, lineHeight: 17 },
  cardTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 18, paddingTop: 30 },
  pillRow: { flexDirection: 'row', gap: 6, marginBottom: 5 },
  verifiedBadge: { color: '#00F0FF', backgroundColor: 'rgba(0,240,255,0.12)', overflow: 'hidden', borderRadius: 999, paddingHorizontal: 8, paddingVertical: 5, fontWeight: '900', fontSize: 10 },
  cardBadge: { color: '#120914', backgroundColor: '#FFD700', overflow: 'hidden', borderRadius: 999, paddingHorizontal: 9, paddingVertical: 5, fontWeight: '900', fontSize: 10 },
  cardCopy: { paddingHorizontal: 18, paddingBottom: 118, paddingTop: 56 },
  cardTitle: { color: '#FFFFFF', fontSize: 31, fontWeight: '900' },
  cardAge: { color: '#FFFFFF', fontWeight: '700' },
  cardSub: { color: 'rgba(255,255,255,0.72)', fontSize: 12, fontWeight: '800', marginTop: 2 },
  cardPrompt: { color: '#FFFFFF', fontSize: 13, lineHeight: 18, marginTop: 6, fontWeight: '800' },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 },
  photoTag: { color: '#FFFFFF', backgroundColor: 'rgba(255,255,255,0.16)', overflow: 'hidden', paddingHorizontal: 9, paddingVertical: 5, borderRadius: 999, fontWeight: '900', fontSize: 10 },
  actionDock: { position: 'absolute', left: 18, right: 18, bottom: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, zIndex: 3 },
  actionItem: { alignItems: 'center', justifyContent: 'center' },
  actionLabel: { color: 'rgba(255,255,255,0.68)', fontWeight: '900', fontSize: 10, marginTop: 5 },
  passAction: { width: 58, height: 58, borderRadius: 29, backgroundColor: 'rgba(20,20,22,0.88)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.10)', alignItems: 'center', justifyContent: 'center', shadowColor: '#000000', shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: { width: 0, height: 7 }, elevation: 7 },
  passGradient: { width: '100%', height: '100%', justifyContent: 'center', alignItems: 'center' },
  topAction: { width: 50, height: 50, borderRadius: 25, backgroundColor: 'rgba(20,20,22,0.88)', borderWidth: 1, borderColor: 'rgba(155,198,255,0.48)', justifyContent: 'center', alignItems: 'center', shadowColor: '#9BC6FF', shadowOpacity: 0.22, shadowRadius: 10, shadowOffset: { width: 0, height: 5 } },
  likeAction: { width: 60, height: 60, borderRadius: 30, backgroundColor: 'rgba(20,20,22,0.88)', borderWidth: 1, borderColor: 'rgba(255,18,0,0.26)', alignItems: 'center', justifyContent: 'center' },
  likeGradient: { width: '100%', height: '100%', justifyContent: 'center', alignItems: 'center' },
  rewindAction: { width: 46, height: 46, borderRadius: 23, backgroundColor: 'rgba(20,20,22,0.76)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.10)', justifyContent: 'center', alignItems: 'center' },
  messageAction: { width: 48, height: 48, borderRadius: 24, backgroundColor: 'rgba(20,20,22,0.78)', borderWidth: 1, borderColor: 'rgba(155,198,255,0.35)', justifyContent: 'center', alignItems: 'center' },
  smallAction: { backgroundColor: '#1E1222', paddingHorizontal: 14, paddingVertical: 14, borderRadius: 999, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  smallActionText: { color: '#FFFFFF', fontWeight: '900' },
  passActionText: { color: '#8A7B89', fontWeight: '900' },
  likeActionText: { color: '#FFFFFF', fontWeight: '900' },
  topActionText: { color: '#FFD700', fontWeight: '900' },
  matchPopOverlay: { position: 'absolute', left: 14, right: 14, top: 96, zIndex: 4 },
  matchSheet: { borderRadius: 28, padding: 20, marginTop: 16, borderWidth: 1, borderColor: 'rgba(255,215,0,0.35)', shadowColor: '#FF1493', shadowOpacity: 0.4, shadowRadius: 24, shadowOffset: { width: 0, height: 14 }, elevation: 12 },
  matchAvatarPair: { height: 116, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', marginBottom: 10 },
  matchAvatarLarge: { width: 92, height: 92, borderRadius: 46, borderWidth: 4, borderColor: '#FFD700', backgroundColor: '#1E1222' },
  matchAvatarOverlap: { marginLeft: -22 },
  floatingHeart: { position: 'absolute', top: 44, width: 34, height: 34, borderRadius: 17, backgroundColor: '#FF1493', alignItems: 'center', justifyContent: 'center' },
  matchKicker: { color: '#FFD700', fontWeight: '900', textTransform: 'uppercase', fontSize: 12, textAlign: 'center' },
  matchTitle: { color: '#FFFFFF', fontSize: 27, fontWeight: '900', marginTop: 6, marginBottom: 10, textAlign: 'center' },
  matchPrompt: { color: '#FFFFFF', backgroundColor: 'rgba(255,255,255,0.14)', borderRadius: 16, padding: 12, fontWeight: '800', lineHeight: 20, marginTop: 8 },
  matchActions: { flexDirection: 'row', gap: 10, marginTop: 14 },
  matchSecondary: { flex: 1, alignItems: 'center', paddingVertical: 13, borderRadius: 999, backgroundColor: 'rgba(255,255,255,0.12)' },
  matchSecondaryText: { color: '#FFFFFF', fontWeight: '900' },
  matchPrimary: { flex: 1.25, alignItems: 'center', paddingVertical: 13, borderRadius: 999, backgroundColor: '#FF1493' },
  matchPrimaryText: { color: '#FFFFFF', fontWeight: '900', textAlign: 'center' },
  shortcutRail: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  shortcut: { flex: 1, backgroundColor: '#1E1222', borderRadius: 18, paddingVertical: 12, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,20,147,0.2)' },
  shortcutLabel: { color: '#FF1493', fontWeight: '900', fontSize: 12 },
  shortcutTitle: { color: '#FFFFFF', fontWeight: '900', marginTop: 4, fontSize: 12 },
  homeNudge: { backgroundColor: '#1E1222', borderRadius: 22, padding: 16, borderWidth: 1, borderColor: 'rgba(255,20,147,0.22)', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 14, marginBottom: 18 },
  emptyDiscovery: { minHeight: 470, borderRadius: 28, borderWidth: 1, borderColor: 'rgba(255,20,147,0.24)', backgroundColor: '#1E1222', alignItems: 'center', justifyContent: 'center', padding: 24, marginBottom: 18 },
  emptyDiscoveryTitle: { color: '#FFFFFF', fontSize: 25, fontWeight: '900', textAlign: 'center', marginTop: 12 },
  emptyDiscoveryText: { color: 'rgba(255,255,255,0.7)', fontWeight: '800', textAlign: 'center', lineHeight: 22, marginTop: 8 },
  emptyDiscoveryButton: { backgroundColor: '#FF1493', borderRadius: 999, paddingHorizontal: 18, paddingVertical: 13, marginTop: 18 },
  emptyDiscoveryButtonText: { color: '#FFFFFF', fontWeight: '900' },
  footerNav: { position: 'absolute', left: 0, right: 0, bottom: 0, paddingTop: 8, paddingHorizontal: 14, backgroundColor: '#080608', borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.08)', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  footerItem: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 4 },
  footerLabel: { color: 'rgba(255,255,255,0.62)', fontSize: 10, fontWeight: '800' },
  footerLabelActive: { color: '#FFFFFF', fontWeight: '900' },
  footerBadge: { position: 'absolute', top: -7, right: -15, minWidth: 26, color: '#FFFFFF', backgroundColor: '#FF1200', overflow: 'hidden', borderRadius: 999, paddingHorizontal: 5, paddingVertical: 1, textAlign: 'center', fontSize: 9, fontWeight: '900' },
  exploreTitle: { color: '#FFFFFF', fontSize: 28, fontWeight: '900', marginBottom: 16 },
  exploreGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 14 },
  exploreTile: { width: '47.8%', aspectRatio: 0.78, borderRadius: 22, backgroundColor: '#211B1F', padding: 18, justifyContent: 'space-between', borderWidth: 1, borderColor: 'rgba(255,255,255,0.05)' },
  exploreTileFooter: { gap: 4 },
  exploreTileTitle: { color: '#FFFFFF', fontSize: 18, lineHeight: 22, fontWeight: '900' },
  exploreTileCount: { color: 'rgba(255,255,255,0.62)', fontSize: 16, fontWeight: '900' },
  likesTabs: { flexDirection: 'row', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.10)', marginBottom: 20 },
  likesTabButton: { flex: 1, alignItems: 'center' },
  likesTab: { flex: 1, textAlign: 'center', color: 'rgba(255,255,255,0.58)', paddingBottom: 14, fontWeight: '900' },
  likesTabActive: { flex: 1, textAlign: 'center', color: '#FFFFFF', paddingBottom: 14, borderBottomWidth: 2, borderBottomColor: '#FF1200', fontWeight: '900' },
  likePreviewCard: { minHeight: 520, borderRadius: 28, overflow: 'hidden', justifyContent: 'flex-end', backgroundColor: '#211B1F', marginBottom: 16 },
  likePreviewImage: { borderRadius: 28 },
  likePreviewCopy: { padding: 20 },
  likePreviewActions: { flexDirection: 'row', justifyContent: 'center', gap: 22, marginTop: 18 },
  likesUnlockButton: { backgroundColor: '#FFFFFF', borderRadius: 999, alignItems: 'center', paddingVertical: 16, marginBottom: 14 },
  likesUnlockText: { color: '#120914', fontSize: 18, fontWeight: '900' },
  likesTabWithDot: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 },
  likesScreenTitle: { color: '#FFFFFF', fontSize: 32, fontWeight: '900', marginBottom: 16 },
  likesSectionTitle: { color: '#FFFFFF', fontSize: 24, fontWeight: '900', marginTop: 12, marginBottom: 12 },
  likesSubcopy: { color: 'rgba(255,255,255,0.68)', fontWeight: '800', lineHeight: 20, marginBottom: 14 },
  freeLikeDrop: { borderRadius: 24, padding: 22, alignItems: 'center', marginBottom: 16 },
  freeLikePill: { color: '#FFFFFF', backgroundColor: 'rgba(255,255,255,0.24)', borderRadius: 999, overflow: 'hidden', paddingHorizontal: 18, paddingVertical: 9, fontWeight: '900', marginBottom: 12 },
  freeLikeTimer: { color: '#FFE9F1', fontSize: 40, fontWeight: '900', marginBottom: 10 },
  freeLikeCopy: { color: '#FFE9F1', fontSize: 15, fontWeight: '800', textAlign: 'center', lineHeight: 22 },
  goldMatchTouch: { flex: 1 },
  fullPhotoViewer: { flex: 1, backgroundColor: '#000000', alignItems: 'center', justifyContent: 'center' },
  fullPhotoImage: { width: '100%', height: '100%' },
  fullPhotoClose: { position: 'absolute', top: 42, left: 20, width: 48, height: 48, borderRadius: 24, backgroundColor: '#120914', alignItems: 'center', justifyContent: 'center' },
  goldPhotoArrow: { position: 'absolute', top: '45%', width: 40, height: 40, borderRadius: 20, backgroundColor: '#120914', alignItems: 'center', justifyContent: 'center', zIndex: 3 },
  goldPhotoArrowLeft: { left: 12 },
  goldPhotoArrowRight: { right: 12 },
  goldMatchShell: { marginBottom: 18 },
  goldMatchShellExpanded: { marginBottom: 22 },
  goldMatchCard: { height: 390, borderRadius: 28, overflow: 'hidden', backgroundColor: '#1E1222' },
  goldMatchCardExpanded: { height: 570 },
  goldMatchImage: { borderRadius: 28 },
  goldMatchBadge: { position: 'absolute', top: 16, left: 16, flexDirection: 'row', gap: 6, alignItems: 'center', backgroundColor: '#FFD700', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999 },
  goldMatchBadgeText: { color: '#120914', fontWeight: '900', fontSize: 12 },
  goldMatchFooter: { position: 'absolute', left: 16, right: 16, bottom: 16 },
  goldMatchName: { color: '#FFFFFF', fontSize: 31, fontWeight: '900' },
  goldMatchMeta: { color: '#FFFFFF', fontWeight: '900', marginTop: 4, marginBottom: 12 },
  goldMatchActions: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  goldPassButton: { width: 56, height: 56, borderRadius: 28, backgroundColor: 'rgba(255,255,255,0.12)', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)' },
  goldAcceptButton: { flex: 1, height: 56, borderRadius: 28, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  goldAcceptText: { color: '#120914', fontSize: 18, fontWeight: '900' },
  goldAcceptIconButton: { width: 62, height: 62, borderRadius: 31, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  goldExpandedPanel: { backgroundColor: 'rgba(18,9,20,0.76)', borderRadius: 20, padding: 12, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)' },
  goldExpandedGallery: { gap: 9, paddingRight: 8 },
  goldExpandedPhoto: { width: 82, height: 104, borderRadius: 16, backgroundColor: '#1E1222' },
  goldExpandedBio: { color: '#FFFFFF', fontWeight: '800', lineHeight: 19, marginTop: 10 },
  goldExpandedTags: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 9 },
  goldExpandedTag: { color: '#120914', backgroundColor: '#FFFFFF', borderRadius: 999, overflow: 'hidden', paddingHorizontal: 9, paddingVertical: 4, fontWeight: '900', fontSize: 11 },
  goldRevealButton: { height: 54, borderRadius: 27, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  goldRevealText: { color: '#120914', fontSize: 17, fontWeight: '900' },
  likesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  blurredLikeCard: { width: '48%', aspectRatio: 0.78, borderRadius: 22, overflow: 'hidden', backgroundColor: '#1E1222' },
  blurredLikeImage: { flex: 1, padding: 12, justifyContent: 'flex-end' },
  blurredLikeImageRadius: { borderRadius: 22 },
  blurredNamePill: { width: 72, height: 28, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.48)', marginBottom: -27 },
  blurredAge: { color: '#FFFFFF', fontSize: 24, fontWeight: '900', marginLeft: 84 },
  blurredMeta: { color: '#FFFFFF', fontSize: 14, fontWeight: '900', marginTop: 6 },
  sentLikeCard: { width: '48%', aspectRatio: 0.78, borderRadius: 22, overflow: 'hidden', backgroundColor: '#1E1222' },
  sentLikeImage: { flex: 1, padding: 12, justifyContent: 'flex-end' },
  sentStar: { position: 'absolute', right: 12, top: 12, width: 42, height: 42, borderRadius: 21, backgroundColor: 'rgba(0,0,0,0.48)', alignItems: 'center', justifyContent: 'center' },
  sentLikeName: { color: '#FFFFFF', fontWeight: '900', fontSize: 19 },
  sentLikeMeta: { color: '#9BC6FF', fontWeight: '900', marginTop: 4 },
  topPickHeadline: { color: '#FFFFFF', fontSize: 22, fontWeight: '900', lineHeight: 29, textAlign: 'center', marginVertical: 18 },
  topPickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  topPickCard: { width: '48%', aspectRatio: 0.78, borderRadius: 22, overflow: 'hidden', backgroundColor: '#1E1222' },
  topPickImage: { flex: 1 },
  topPickImageRadius: { borderRadius: 22 },
  topPickSilhouette: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(155,198,255,0.24)' },
  topPickFooter: { position: 'absolute', left: 12, right: 54, bottom: 12 },
  topPickName: { color: '#FFFFFF', fontWeight: '900', fontSize: 19 },
  topPickTime: { color: '#FFD700', fontWeight: '900', fontSize: 16, marginTop: 3 },
  topPickStar: { position: 'absolute', right: 12, bottom: 12, width: 42, height: 42, borderRadius: 21, backgroundColor: 'rgba(0,0,0,0.54)', alignItems: 'center', justifyContent: 'center' },
  topPickUnlockButton: { height: 56, borderRadius: 28, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center', marginTop: 22, marginBottom: 10 },
  topPickUnlockText: { color: '#120914', fontSize: 17, fontWeight: '900' },
  nudgeTitle: { color: '#FFFFFF', fontWeight: '900', fontSize: 16, marginTop: 3 },
  nudgeAction: { color: '#FFD700', fontWeight: '900' },
  panel: { backgroundColor: '#1E1222', borderRadius: 24, borderWidth: 1, borderColor: 'rgba(255,20,147,0.22)', padding: 18, marginBottom: 14 },
  chatInboxHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 4, marginBottom: 18 },
  chatHeroTitle: { color: '#FFFFFF', fontSize: 36, fontWeight: '900' },
  chatHeroMeta: { color: 'rgba(255,255,255,0.58)', fontWeight: '900', marginTop: 3 },
  searchBox: { minHeight: 52, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.12)', flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 22 },
  searchInput: { flex: 1, minHeight: 48, color: '#FFFFFF', fontSize: 18, fontWeight: '800' },
  chatSectionTitle: { color: '#FFFFFF', fontSize: 21, fontWeight: '900', marginBottom: 12 },
  readyMatchesRail: { gap: 16, paddingRight: 12, paddingBottom: 18 },
  readyMatchCard: { width: 86, alignItems: 'center' },
  readyMatchPhoto: { width: 84, height: 104, borderRadius: 18, backgroundColor: '#1E1222' },
  onlineDot: { position: 'absolute', top: 4, right: 2, width: 16, height: 16, borderRadius: 8, backgroundColor: '#16A34A', borderWidth: 3, borderColor: '#120914' },
  readyMatchName: { color: '#FFFFFF', fontWeight: '900', marginTop: 7, maxWidth: 86, textAlign: 'center' },
  messagesPanel: { backgroundColor: '#111011', borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)' },
  messagesTitle: { color: '#FFFFFF', fontSize: 21, fontWeight: '900', marginBottom: 8 },
  threadRow: { minHeight: 82, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.08)' },
  threadAvatar: { width: 58, height: 58, borderRadius: 29, backgroundColor: '#241528' },
  threadOnlineDot: { position: 'absolute', right: 1, bottom: 2, width: 14, height: 14, borderRadius: 7, backgroundColor: '#16A34A', borderWidth: 2, borderColor: '#111011' },
  threadCopy: { flex: 1, minWidth: 0 },
  threadName: { color: '#FFFFFF', fontSize: 20, fontWeight: '900' },
  threadPreview: { color: 'rgba(255,255,255,0.62)', fontSize: 15, fontWeight: '800', marginTop: 4 },
  yourTurnPill: { color: '#120914', backgroundColor: '#FFFFFF', borderRadius: 999, overflow: 'hidden', paddingHorizontal: 13, paddingVertical: 7, fontWeight: '900', fontSize: 12 },
  threadBadge: { minWidth: 24, height: 24, borderRadius: 12, overflow: 'hidden', backgroundColor: '#FF1493', color: '#FFFFFF', textAlign: 'center', paddingTop: 3, fontWeight: '900', fontSize: 12 },
  modeHint: { color: 'rgba(255,255,255,0.58)', fontWeight: '800', fontSize: 12, marginTop: 8, lineHeight: 17 },
  emptyThreadCard: { backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,20,147,0.16)', borderRadius: 18, padding: 16, marginTop: 8 },
  emptyThreadTitle: { color: '#FFFFFF', fontWeight: '900', fontSize: 17, marginBottom: 5, textAlign: 'center' },
  emptyThreadText: { color: 'rgba(255,255,255,0.62)', fontWeight: '800', lineHeight: 21, paddingVertical: 18, textAlign: 'center' },
  threadTopBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, marginBottom: 14 },
  chatBackButton: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#1E1222', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255,20,147,0.20)' },
  matchContext: { color: '#FFD700', fontWeight: '900', marginBottom: 10, lineHeight: 18 },
  chatScreen: { backgroundColor: '#120914', paddingBottom: 24 },
  chatKeyboardAvoider: { flex: 1, justifyContent: 'flex-end' },
  chatHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 12, marginBottom: 10, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.08)' },
  chatIdentity: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  chatInboxStrip: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#1E1222', borderRadius: 20, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(255,20,147,0.18)' },
  chatScreenTitle: { color: '#FFFFFF', fontSize: 21, fontWeight: '900' },
  chatTokenPill: { color: '#120914', backgroundColor: '#FFD700', borderRadius: 999, overflow: 'hidden', paddingHorizontal: 11, paddingVertical: 7, fontWeight: '900' },
  safetyReminder: { flexDirection: 'row', gap: 9, alignItems: 'flex-start', backgroundColor: 'rgba(255,215,0,0.10)', borderWidth: 1, borderColor: 'rgba(255,215,0,0.22)', borderRadius: 18, padding: 12, marginBottom: 12 },
  safetyReminderText: { flex: 1, color: 'rgba(255,255,255,0.82)', fontWeight: '800', lineHeight: 19, fontSize: 12 },
  safetyBlockCard: { backgroundColor: 'rgba(255,218,214,0.12)', borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,111,97,0.34)', padding: 14, marginBottom: 12, gap: 7 },
  safetyBlockTitle: { color: '#FFFFFF', fontWeight: '900', fontSize: 14 },
  safetyBlockText: { color: 'rgba(255,255,255,0.72)', fontWeight: '800', lineHeight: 19, fontSize: 12 },
  safetyBlockAction: { color: '#FFD700', fontWeight: '900', marginTop: 2 },
  abuseReportButton: { marginTop: 8, alignSelf: 'flex-start', borderRadius: 999, backgroundColor: '#FF1493', paddingHorizontal: 10, paddingVertical: 6 },
  abuseReportText: { color: '#FFFFFF', fontSize: 11, fontWeight: '900' },
  contactSheetBackdrop: { flex: 1, backgroundColor: 'rgba(6,2,8,0.72)', justifyContent: 'flex-end', paddingHorizontal: 16, paddingBottom: 18 },
  contactSheetCard: { backgroundColor: '#1E1222', borderRadius: 28, padding: 20, borderWidth: 1, borderColor: 'rgba(255,20,147,0.32)', shadowColor: '#FF1493', shadowOpacity: 0.32, shadowRadius: 24, shadowOffset: { width: 0, height: -8 }, elevation: 18 },
  contactSheetIcon: { width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  contactSheetEyebrow: { color: '#FFD700', fontSize: 12, fontWeight: '900', textTransform: 'uppercase', marginBottom: 6 },
  contactSheetTitle: { color: '#FFFFFF', fontSize: 24, fontWeight: '900', lineHeight: 29, marginBottom: 10 },
  contactSheetBody: { color: 'rgba(255,255,255,0.76)', fontSize: 14, fontWeight: '800', lineHeight: 21, marginBottom: 14 },
  contactSafetyList: { gap: 10, backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 18, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.07)' },
  contactSafetyItem: { flexDirection: 'row', gap: 9, alignItems: 'flex-start' },
  contactSafetyText: { flex: 1, color: 'rgba(255,255,255,0.78)', fontSize: 12, fontWeight: '800', lineHeight: 18 },
  contactSheetActions: { flexDirection: 'row', gap: 10 },
  contactReviewButton: { flex: 1, height: 50, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.08)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.10)' },
  contactReviewText: { color: '#FFFFFF', fontSize: 14, fontWeight: '900', textTransform: 'uppercase' },
  contactSendButton: { flex: 1.25, height: 50, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FF1493' },
  contactSendText: { color: '#FFFFFF', fontSize: 14, fontWeight: '900', textTransform: 'uppercase' },
  conversationPanel: { backgroundColor: '#1E1222', borderRadius: 22, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(255,20,147,0.18)', flexShrink: 1 },
  chatIconButton: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#2A1A30', borderWidth: 1, borderColor: 'rgba(255,20,147,0.22)', alignItems: 'center', justifyContent: 'center' },
  chatTools: { backgroundColor: '#1E1222', borderRadius: 20, padding: 12, borderWidth: 1, borderColor: 'rgba(255,20,147,0.14)' },
  chatToolsSimple: { backgroundColor: '#1E1222', borderRadius: 18, padding: 12, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(255,20,147,0.14)' },
  chatHeaderAvatar: { width: 42, height: 42, borderRadius: 21, borderWidth: 2, borderColor: '#FF1493' },
  chatName: { color: '#FFFFFF', fontWeight: '900', fontSize: 17 },
  chatStatus: { color: '#16A34A', fontWeight: '800', fontSize: 12 },
  headerIcons: { flexDirection: 'row', gap: 10 },
  kicker: { color: '#FF1493', fontWeight: '900', textTransform: 'uppercase', marginBottom: 8, fontSize: 12 },
  kickerLight: { color: '#FFE9F1', fontWeight: '900', textTransform: 'uppercase', marginBottom: 8, fontSize: 12 },
  kickerDark: { color: '#120914', fontWeight: '900', textTransform: 'uppercase', marginBottom: 8, fontSize: 12 },
  title: { color: '#FFFFFF', fontSize: 27, fontWeight: '900', marginBottom: 12 },
  sectionLabel: { color: '#FFD700', fontWeight: '900', textTransform: 'uppercase', marginBottom: 10, fontSize: 12 },
  insight: { color: '#FFFFFF', backgroundColor: '#2A1A30', borderRadius: 16, padding: 13, marginTop: 8, fontWeight: '800', lineHeight: 21 },
  newMatches: { flexDirection: 'row', gap: 12, paddingRight: 8, marginBottom: 14 },
  matchAvatarWrap: { alignItems: 'center', gap: 6 },
  matchAvatar: { width: 52, height: 52, borderRadius: 26, borderWidth: 2, borderColor: '#FF1493' },
  matchAvatarText: { color: 'rgba(255,255,255,0.72)', fontWeight: '900', fontSize: 12 },
  signalRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  signal: { backgroundColor: '#2A1A30', color: '#FFFFFF', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 999, overflow: 'hidden', fontWeight: '900', fontSize: 12 },
  promptRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  promptChip: { backgroundColor: '#FFD700', color: '#120914', borderRadius: 999, overflow: 'hidden', paddingHorizontal: 12, paddingVertical: 8, fontWeight: '900', fontSize: 12 },
  lockedReply: { backgroundColor: '#1E1222', borderWidth: 1, borderColor: '#FFD700', borderRadius: 20, padding: 16, marginVertical: 10, gap: 8 },
  lockedHeader: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  lockedTitle: { color: '#FFD700', fontWeight: '900', fontSize: 13 },
  blurredMask: { color: 'rgba(255,255,255,0.24)', fontSize: 16, letterSpacing: 2, lineHeight: 24 },
  lockedText: { color: 'rgba(255,255,255,0.72)', fontWeight: '800', fontSize: 13, lineHeight: 20 },
  unlockButton: { backgroundColor: '#FFD700', borderRadius: 14, alignItems: 'center', paddingVertical: 13, marginTop: 8 },
  unlockButtonDone: { backgroundColor: '#16A34A' },
  unlockButtonText: { color: '#120914', fontWeight: '900' },
  bubble: { maxWidth: '86%', padding: 13, borderRadius: 20, marginVertical: 5 },
  sent: { alignSelf: 'flex-end', backgroundColor: '#FF1493', borderBottomRightRadius: 4 },
  received: { alignSelf: 'flex-start', backgroundColor: '#1E1222', borderBottomLeftRadius: 4 },
  sentText: { color: '#FFFFFF', fontWeight: '800', lineHeight: 22 },
  receivedText: { color: '#FFFFFF', fontWeight: '800', lineHeight: 22 },
  sentMeta: { color: 'rgba(255,255,255,0.68)', fontSize: 11, fontWeight: '900', marginTop: 6 },
  receivedMeta: { color: 'rgba(255,255,255,0.5)', fontSize: 11, fontWeight: '900', marginTop: 6 },
  segment: { flexDirection: 'row', backgroundColor: '#1E1222', borderRadius: 18, padding: 4, marginVertical: 12 },
  segmentItem: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 15 },
  segmentActive: { backgroundColor: '#FF1493' },
  segmentText: { color: 'rgba(255,255,255,0.7)', fontWeight: '900', textTransform: 'capitalize', fontSize: 12 },
  segmentTextActive: { color: '#FFFFFF' },
  giftRow: { flexDirection: 'row', gap: 8, marginTop: 10 },
  giftButton: { flex: 1, backgroundColor: '#1E1222', borderRadius: 18, padding: 12, borderWidth: 1, borderColor: 'rgba(255,20,147,0.22)' },
  giftName: { color: '#FFFFFF', fontWeight: '900' },
  giftMeta: { color: '#FFD700', fontWeight: '900', marginTop: 4, fontSize: 12 },
  composer: { flexDirection: 'row', gap: 8, marginTop: 10, backgroundColor: '#1E1222', borderRadius: 26, padding: 6, borderWidth: 1, borderColor: 'rgba(255,20,147,0.24)', alignItems: 'flex-end' },
  input: { flex: 1, minHeight: 42, maxHeight: 104, paddingHorizontal: 14, paddingVertical: 10, color: '#FFFFFF', fontWeight: '800', lineHeight: 20 },
  send: { width: 42, height: 42, backgroundColor: '#FF1493', borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  sendText: { color: '#FFFFFF', fontWeight: '900' },
  walletHero: { borderRadius: 28, padding: 20, marginBottom: 14 },
  balance: { color: '#120914', fontSize: 44, fontWeight: '900' },
  heroCopy: { color: '#FFE9F1', fontWeight: '800', lineHeight: 22, marginTop: 8 },
  heroCopyDark: { color: '#3E2400', fontWeight: '900', lineHeight: 22, marginTop: 8 },
  packageGrid: { gap: 10, marginBottom: 14 },
  packageCard: { backgroundColor: '#1E1222', borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,20,147,0.22)', padding: 16 },
  packageFeatured: { borderColor: '#FFD700' },
  packageBadge: { alignSelf: 'flex-start', color: '#120914', backgroundColor: '#FFD700', borderRadius: 999, overflow: 'hidden', paddingHorizontal: 10, paddingVertical: 5, fontWeight: '900', fontSize: 11, marginBottom: 8 },
  packageAmount: { color: '#FFFFFF', fontSize: 28, fontWeight: '900' },
  packagePrice: { color: '#FF1493', fontWeight: '900', fontSize: 18, marginTop: 3 },
  packageUnit: { color: 'rgba(255,255,255,0.62)', fontWeight: '800', marginTop: 3 },
  packageTopRow: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', gap: 12 },
  packageSelectButton: { minHeight: 48, borderRadius: 24, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center', marginTop: 14 },
  packageSelectText: { color: '#120914', fontWeight: '900', fontSize: 16 },
  paymentPage: { gap: 16 },
  paymentPageEmpty: { backgroundColor: '#111823', borderRadius: 26, padding: 24, alignItems: 'center', gap: 14 },
  paymentPageHero: { borderRadius: 30, padding: 22, minHeight: 230, justifyContent: 'space-between' },
  paymentPageEyebrow: { color: '#FFD700', fontWeight: '900', textTransform: 'uppercase', fontSize: 12 },
  paymentPageEyebrowDark: { color: '#3E2400' },
  paymentPageTitle: { color: '#FFFFFF', fontSize: 29, lineHeight: 35, fontWeight: '900', marginTop: 8 },
  paymentPageTitleDark: { color: '#120914' },
  paymentPageSubtitle: { color: 'rgba(255,255,255,0.76)', fontWeight: '800', lineHeight: 22, marginTop: 8 },
  paymentPageSubtitleDark: { color: 'rgba(18,9,20,0.76)' },
  paymentPageAmountRow: { backgroundColor: 'rgba(255,255,255,0.14)', borderRadius: 22, padding: 16, marginTop: 20 },
  paymentPageAmountLabel: { color: 'rgba(255,255,255,0.72)', fontWeight: '900', marginBottom: 4 },
  paymentPageAmountLabelDark: { color: 'rgba(18,9,20,0.66)' },
  paymentPageAmount: { color: '#FFFFFF', fontSize: 28, fontWeight: '900' },
  paymentPageAmountDark: { color: '#120914' },
  paymentMethodPanel: { backgroundColor: '#111823', borderRadius: 28, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', padding: 18 },
  paymentMethodTitle: { color: '#FFFFFF', fontSize: 22, fontWeight: '900', marginBottom: 14 },
  methodCard: { flexDirection: 'row', gap: 12, alignItems: 'center', backgroundColor: '#0D111A', borderRadius: 20, padding: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)' },
  methodIconWrap: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#00A846', alignItems: 'center', justifyContent: 'center' },
  methodCopy: { flex: 1 },
  methodTitle: { color: '#FFFFFF', fontWeight: '900', fontSize: 16 },
  methodCaption: { color: 'rgba(255,255,255,0.62)', fontWeight: '700', lineHeight: 18, marginTop: 3, fontSize: 12 },
  paymentPageInput: { minHeight: 54, borderRadius: 20, backgroundColor: '#0D111A', borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)', color: '#FFFFFF', paddingHorizontal: 16, fontWeight: '900', marginTop: 12, marginBottom: 12 },
  paymentMpesaButton: { minHeight: 56, borderRadius: 28, backgroundColor: '#00A846', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9 },
  paymentCardButton: { minHeight: 56, borderRadius: 28, backgroundColor: '#2563EB', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9 },
  paymentMethodButtonText: { color: '#FFFFFF', fontWeight: '900', fontSize: 16 },
  cardDivider: { flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 16 },
  cardDividerLine: { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.12)' },
  cardDividerText: { color: 'rgba(255,255,255,0.58)', fontWeight: '900' },
  paymentNotice: { color: '#FFD700', fontWeight: '800', marginTop: 8, marginBottom: 12, textAlign: 'center' },
  paymentSheetBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.62)', justifyContent: 'flex-end' },
  paymentSheetCard: { backgroundColor: '#111823', borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 20, paddingBottom: 30, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)' },
  paymentSheetHandle: { width: 48, height: 5, borderRadius: 999, backgroundColor: 'rgba(255,255,255,0.24)', alignSelf: 'center', marginBottom: 18 },
  paymentSheetTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  paymentProviderIcon: { width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center' },
  paymentCloseButton: { width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(255,255,255,0.1)', alignItems: 'center', justifyContent: 'center' },
  paymentSheetEyebrow: { color: '#FFD700', fontWeight: '900', textTransform: 'uppercase', letterSpacing: 0, marginTop: 18 },
  paymentSheetTitle: { color: '#FFFFFF', fontSize: 30, fontWeight: '900', marginTop: 6 },
  paymentSheetSubtitle: { color: 'rgba(255,255,255,0.74)', fontWeight: '800', lineHeight: 22, marginTop: 6 },
  paymentAmountCard: { backgroundColor: '#0D111A', borderRadius: 22, padding: 18, marginTop: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)' },
  paymentAmountLabel: { color: 'rgba(255,255,255,0.62)', fontWeight: '900', marginBottom: 6 },
  paymentAmountValue: { color: '#FFFFFF', fontSize: 32, fontWeight: '900' },
  paymentStatusRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 16 },
  paymentStatusText: { color: '#FFFFFF', fontWeight: '900' },
  paymentInstructionText: { color: 'rgba(255,255,255,0.76)', lineHeight: 21, fontWeight: '700', marginTop: 12 },
  paymentReferenceText: { color: 'rgba(255,255,255,0.48)', fontSize: 12, fontWeight: '800', marginTop: 10 },
  paymentInfoBox: { flexDirection: 'row', gap: 9, backgroundColor: 'rgba(255,215,0,0.1)', borderColor: 'rgba(255,215,0,0.24)', borderWidth: 1, borderRadius: 18, padding: 13, marginTop: 16 },
  paymentInfoText: { color: '#FFE9A8', flex: 1, fontWeight: '800', lineHeight: 19, fontSize: 12 },
  paymentPrimaryButton: { minHeight: 56, borderRadius: 28, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center', marginTop: 18 },
  paymentPrimaryButtonDisabled: { opacity: 0.5 },
  paymentPrimaryText: { color: '#111823', fontSize: 17, fontWeight: '900' },
  paymentActionsRow: { flexDirection: 'row', gap: 10, marginTop: 14 },
  paymentSecondaryButton: { flex: 1, minHeight: 50, borderRadius: 25, backgroundColor: 'rgba(255,255,255,0.1)', alignItems: 'center', justifyContent: 'center' },
  paymentSecondaryText: { color: '#FFFFFF', fontWeight: '900' },
  purchaseScreen: { backgroundColor: '#111823', borderRadius: 24, padding: 18, paddingBottom: 26, marginBottom: 18 },
  purchaseCloseRow: { height: 42, justifyContent: 'center', alignItems: 'flex-start' },
  superStar: { width: 108, height: 108, borderRadius: 54, alignSelf: 'center', alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  superTitle: { color: '#AFCBFF', fontSize: 45, fontWeight: '900', textAlign: 'center', marginBottom: 12 },
  superTitleScript: { fontStyle: 'italic' },
  superCopy: { color: '#BFD3F8', fontSize: 20, lineHeight: 28, fontWeight: '800', textAlign: 'center', marginBottom: 24 },
  superOfferStack: { gap: 12 },
  superOffer: { minHeight: 120, borderRadius: 22, padding: 18, backgroundColor: '#0D111A', borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 16 },
  superOfferActive: { backgroundColor: '#9BC6FF', borderColor: '#9BC6FF' },
  superOfferBadge: { color: '#FFFFFF', fontWeight: '900', fontSize: 13, marginBottom: 12 },
  superOfferCount: { color: '#FFFFFF', fontSize: 24, fontWeight: '900', lineHeight: 29 },
  superOfferHint: { color: 'rgba(255,255,255,0.72)', fontWeight: '800', marginTop: 5 },
  superOfferPriceBox: { minWidth: 124, alignItems: 'flex-end' },
  superOfferPrice: { color: '#FFFFFF', fontSize: 19, fontWeight: '900' },
  superOfferUnit: { color: 'rgba(255,255,255,0.72)', fontSize: 11, fontWeight: '900', marginTop: 4, textAlign: 'right' },
  orText: { color: '#FFFFFF', fontSize: 28, fontStyle: 'italic', fontWeight: '900', textAlign: 'center', marginVertical: 18 },
  goldInlineCard: { minHeight: 92, borderRadius: 20, padding: 16, backgroundColor: '#0D111A', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  goldInlineTitle: { color: '#FFFFFF', fontSize: 20, fontWeight: '900' },
  goldInlineCopy: { color: 'rgba(255,255,255,0.78)', fontSize: 13, fontWeight: '800', marginTop: 6 },
  goldSelectButton: { backgroundColor: '#EAF0FF', borderRadius: 999, paddingHorizontal: 24, paddingVertical: 12 },
  goldSelectText: { color: '#120914', fontWeight: '900', fontSize: 16 },
  purchaseContinue: { minHeight: 60, borderRadius: 30, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center', marginTop: 22 },
  purchaseContinueText: { color: '#111111', fontWeight: '900', fontSize: 20, textAlign: 'center' },
  goldHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  goldBrand: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  goldBrandText: { color: '#FFFFFF', fontSize: 26, fontWeight: '900' },
  goldBadge: { color: '#120914', backgroundColor: '#FFD700', borderRadius: 999, overflow: 'hidden', paddingHorizontal: 13, paddingVertical: 6, fontWeight: '900' },
  goldHeroText: { color: '#FFFFFF', fontSize: 29, lineHeight: 36, fontWeight: '900', marginBottom: 22 },
  goldPlanLabel: { color: '#FFFFFF', fontSize: 20, fontWeight: '900', marginBottom: 14 },
  goldPlanScroller: { gap: 14, paddingRight: 20, paddingBottom: 18 },
  goldPlanOption: { width: 228, minHeight: 152, borderRadius: 22, borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)', padding: 18, justifyContent: 'space-between', backgroundColor: '#111111' },
  goldPlanOptionActive: { borderColor: '#FFD700', borderWidth: 2 },
  goldOptionTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  goldOptionBadge: { color: '#FFD700', fontWeight: '900', fontSize: 16 },
  goldOptionLabel: { color: '#FFFFFF', fontSize: 28, fontWeight: '900', lineHeight: 32 },
  goldOptionPrice: { color: '#FFFFFF', fontSize: 17, fontWeight: '900', marginTop: 6 },
  goldIncludedCard: { borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)', padding: 18, marginTop: 10 },
  goldIncludedPill: { alignSelf: 'center', color: 'rgba(255,255,255,0.62)', backgroundColor: '#111111', borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)', borderRadius: 999, overflow: 'hidden', paddingHorizontal: 12, paddingVertical: 5, marginTop: -34, marginBottom: 14, fontWeight: '800' },
  goldBenefitRow: { flexDirection: 'row', alignItems: 'center', gap: 18, paddingVertical: 10 },
  goldBenefitText: { color: '#FFFFFF', fontSize: 17, fontWeight: '900', flex: 1, lineHeight: 22 },
  goldTerms: { color: 'rgba(255,255,255,0.82)', lineHeight: 21, fontWeight: '700', marginTop: 18 },
  catalogCard: { backgroundColor: '#1E1222', borderRadius: 22, borderWidth: 1, borderColor: 'rgba(255,215,0,0.22)', padding: 16, marginBottom: 16 },
  catalogRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.06)' },
  catalogLabel: { color: '#FFFFFF', fontWeight: '800' },
  catalogCost: { color: '#FFD700', fontWeight: '900' },
  planCard: { borderRadius: 24, padding: 16, borderWidth: 1, borderColor: 'rgba(255,215,0,0.28)', marginBottom: 12, overflow: 'hidden' },
  platinumPlanCard: { borderColor: 'rgba(155,198,255,0.46)', shadowColor: '#9BC6FF', shadowOpacity: 0.22, shadowRadius: 14, shadowOffset: { width: 0, height: 8 } },
  planCardActive: { borderColor: '#FFD700', borderWidth: 2 },
  planHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  planName: { color: '#FFFFFF', fontSize: 21, fontWeight: '900' },
  planPrice: { color: '#FFD700', fontWeight: '900', fontSize: 14 },
  planSubline: { color: 'rgba(255,255,255,0.68)', fontWeight: '800', fontSize: 11, marginTop: 3, maxWidth: 190 },
  planPerkGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  planPerkPill: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(255,255,255,0.88)', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 7 },
  planPerkPillText: { color: '#120914', fontWeight: '900', fontSize: 10 },
  planSelectButton: { minHeight: 50, borderRadius: 25, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center', marginTop: 16 },
  platinumSelectButton: { backgroundColor: '#9BC6FF' },
  planSelectText: { color: '#120914', fontWeight: '900', fontSize: 16 },
  planPerk: { color: '#FFFFFF', fontWeight: '800', paddingVertical: 5 },
  boostButton: { backgroundColor: '#FFD700', padding: 18, borderRadius: 22, alignItems: 'center', marginTop: 12, marginBottom: 14 },
  boostButtonActive: { backgroundColor: '#FF6F61' },
  boostText: { color: '#120914', fontWeight: '900' },
  textButton: { alignItems: 'center', paddingVertical: 12 },
  textButtonLabel: { color: '#FFD700', fontWeight: '900' },
  legalPanel: { backgroundColor: '#1E1222', borderRadius: 22, borderWidth: 1, borderColor: 'rgba(255,215,0,0.18)', padding: 16, marginBottom: 14 },
  dangerPanel: { backgroundColor: '#1E1222', borderRadius: 22, borderWidth: 1, borderColor: 'rgba(255,111,97,0.28)', padding: 16, marginBottom: 14 },
  dangerActionRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  dangerSoftButton: { flex: 1, minHeight: 50, borderRadius: 16, backgroundColor: 'rgba(255,111,97,0.1)', borderWidth: 1, borderColor: 'rgba(255,111,97,0.28)', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 12 },
  dangerSoftButtonText: { color: '#FFD7D2', fontWeight: '900', textAlign: 'center' },
  dangerButton: { flex: 1, minHeight: 50, borderRadius: 16, backgroundColor: '#FF6F61', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 12 },
  dangerButtonText: { color: '#120914', fontWeight: '900', textAlign: 'center' },
  legalLink: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.08)' },
  legalTitle: { color: '#FFFFFF', fontWeight: '900', fontSize: 16, marginBottom: 4 },
  policyScreen: { gap: 12 },
  policyItem: { backgroundColor: '#1E1222', borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,20,147,0.18)', padding: 16 },
  policyTitle: { color: '#FFD700', fontWeight: '900', fontSize: 17, marginBottom: 6 },
  policyBody: { color: 'rgba(255,255,255,0.78)', fontWeight: '800', lineHeight: 21 },
  complianceText: { color: 'rgba(255,255,255,0.62)', fontSize: 12, lineHeight: 18, fontWeight: '700', marginBottom: 18 },
  listItem: { backgroundColor: '#2A1A30', borderRadius: 18, padding: 15, marginTop: 10, borderWidth: 1, borderColor: 'rgba(255,20,147,0.14)' },
  listTitle: { color: '#FFFFFF', fontWeight: '900', fontSize: 16 },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#1E1222', borderWidth: 1, borderColor: 'rgba(255,20,147,0.22)', borderRadius: 20, padding: 16, marginBottom: 12 },
  switchTitle: { flex: 1, fontWeight: '900', color: '#FFFFFF', paddingRight: 10 },
  toggleTrack: { width: 52, height: 30, borderRadius: 999, backgroundColor: '#4B384F', padding: 3 },
  toggleTrackOn: { backgroundColor: '#FF1493' },
  toggleDot: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#FFFFFF' },
  toggleDotOn: { transform: [{ translateX: 22 }] },
  safetyScore: { flexDirection: 'row', gap: 16, backgroundColor: '#1E1222', borderRadius: 24, padding: 18, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,20,147,0.22)' },
  score: { width: 76, height: 76, borderRadius: 38, textAlign: 'center', textAlignVertical: 'center', backgroundColor: '#FFD700', color: '#120914', fontSize: 30, fontWeight: '900', overflow: 'hidden' },
  scoreTitle: { color: '#FFFFFF', fontSize: 20, fontWeight: '900', marginBottom: 4 },
  progress: { height: 9, backgroundColor: '#2A1A30', borderRadius: 999, overflow: 'hidden', marginVertical: 12 },
  progressFill: { height: 9, backgroundColor: '#FF1493' },
  profileStrength: { color: '#FFD700', fontWeight: '900', fontSize: 18 },
  editProfilePanel: { backgroundColor: '#241528', borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,20,147,0.24)', padding: 14, marginTop: 12, marginBottom: 12 },
  editProfileHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 },
  ageLockPill: { minWidth: 54, height: 38, borderRadius: 999, backgroundColor: '#FFD700', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingHorizontal: 10 },
  ageLockText: { color: '#120914', fontWeight: '900' },
  lockedAgeRow: { minHeight: 54, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,215,0,0.26)', paddingHorizontal: 14, marginBottom: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  lockedAgeLabel: { color: 'rgba(255,255,255,0.58)', fontWeight: '900', fontSize: 11, textTransform: 'uppercase' },
  lockedAgeValue: { color: '#FFFFFF', fontWeight: '900', fontSize: 16, marginTop: 2 },
  lockedAgeBadge: { color: '#120914', backgroundColor: '#FFD700', overflow: 'hidden', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5, fontWeight: '900', fontSize: 11 },
  distancePanel: { backgroundColor: '#2A1A30', borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,20,147,0.24)', padding: 14, marginTop: 12, marginBottom: 12 },
  distanceHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 },
  distanceTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '900' },
  distanceMeta: { color: 'rgba(255,255,255,0.66)', fontWeight: '800', marginTop: 3, lineHeight: 18 },
  mapToggle: { width: 42, height: 42, borderRadius: 21, borderWidth: 1, borderColor: 'rgba(255,215,0,0.45)', alignItems: 'center', justifyContent: 'center', backgroundColor: '#1E1222' },
  mapToggleActive: { backgroundColor: '#FFD700', borderColor: '#FFD700' },
  distanceScale: { flexDirection: 'row', justifyContent: 'space-between', marginTop: -2 },
  distanceScaleText: { color: 'rgba(255,255,255,0.52)', fontSize: 11, fontWeight: '800' },
  ageRangeBlock: { marginTop: 16, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.08)', paddingTop: 14 },
  ageRangeHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  ageRangeValue: { color: '#FFD700', fontWeight: '900', fontSize: 16 },
  distanceSaveButton: { marginTop: 10, backgroundColor: '#FF1493', borderRadius: 999, alignItems: 'center', paddingVertical: 12 },
  distanceSaveText: { color: '#FFFFFF', fontWeight: '900' },
  photoSlotGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginVertical: 12 },
  photoSlot: { width: '30.5%', aspectRatio: 0.82, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,20,147,0.25)', backgroundColor: '#2A1A30', alignItems: 'center', justifyContent: 'center', gap: 6, overflow: 'hidden' },
  photoSlotMain: { borderColor: '#FFD700', borderWidth: 2 },
  photoSlotText: { color: 'rgba(255,255,255,0.86)', fontWeight: '900', fontSize: 12, position: 'absolute', left: 6, right: 6, bottom: 7, textAlign: 'center', backgroundColor: 'rgba(18,9,20,0.72)', borderRadius: 999, overflow: 'hidden', paddingVertical: 4 },
  photoThumb: { width: '100%', height: '100%', borderRadius: 12 },
  profileActionGrid: { flexDirection: 'row', gap: 8, marginTop: 8 },
  profileAction: { flex: 1, minHeight: 54, borderRadius: 18, backgroundColor: '#2A1A30', borderWidth: 1, borderColor: 'rgba(255,215,0,0.24)', alignItems: 'center', justifyContent: 'center', gap: 5 },
  profileActionText: { color: '#FFFFFF', fontWeight: '900', fontSize: 12, textAlign: 'center' },
  profileActionDisabled: { opacity: 0.48 },
  promptEditor: { backgroundColor: '#2A1A30', borderRadius: 16, borderWidth: 1, borderColor: 'rgba(255,20,147,0.18)', padding: 12, marginTop: 9 },
  promptEditorLabel: { color: '#FFD700', fontWeight: '900', marginBottom: 7 },
  promptEditorInput: { minHeight: 46, color: '#FFFFFF', fontWeight: '800', lineHeight: 20, textAlignVertical: 'top' },
});
